<?php
session_start();
require '../../config/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
  header("Location: ../../auth/login.php");
  exit;
}

$stmt = $conn->query("
  SELECT ar.*, CONCAT(t.fname, ' ', t.lname) AS tech_name
  FROM archived_requests ar
  LEFT JOIN technicians t ON ar.tech_id = t.tech_id
  ORDER BY ar.created_at DESC
");
$archives = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Archived Requests</title>
  <link rel="stylesheet" href="AArchive.css">
</head>
<body>
<div class="page-container">
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li><a href="../Dashboard/ADashboard.php">Dashboard</a></li>
      <li><a href="../Update/ARequest.php">Requests</a></li>
      <li class="active"><a href="../Archive/AArchive.php">Archives</a></li>
      <li><a href="../Technicians/ATechnicians.php">Technicians</a></li>
      <li><a href="../Users/AUsers.php">Users</a></li>
      <li class="logout"><a href="../../auth/logout.php">Logout</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <header><h1>ARCHIVED REQUESTS</h1></header>
    <section class="archive-list">
      <?php foreach ($archives as $r): ?>
      <div class="archive-card">
        <h3><?= htmlspecialchars($r['unit_name']) ?></h3>
        <p><b>Requester:</b> <?= htmlspecialchars($r['fname'].' '.$r['lname']) ?></p>
        <p><b>Technician:</b> <?= htmlspecialchars($r['tech_name'] ?: 'N/A') ?></p>
        <p><b>Room:</b> <?= htmlspecialchars($r['room']) ?></p>
        <p><b>Status:</b> ✅ Completed</p>
        <p><b>Date:</b> <?= htmlspecialchars($r['request_date']) ?></p>
      </div>
      <?php endforeach; ?>
      <?php if (empty($archives)): ?>
        <p style="color:white;text-align:center;">No archived requests found.</p>
      <?php endif; ?>
    </section>
  </main>   
</div>
</body>
</html>
