// ====== ADMIN DASHBOARD SCRIPT ======

// Run once DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  setupRealTimeUpdates();
  setupCharCount();
  
  // Close modal when clicking outside
  window.addEventListener('click', function(event) {
    const modal = document.getElementById('reportModal');
    if (event.target === modal) {
      closeReportModal();
    }
  });
  
  // Close modal with Escape key
  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
      closeReportModal();
    }
  });
});

// ====== BEAUTIFUL MODAL FUNCTIONS ======
function openReportModal() {
  const modal = document.getElementById('reportModal');
  modal.style.display = 'block';
  
  // Prevent body scroll when modal is open
  document.body.style.overflow = 'hidden';
  
  // Add animation class
  setTimeout(() => {
    modal.querySelector('.modal-content').classList.add('modal-open');
  }, 10);
  
  // Set focus to first input
  document.getElementById('reportTitle').focus();
}

function closeReportModal() {
  const modal = document.getElementById('reportModal');
  const modalContent = modal.querySelector('.modal-content');
  
  // Restore body scroll
  document.body.style.overflow = 'auto';
  
  modalContent.classList.remove('modal-open');
  modalContent.classList.add('modal-close');
  
  setTimeout(() => {
    modal.style.display = 'none';
    modalContent.classList.remove('modal-close');
  }, 300);
}

// Character count for textarea
function setupCharCount() {
  const textarea = document.getElementById('reportMessage');
  const charCount = document.getElementById('charCount');
  
  textarea.addEventListener('input', function() {
    const count = this.value.length;
    charCount.textContent = count;
    
    // Change color based on length
    if (count > 500) {
      charCount.style.color = '#dc3545';
    } else if (count > 300) {
      charCount.style.color = '#ffc107';
    } else {
      charCount.style.color = '#28a745';
    }
  });
}

// Enhanced report generation with loading state
function generateReport() {
  const generateBtn = document.querySelector('.btn-primary');
  const originalHtml = generateBtn.innerHTML;
  
  // Show loading state
  generateBtn.innerHTML = '<span class="loading"></span> Generating Report...';
  generateBtn.disabled = true;
  
  // Get form values
  const title = document.getElementById('reportTitle').value || 'Monthly Maintenance Performance Report';
  const message = document.getElementById('reportMessage').value;
  const includeCharts = document.getElementById('includeCharts').checked;
  const includeTables = document.getElementById('includeTables').checked;
  const includeSummary = document.getElementById('includeSummary').checked;
  
  // Simulate processing time
  setTimeout(() => {
    // Create print window
    const printWindow = window.open('', '_blank');
    
    // Get current date
    const currentDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Build beautiful report content
    let reportContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${title}</title>
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 40px;
            color: #333;
            line-height: 1.6;
            background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
          }
          .report-header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: linear-gradient(135deg, #004aad, #0066ff);
            color: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 74, 173, 0.3);
          }
          .report-header h1 {
            margin: 0 0 10px 0;
            font-size: 32px;
            font-weight: 700;
          }
          .report-meta {
            opacity: 0.9;
            font-size: 14px;
          }
          .report-message {
            background: white;
            padding: 30px;
            border-radius: 10px;
            margin: 30px 0;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1);
            border-left: 5px solid #004aad;
          }
          .section {
            margin-bottom: 40px;
            page-break-inside: avoid;
          }
          .section h2 {
            color: #004aad;
            border-bottom: 3px solid #004aad;
            padding-bottom: 10px;
            margin-bottom: 25px;
            font-size: 24px;
          }
          .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 30px;
          }
          .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border-top: 4px solid;
            transition: transform 0.3s ease;
          }
          .stat-card:hover {
            transform: translateY(-5px);
          }
          .stat-card.blue { border-top-color: #007bff; }
          .stat-card.green { border-top-color: #28a745; }
          .stat-card.yellow { border-top-color: #ffc107; }
          .stat-number {
            font-size: 42px;
            font-weight: bold;
            color: #004aad;
            margin: 15px 0;
          }
          .stat-label {
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 25px 0;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
          }
          th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e9ecef;
          }
          th {
            background: #004aad;
            color: white;
            font-weight: 600;
          }
          tr:hover {
            background: #f8f9fa;
          }
          .chart-placeholder {
            background: white;
            padding: 40px;
            text-align: center;
            margin: 25px 0;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: 2px dashed #e9ecef;
          }
          .signature-section {
            margin-top: 60px;
            padding-top: 30px;
            border-top: 2px solid #e9ecef;
          }
          @media print {
            body { margin: 20px; }
            .section { break-inside: avoid; }
            .stat-card { box-shadow: none; border: 1px solid #ddd; }
            table { box-shadow: none; }
          }
        </style>
      </head>
      <body>
        <div class="report-header">
          <h1>${title}</h1>
          <div class="report-meta">
            Generated on: ${currentDate} | MOP Maintenance Management System
          </div>
        </div>
    `;
    
    // Add custom message if provided and enabled
    if (message && includeSummary) {
      reportContent += `
        <div class="report-message">
          <h3 style="margin-top: 0; color: #004aad;">Executive Summary</h3>
          ${message.replace(/\n/g, '<br>')}
        </div>
      `;
    }
    
    // Add key statistics
    reportContent += `
      <div class="section">
        <h2>Key Performance Indicators</h2>
        <div class="stats-grid">
          <div class="stat-card blue">
            <div class="stat-label">Total Requests</div>
            <div class="stat-number">${document.querySelector('.card.blue .count').textContent}</div>
            <div>All maintenance requests</div>
          </div>
          <div class="stat-card green">
            <div class="stat-label">Completed Tasks</div>
            <div class="stat-number">${document.querySelector('.card.green .count').textContent}</div>
            <div>Successful repairs</div>
          </div>
          <div class="stat-card yellow">
            <div class="stat-label">Pending Tasks</div>
            <div class="stat-number">${document.querySelector('.card.yellow .count').textContent}</div>
            <div>In progress</div>
          </div>
        </div>
      </div>
    `;
    
    // Add department breakdown
    if (includeTables) {
      reportContent += `
        <div class="section">
          <h2>Department Performance</h2>
          <table>
            <thead>
              <tr>
                <th>Department</th>
                <th>Total Requests</th>
                <th>Percentage</th>
              </tr>
            </thead>
            <tbody>
      `;
      
      // Add department data
      const deptRows = document.querySelectorAll('.table-card.full-width tbody tr');
      deptRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        reportContent += `
          <tr>
            <td>${cells[0].textContent}</td>
            <td>${cells[1].textContent}</td>
            <td>${cells[2].querySelector('span').textContent}</td>
          </tr>
        `;
      });
      
      reportContent += `
            </tbody>
          </table>
        </div>
      `;
    }
    
    // Add top technicians
    if (includeTables) {
      reportContent += `
        <div class="section">
          <h2>Top Performing Technicians</h2>
          <table>
            <thead>
              <tr>
                <th>Technician</th>
                <th>Specialization</th>
                <th>Tasks Completed</th>
                <th>Rating</th>
              </tr>
            </thead>
            <tbody>
      `;
      
      const techRows = document.querySelectorAll('#topTechBody tr');
      techRows.forEach(row => {
        const cells = row.querySelectorAll('td');
        reportContent += `
          <tr>
            <td>${cells[0].textContent}</td>
            <td>${cells[1].textContent}</td>
            <td>${cells[2].textContent}</td>
            <td>${cells[3].textContent}</td>
          </tr>
        `;
      });
      
      reportContent += `
            </tbody>
          </table>
        </div>
      `;
    }
    
    // Add chart placeholders if charts are included
    if (includeCharts) {
      reportContent += `
        <div class="section">
          <h2>Visual Analysis</h2>
          <div class="chart-placeholder">
            📊 Charts and graphs would appear here in the digital version<br>
            <small>(Bar chart: Requests by Department | Pie chart: Request Types | Line chart: Monthly Trends)</small>
          </div>
        </div>
      `;
    }
    
    // Add signature section
    reportContent += `
        <div class="signature-section">
          <table style="width: 100%; border: none;">
            <tr>
              <td style="border: none; width: 50%;">
                <strong>Prepared by:</strong><br>
                Administrator<br>
                System Administrator
              </td>
              <td style="border: none; width: 50%; text-align: right;">
                <strong>Date:</strong><br>
                ${currentDate}<br>
                &nbsp;
              </td>
            </tr>
          </table>
        </div>
      </body>
      </html>
    `;
    
    // Write and print the report
    printWindow.document.write(reportContent);
    printWindow.document.close();
    printWindow.focus();
    
    setTimeout(() => {
      printWindow.print();
      // printWindow.close(); // Optional: close after printing
    }, 500);
    
    // Reset button
    generateBtn.innerHTML = originalHtml;
    generateBtn.disabled = false;
    
    // Close modal
    closeReportModal();
    
    // Show success notification
    showNotification('Report generated successfully! Opening print dialog...', 'success');
    
  }, 1500); // Simulate processing time
}

// ====== REAL-TIME UPDATES ======
function setupRealTimeUpdates() {
  setInterval(updateDashboardStats, 30000);
}

function updateDashboardStats() {
  fetch("../../backend/get_dashboard_stats.php")
    .then(res => res.json())
    .then(data => {
      const blueCard = document.querySelector(".card.blue .count");
      const greenCard = document.querySelector(".card.green .count");
      const yellowCard = document.querySelector(".card.yellow .count");
      
      if (blueCard) blueCard.innerText = data.total_requests || 0;
      if (greenCard) greenCard.innerText = data.completed_tasks || 0;
      if (yellowCard) yellowCard.innerText = data.pending_tasks || 0;
    })
    .catch(err => console.error("Error updating stats:", err));
}

function refreshAllData() {
  updateDashboardStats();
  
  const refreshBtn = document.querySelector('.btn-refresh');
  const originalText = refreshBtn.textContent;
  refreshBtn.innerHTML = '<span class="loading"></span> Refreshing...';
  refreshBtn.disabled = true;
  
  setTimeout(() => {
    refreshBtn.innerHTML = '<span class="btn-icon">🔄</span> Refresh Data';
    refreshBtn.disabled = false;
    showNotification('Data refreshed successfully!', 'success');
  }, 1000);
}

// ====== NOTIFICATION SYSTEM ======
function showNotification(message, type = 'info') {
  // Remove existing notifications
  const existingNotifications = document.querySelectorAll('.notification');
  existingNotifications.forEach(notification => notification.remove());
  
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    background: ${type === 'success' ? '#28a745' : '#007bff'};
    color: white;
    border-radius: 10px;
    z-index: 10000;
    box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    animation: slideInRight 0.3s ease;
    font-weight: 500;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOutRight 0.3s ease';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Add notification animations
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
  @keyframes slideInRight {
    from { transform: translateX(100%); opacity: 0; }
    to { transform: translateX(0); opacity: 1; }
  }
  @keyframes slideOutRight {
    from { transform: translateX(0); opacity: 1; }
    to { transform: translateX(100%); opacity: 0; }
  }
`;
document.head.appendChild(notificationStyles);