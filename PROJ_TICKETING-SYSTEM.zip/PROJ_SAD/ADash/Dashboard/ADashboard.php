<?php
session_start();
require '../../config/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
  header("Location: ../../auth/login.php");
  exit;
}

// === FETCH COUNTS ===
$totalRequests = $conn->query("SELECT COUNT(*) FROM user_requests")->fetchColumn();
$completedTasks = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status = 'Completed'")->fetchColumn();
$pendingTasks   = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status IN ('Pending','Assigned','In Progress')")->fetchColumn();

// === REQUESTS PER DEPARTMENT ===
$deptData = $conn->query("
  SELECT department, COUNT(*) as total 
  FROM user_requests 
  GROUP BY department
")->fetchAll(PDO::FETCH_ASSOC);

// === REQUEST TYPES PIE ===
$typeData = $conn->query("
  SELECT 
    unit_name AS type,
    COUNT(*) AS total
  FROM user_requests
  GROUP BY unit_name
")->fetchAll(PDO::FETCH_ASSOC);

// === TOP TECHNICIANS ===
$topTechs = $conn->query("
  SELECT fname, lname, specialization, tasks_completed, rating
  FROM technicians
  ORDER BY tasks_completed DESC
  LIMIT 3
")->fetchAll(PDO::FETCH_ASSOC);

// === RECENT ACTIVITY ===
$recent = $conn->query("
  SELECT ur.id, ur.request_details, ur.status, ur.created_at, t.fname, t.lname
  FROM user_requests ur
  LEFT JOIN technicians t ON ur.tech_id = t.tech_id
  ORDER BY ur.created_at DESC
  LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// === INVENTORY DATA ===
try {
    $inventoryData = $conn->query("
        SELECT 
            category,
            COUNT(*) as item_count
        FROM inventory
        GROUP BY category
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $inventoryData = [];
}

// === MONTHLY REQUEST TRENDS ===
$monthlyTrends = $conn->query("
  SELECT 
    DATE_FORMAT(created_at, '%Y-%m') as month,
    COUNT(*) as request_count
  FROM user_requests 
  WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
  GROUP BY DATE_FORMAT(created_at, '%Y-%m')
  ORDER BY month DESC
  LIMIT 12
")->fetchAll(PDO::FETCH_ASSOC);

// === GET INVENTORY STATUS COUNTS ===
try {
    $inventoryStatus = $conn->query("
        SELECT 
            status,
            COUNT(*) as count
        FROM inventory
        GROUP BY status
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $inventoryStatus = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="ADashboard.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
  <script src="ADashboard.js"></script>
</head>
<body>
<div class="page-container">
  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li class="active"><a href="../../Dashboard/ADashboard.php">
        <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
        Dashboard
      </a></li>
      <li><a href="../Update/ARequest.php">
        <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
        Requests
      </a></li>
      <li><a href="../Users/AUsers.php">
        <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
        Users
      </a></li>
      <li><a href="../Technicians/ATechnicians.php">
        <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
        Technician
      </a></li>
      <li><a href="../Inventory/AInventory.php">
        <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
        Inventory
      </a></li>
      <li class="logout"><a href="../../auth/logout.php">
        <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
        Logout
      </a></li>
    </ul>
  </aside>

  <!-- MAIN CONTENT -->
  <main class="main-content">
    <header>
      <h1>Admin Dashboard</h1>
      <div class="header-actions">
        <button onclick="refreshAllData()" class="btn btn-refresh">
          <span class="btn-icon">🔄</span>
          Refresh Data
        </button>
        <button onclick="openReportModal()" class="btn btn-report">
          <span class="btn-icon">📊</span>
          Generate Report
        </button>
      </div>
    </header>

<!-- BEAUTIFUL REPORT MODAL -->
<div id="reportModal" class="modal">
  <div class="modal-content report-modal">
    <div class="modal-header">
      <div class="modal-title">
        <div class="modal-icon">📋</div>
        <h2>Create Professional Report</h2>
      </div>
      <span class="close" onclick="closeReportModal()">&times;</span>
    </div>
    
    <div class="modal-body">
      <div class="form-group">
        <label for="reportTitle" class="form-label">
          <span class="label-icon">📝</span>
          Report Title
        </label>
        <input type="text" id="reportTitle" class="form-input" 
               placeholder="Enter report title" 
               value="Monthly Maintenance Performance Report">
      </div>
      
      <div class="form-group">
        <label for="reportMessage" class="form-label">
          <span class="label-icon">💬</span>
          Executive Summary
        </label>
        <textarea id="reportMessage" class="form-textarea" 
                  placeholder="Type your custom analysis, observations, or recommendations here... This message will appear at the top of your report."
                  rows="6"></textarea>
        <div class="char-count">
          <span id="charCount">0</span> characters
        </div>
      </div>
      
      <div class="form-section">
        <h3 class="section-title">
          <span class="section-icon">⚙️</span>
          Report Options
        </h3>
        <div class="options-grid">
          <label class="option-checkbox">
            <input type="checkbox" id="includeCharts" checked>
            <span class="checkmark"></span>
            <span class="option-text">
              <span class="option-title">Include Charts & Graphs</span>
              <span class="option-desc">Visual data representations</span>
            </span>
          </label>
          
          <label class="option-checkbox">
            <input type="checkbox" id="includeTables" checked>
            <span class="checkmark"></span>
            <span class="option-text">
              <span class="option-title">Include Data Tables</span>
              <span class="option-desc">Detailed statistics and lists</span>
            </span>
          </label>
          
          <label class="option-checkbox">
            <input type="checkbox" id="includeSummary" checked>
            <span class="checkmark"></span>
            <span class="option-text">
              <span class="option-title">Include Executive Summary</span>
              <span class="option-desc">Key findings and recommendations</span>
            </span>
          </label>
        </div>
      </div>
    </div>
    
    <div class="modal-footer">
      <div class="footer-actions">
        <button onclick="closeReportModal()" class="btn btn-secondary">
          <span class="btn-icon">❌</span>
          Cancel
        </button>
        <button onclick="generateReport()" class="btn btn-primary">
          <span class="btn-icon">🖨️</span>
          Print Report
        </button>
      </div>
    </div>
  </div>
</div>
    <!-- SUMMARY CARDS -->
    <section class="dashboard-section">
      <h2>Key Statistics</h2>
      <div class="summary-section">
        <div class="card blue">
          <h3>TOTAL REQUESTS</h3>
          <p class="count"><?= $totalRequests ?></p>
          <span>Total maintenance requests</span>
        </div>
        <div class="card green">
          <h3>COMPLETED TASKS</h3>
          <p class="count"><?= $completedTasks ?></p>
          <span>Repairs completed</span>
        </div>
        <div class="card yellow">
          <h3>PENDING / ONGOING</h3>
          <p class="count"><?= $pendingTasks ?></p>
          <span>Still in process</span>
        </div>
        <?php if (!empty($inventoryStatus)): ?>
        <div class="card red">
          <h3>TOTAL INVENTORY</h3>
          <p class="count"><?= array_sum(array_column($inventoryStatus, 'count')) ?></p>
          <span>Items in inventory</span>
        </div>
        <?php endif; ?>
      </div>
    </section>

    <!-- CHARTS ROW 1 -->
    <section class="dashboard-section">
      <h2>Request Analysis</h2>
      <div class="charts-row">
        <div class="chart-card large">
          <h3>Requests by Department</h3>
          <canvas id="chartDepartment"></canvas>
        </div>
        <div class="chart-card small">
          <h3>Request Types Distribution</h3>
          <canvas id="chartTypes"></canvas>
        </div>
      </div>
    </section>

    <!-- CHARTS ROW 2 -->
    <section class="dashboard-section">
      <h2>Trends & Inventory</h2>
      <div class="charts-row">
        <div class="chart-card large">
          <h3>Monthly Request Trends</h3>
          <canvas id="chartTrends"></canvas>
        </div>
        <?php if (!empty($inventoryData)): ?>
        <div class="chart-card small">
          <h3>Inventory by Category</h3>
          <canvas id="chartInventory"></canvas>
        </div>
        <?php endif; ?>
      </div>
    </section>

    <!-- PERFORMANCE DATA -->
    <section class="dashboard-section">
      <h2>Performance Overview</h2>
      <div class="lower-section">
        <div class="table-card">
          <h3>Top Performing Technicians</h3>
          <table>
            <thead>
              <tr>
                <th>Full Name</th>
                <th>Specialization</th>
                <th>Tasks Completed</th>
                <th>Rating</th>
              </tr>
            </thead>
            <tbody id="topTechBody">
              <?php foreach ($topTechs as $t): ?>
                <tr>
                  <td><?= htmlspecialchars($t['fname'] . ' ' . $t['lname']) ?></td>
                  <td><?= htmlspecialchars($t['specialization']) ?></td>
                  <td><?= htmlspecialchars($t['tasks_completed']) ?></td>
                  <td><?= htmlspecialchars($t['rating']) ?> ⭐</td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <div class="activity-card">
          <h3>Recent Activity</h3>
          <ul id="recentActivity">
            <?php foreach ($recent as $r): ?>
              <li>
                <b><?= htmlspecialchars($r['request_details']) ?></b><br>
                <small>Status: <?= htmlspecialchars($r['status']) ?> — <?= htmlspecialchars($r['fname'].' '.$r['lname']) ?></small>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    </section>

    <!-- DEPARTMENT BREAKDOWN -->
    <section class="dashboard-section">
      <h2>Department Performance</h2>
      <div class="table-card full-width">
        <table>
          <thead>
            <tr>
              <th>Department</th>
              <th>Total Requests</th>
              <th>Percentage</th>
              <th>Status Overview</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $totalDeptRequests = array_sum(array_column($deptData, 'total'));
            foreach ($deptData as $dept): 
              $percentage = $totalDeptRequests > 0 ? round(($dept['total'] / $totalDeptRequests) * 100, 1) : 0;
            ?>
              <tr>
                <td><?= htmlspecialchars($dept['department']) ?></td>
                <td><?= htmlspecialchars($dept['total']) ?></td>
                <td>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: <?= $percentage ?>%"></div>
                    <span><?= $percentage ?>%</span>
                  </div>
                </td>
                <td>
                  <?php 
                  // Get department status breakdown
                  $statusData = $conn->query("
                    SELECT status, COUNT(*) as count 
                    FROM user_requests 
                    WHERE department = '" . $dept['department'] . "'
                    GROUP BY status
                  ")->fetchAll(PDO::FETCH_ASSOC);
                  
                  $statusText = [];
                  foreach ($statusData as $status) {
                    $statusText[] = $status['status'] . ': ' . $status['count'];
                  }
                  echo implode(', ', $statusText);
                  ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <!-- INVENTORY SUMMARY -->
    <?php if (!empty($inventoryData)): ?>
    <section class="dashboard-section">
      <h2>Inventory Summary</h2>
      <div class="table-card full-width">
        <h3>Inventory by Category</h3>
        <table>
          <thead>
            <tr>
              <th>Category</th>
              <th>Item Count</th>
              <th>Percentage</th>
            </tr>
          </thead>
          <tbody>
            <?php 
            $totalItems = array_sum(array_column($inventoryData, 'item_count'));
            foreach ($inventoryData as $item): 
              $percentage = $totalItems > 0 ? round(($item['item_count'] / $totalItems) * 100, 1) : 0;
            ?>
              <tr>
                <td><?= htmlspecialchars($item['category']) ?></td>
                <td><?= htmlspecialchars($item['item_count']) ?></td>
                <td>
                  <div class="progress-bar">
                    <div class="progress-fill" style="width: <?= $percentage ?>%"></div>
                    <span><?= $percentage ?>%</span>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
    <?php endif; ?>
  </main>
</div>

<script>
// Chart data from PHP
const deptLabels = <?= json_encode(array_column($deptData, 'department')) ?>;
const deptCounts = <?= json_encode(array_column($deptData, 'total')) ?>;
const typeLabels = <?= json_encode(array_column($typeData, 'type')) ?>;
const typeCounts = <?= json_encode(array_column($typeData, 'total')) ?>;
const trendMonths = <?= json_encode(array_column($monthlyTrends, 'month')) ?>;
const trendCounts = <?= json_encode(array_column($monthlyTrends, 'request_count')) ?>;

// Initialize charts when page loads
document.addEventListener('DOMContentLoaded', function() {
  initializeCharts();
});

function initializeCharts() {
  // Department Chart
  new Chart(document.getElementById('chartDepartment'), {
    type: 'bar',
    data: {
      labels: deptLabels,
      datasets: [{
        label: 'Requests',
        data: deptCounts,
        backgroundColor: '#004aad'
      }]
    },
    options: { 
      responsive: true, 
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } } 
    }
  });

  // Request Types Chart
  new Chart(document.getElementById('chartTypes'), {
    type: 'pie',
    data: {
      labels: typeLabels,
      datasets: [{
        data: typeCounts,
        backgroundColor: ['#0066ff', '#66ccff', '#ff9933', '#cc00ff', '#00cc99', '#ff6666']
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'right' } }
    }
  });

  // Trends Chart
  new Chart(document.getElementById('chartTrends'), {
    type: 'line',
    data: {
      labels: trendMonths,
      datasets: [{
        label: 'Monthly Requests',
        data: trendCounts,
        borderColor: '#ff6666',
        backgroundColor: 'rgba(255, 102, 102, 0.1)',
        tension: 0.3,
        fill: true
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });

  <?php if (!empty($inventoryData)): ?>
  // Inventory Chart
  const inventoryLabels = <?= json_encode(array_column($inventoryData, 'category')) ?>;
  const inventoryCounts = <?= json_encode(array_column($inventoryData, 'item_count')) ?>;
  new Chart(document.getElementById('chartInventory'), {
    type: 'bar',
    data: {
      labels: inventoryLabels,
      datasets: [{
        label: 'Items',
        data: inventoryCounts,
        backgroundColor: '#00cc99'
      }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
  <?php endif; ?>
}
</script>
</body>
</html>