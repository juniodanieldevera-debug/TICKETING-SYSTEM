<?php
session_start();
require_once '../../config/db_connect.php';

// Admin protection
if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit();
}

// ===================== HANDLE ADD ITEM =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item'])) {
    $name = trim($_POST['name']);
    $unit = trim($_POST['unit_number']);
    $category = trim($_POST['category']);
    $supplier = trim($_POST['supplier']);
    $stock = (int)$_POST['stock'];

    $status = 'Available';
    if ($stock <= 0) $status = 'Out of Stock';
    if ($stock > 0 && $stock < 5) $status = 'Low';

     $ins = $conn->prepare("INSERT INTO inventory (name, unit_number, category, supplier, status, stock) VALUES (?, ?, ?, ?, ?, ?)");
    $ins->execute([$name, $unit, $category, $supplier, $status, $stock]);

    $item_id = $conn->lastInsertId();
    // Log addition in inventory_reports
    $log = $conn->prepare("INSERT INTO inventory_reports (item_id, tech_id, action, quantity) VALUES (?, NULL, 'Added', ?)");
    $log->execute([$item_id, $stock]);

    header("Location: AInventory.php");
    exit();
}

// ===================== HANDLE EDIT ITEM =====================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_item'])) {
    $id = (int)$_POST['item_id'];
    $name = trim($_POST['name']);
    $unit = trim($_POST['unit_number']);
    $category = trim($_POST['category']);
    $supplier = trim($_POST['supplier']);
    $stock = (int)$_POST['stock'];

    $status = 'Available';
    if ($stock <= 0) $status = 'Out of Stock';
    if ($stock > 0 && $stock < 5) $status = 'Low';

    $upd = $conn->prepare("UPDATE inventory SET name=?, unit_number=?, category=?, supplier=?, status=?, stock=? WHERE item_id=?");
    $upd->execute([$name, $unit, $category, $supplier, $status, $stock, $id]);

    $log = $conn->prepare("INSERT INTO inventory_reports (item_id, tech_id, action, quantity) VALUES (?, NULL, 'Updated', ?)");
    $log->execute([$id, $stock]);

    header("Location: AInventory.php");
}

// ===================== HANDLE DELETE ITEM =====================
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];

    // 1️⃣ LOG FIRST
    $log = $conn->prepare("INSERT INTO inventory_reports (item_id, tech_id, action, quantity) VALUES (?, NULL, 'Deleted', NULL)");
    $log->execute([$id]);

    // 2️⃣ THEN DELETE
    $dstmt = $conn->prepare("DELETE FROM inventory WHERE item_id = ?");
    $dstmt->execute([$id]);

    // redirect
    header("Location: AInventory.php");
    exit();
}


// ===================== FETCH INVENTORY =====================
$search = $_GET['q'] ?? '';
$filter_cat = $_GET['cat'] ?? '';

$sql = "SELECT * FROM inventory WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
}
if ($filter_cat !== '') {
    $sql .= " AND category = ?";
    $params[] = $filter_cat;
}

$sql .= " ORDER BY created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// fetch categories
$catStmt = $conn->prepare("SELECT DISTINCT category FROM inventory WHERE category IS NOT NULL");
$catStmt->execute();
$cats = $catStmt->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Inventory</title>
    <link rel="stylesheet" href="AInventory.css?v=<?= time() ?>">
</head>
<body>
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li><a href="../Dashboard/ADashboard.php">
        <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
        Dashboard
      </a></li>
      <li><a href="../Update/ARequest.php">
        <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
        Requests
      </a></li>
      <li><a href="../Users/AUsers.php">
        <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
        Users
      </a></li>
      <li><a href="../Technicians/ATechnicians.php">
        <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
        Technician
      </a></li>
      <li  class="active"><a href="../Inventory/AInventory.php">
        <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
        Inventory
      </a></li>
      <li class="logout"><a href="../../auth/logout.php">
        <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
        Logout
      </a></li>
    </ul>
  </aside>

<div class="admin-content">
    <div class="header">
        <h1>MATERIAL INVENTORY</h1>
        <div class="actions">
            <button class="btn primary" id="addButton">ADD ITEM</button>
        </div>
    </div>

    <div class="tabs">
        <a class="tab active" href="AInventory.php">MATERIAL INVENTORY</a>
        <a class="tab" href="AMaterial_Request.php">MATERIAL REQUESTS</a>
        <a class="tab" href="AMaterial_Reports.php">MATERIAL REPORTS</a>
    </div>

    <div class="toolbar">
        <form method="GET" class="search-form">
            <input type="text" name="q" placeholder="Search item..." value="<?= htmlspecialchars($search) ?>">
            <select name="cat">
                <option value="">All Categories</option>
                <?php foreach($cats as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>" <?= $filter_cat===$c ? 'selected' : '' ?>><?= htmlspecialchars($c) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="table-wrap">
        <table class="inventory-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>NAME</th>
                    <th>UNIT NO.</th>
                    <th>CATEGORY</th>
                    <th>SUPPLIER</th>
                    <th>STATUS</th>
                    <th>STOCK</th>
                    <th>ACTIONS</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($items)): ?>
                <tr><td colspan="8" style="text-align:center">No items found.</td></tr>
                <?php else: foreach ($items as $it): ?>
                <tr>
                    <td><?= $it['item_id'] ?></td>
                    <td><?= htmlspecialchars($it['name']) ?></td>
                    <td><?= htmlspecialchars($it['unit_number']) ?></td>
                    <td><?= htmlspecialchars($it['category']) ?></td>
                    <td><?= htmlspecialchars($it['supplier']) ?></td>
                    <td><?= $it['status'] ?></td>
                    <td><?= $it['stock'] ?></td>
                    <td class="actions-td">
                        <button class="btn small editBtn"
                            data-id="<?= $it['item_id'] ?>"
                            data-name="<?= htmlspecialchars($it['name']) ?>"
                            data-unit="<?= htmlspecialchars($it['unit_number']) ?>"
                            data-category="<?= htmlspecialchars($it['category']) ?>"
                            data-supplier="<?= htmlspecialchars($it['supplier']) ?>"
                            data-stock="<?= htmlspecialchars($it['stock']) ?>">
                            Edit
                        </button>
                        <a class="btn small danger" href="AInventory.php?delete=<?= $it['item_id'] ?>" onclick="return confirm('Delete this item?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- ===================== EDIT ITEM POP-UP ===================== -->
<div id="editModal" class="modal-bg">
    <div class="modal-form">
        <h2>Edit Item</h2>

        <form method="POST">
            <input type="hidden" name="edit_item" value="1">
            <input type="hidden" name="item_id" id="edit_id">

            <label>Item Name</label>
            <input name="name" id="edit_name" required>

            <label>Unit Number</label>
            <input name="unit_number" id="edit_unit">

            <label>Category</label>
            <input name="category" id="edit_category">

            <label>Supplier</label>
            <input name="supplier" id="edit_supplier">

            <label>Stock</label>
            <input type="number" name="stock" id="edit_stock" min="0">

            <div style="margin-top:18px; display:flex; gap:10px; justify-content:flex-end;">
                <button class="btn primary" type="submit">Save Changes</button>
                <button type="button" class="btn" id="closeEdit">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- ===================== ADD ITEM POP-UP ===================== -->
<div id="addModal" class="modal-bg">
    <div class="modal-form">
        <h2>Add New Item</h2>

        <form method="POST">
            <input type="hidden" name="add_item" value="1">

            <label>Item Name</label>
            <input name="name" required>

            <label>Unit Number</label>
            <input name="unit_number">

            <label>Category</label>
            <input name="category">

            <label>Supplier</label>
            <input name="supplier">

            <label>Stock</label>
            <input type="number" name="stock" min="0">

            <div style="margin-top:18px; display:flex; gap:10px; justify-content:flex-end;">
                <button class="btn primary" type="submit">Add Item</button>
                <button type="button" class="btn" id="closeAdd">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
// ==== OPEN EDIT POPUP ====
document.querySelectorAll(".editBtn").forEach(btn => {
    btn.addEventListener("click", () => {
        document.getElementById("edit_id").value = btn.dataset.id;
        document.getElementById("edit_name").value = btn.dataset.name;
        document.getElementById("edit_unit").value = btn.dataset.unit;
        document.getElementById("edit_category").value = btn.dataset.category;
        document.getElementById("edit_supplier").value = btn.dataset.supplier;
        document.getElementById("edit_stock").value = btn.dataset.stock;

        document.getElementById("editModal").style.display = "flex";
    });
});

// ==== OPEN ADD POP-UP ====
document.getElementById("addButton")?.addEventListener("click", () => {
    document.getElementById("addModal").style.display = "flex";
});

// ==== CLOSE POPUPS ====
document.getElementById("closeEdit").onclick = () => {
    document.getElementById("editModal").style.display = "none";
};
document.getElementById("closeAdd").onclick = () => {
    document.getElementById("addModal").style.display = "none";
};

// ==== ADD ITEM ====
document.querySelector("#addModal form").addEventListener("submit", async function(e){
    e.preventDefault();
    const formData = new FormData(this);

    Swal.fire({
        title: 'Add this item?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, add it!',
        cancelButtonText: 'Cancel'
    }).then(async (result) => {
        if(result.isConfirmed){
            try {
                const res = await fetch('AInventory.php', {
                    method: 'POST',
                    body: formData
                });
                const text = await res.text();
                Swal.fire('Added!', 'Item successfully added.', 'success').then(()=> location.reload());
            } catch(err) {
                console.error(err);
                Swal.fire('Error', 'Unable to add item.', 'error');
            }
        }
    });
});

// ==== EDIT ITEM ====
document.querySelector("#editModal form").addEventListener("submit", async function(e){
    e.preventDefault();
    const formData = new FormData(this);

    Swal.fire({
        title: 'Save changes?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, save!',
        cancelButtonText: 'Cancel'
    }).then(async (result) => {
        if(result.isConfirmed){
            try {
                const res = await fetch('AInventory.php', {
                    method: 'POST',
                    body: formData
                });
                const text = await res.text();
                Swal.fire('Saved!', 'Item successfully updated.', 'success').then(()=> location.reload());
            } catch(err) {
                console.error(err);
                Swal.fire('Error', 'Unable to update item.', 'error');
            }
        }
    });
});

// ==== DELETE ITEM ====
document.querySelectorAll(".btn.danger").forEach(btn => {
    btn.addEventListener("click", async function(e){
        e.preventDefault();
        const href = btn.getAttribute("href");

        Swal.fire({
            title: 'Delete this item?',
            text: "This action cannot be undone!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete!',
            cancelButtonText: 'Cancel'
        }).then(async (result) => {
            if(result.isConfirmed){
                try {
                    const res = await fetch(href, { method: 'GET' });
                    const text = await res.text();
                    Swal.fire('Deleted!', 'Item successfully deleted.', 'success').then(()=> location.reload());
                } catch(err) {
                    console.error(err);
                    Swal.fire('Error', 'Unable to delete item.', 'error');
                }
            }
        });
    });
});
</script>

</body>
</html>
