<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit();
}

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header("Location: AInventory.php"); exit(); }

$stmt = $conn->prepare("SELECT * FROM inventory WHERE item_id = ?");
$stmt->execute([$id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$item) { die("Item not found"); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $unit = trim($_POST['unit_number']);
    $category = trim($_POST['category']);
    $supplier = trim($_POST['supplier']);
    $stock = (int)$_POST['stock'];
    $status = 'Available';
    if ($stock <= 0) $status = 'Out of Stock';
    if ($stock > 0 && $stock < 5) $status = 'Low';

    $upd = $conn->prepare("UPDATE inventory SET name=?, unit_number=?, category=?, supplier=?, status=?, stock=? WHERE item_id=?");
    $upd->execute([$name, $unit, $category, $supplier, $status, $stock, $id]);

    // log update
    $log = $conn->prepare("INSERT INTO inventory_reports (item_id, tech_id, action, quantity, note) VALUES (?, NULL, 'Updated', ?, ?)");
    $log->execute([$id, $stock, "Updated by admin {$_SESSION['account_id']}"]);

    header("Location: AInventory.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Item</title>
    <link rel="stylesheet" href="AInventory.css">
</head>
<body>
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li ><a href="../Dashboard/ADashboard.php">
        <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
        Dashboard
      </a></li>
      <li><a href="../Update/ARequest.php">
        <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
        Requests
      </a></li>
      <li><a href="../Users/AUsers.php">
        <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
        Users
      </a></li>
      <li><a href="../Technicians/ATechnicians.php">
        <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
        Technician
      </a></li>
      <li class="active"><a href="../Inventory/AInventory.php">
        <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
        Inventory
      </a></li>
      <li class="logout"><a href="../../auth/logout.php">
        <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
        Logout
      </a></li>
    </ul>
  </aside>

<div class="admin-content">
    <div class="header"><h1>EDIT ITEM</h1></div>

    <form method="POST" class="form-card">
        <label>Item Name</label>
        <input name="name" value="<?= htmlspecialchars($item['name']) ?>" required>

        <label>Unit Number</label>
        <input name="unit_number" value="<?= htmlspecialchars($item['unit_number']) ?>">

        <label>Category</label>
        <input name="category" value="<?= htmlspecialchars($item['category']) ?>">

        <label>Supplier</label>
        <input name="supplier" value="<?= htmlspecialchars($item['supplier']) ?>">

        <label>Stock</label>
        <input name="stock" type="number" value="<?= (int)$item['stock'] ?>" min="0">

        <button class="btn primary" type="submit">Save Changes</button>
        <a class="btn" href="AInventory.php">Cancel</a>
    </form>
</div>
</body>
</html>
