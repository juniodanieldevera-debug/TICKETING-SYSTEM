<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit();
}

// optional filters
$item = $_GET['item'] ?? '';
$action = $_GET['action'] ?? '';

$sql = "SELECT ir.*, inv.name as item_name, t.fname, t.lname
        FROM inventory_reports ir
        LEFT JOIN inventory inv ON inv.item_id = ir.item_id
        LEFT JOIN technicians t ON t.tech_id = ir.tech_id
        WHERE 1=1";
$params = [];
if ($item !== '') { $sql .= " AND inv.item_id = ?"; $params[] = $item; }
if ($action !== '') { $sql .= " AND ir.action = ?"; $params[] = $action; }
$sql .= " ORDER BY ir.created_at DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

// item list for filter
$iStmt = $conn->prepare("SELECT item_id, name FROM inventory ORDER BY name");
$iStmt->execute();
$items = $iStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Material Reports</title>
    <link rel="stylesheet" href="AInventory.css">
</head>
<body>
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li><a href="../Dashboard/ADashboard.php">
        <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
        Dashboard
      </a></li>
      <li><a href="../Update/ARequest.php">
        <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
        Requests
      </a></li>
      <li><a href="../Users/AUsers.php">
        <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
        Users
      </a></li>
      <li><a href="../Technicians/ATechnicians.php">
        <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
        Technician
      </a></li>
      <li class="active"><a href="../Inventory/AInventory.php">
        <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
        Inventory
      </a></li>
      <li class="logout"><a href="../../auth/logout.php">
        <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
        Logout
      </a></li>
    </ul>
  </aside>

<div class="admin-content">
    <div class="header"><h1>MATERIAL REPORTS</h1></div>

    <!-- ADDED TABS -->
    <div class="tabs">
        <a class="tab" href="AInventory.php">MATERIAL INVENTORY</a>
        <a class="tab" href="AMaterial_Request.php">MATERIAL REQUESTS</a>
        <a class="tab active" href="AMaterial_Reports.php">MATERIAL REPORTS</a>
    </div>

    <div class="toolbar">
        <form method="GET" class="search-form">
            <select name="item">
                <option value="">All Items</option>
                <?php foreach($items as $it): ?>
                    <option value="<?= $it['item_id'] ?>" <?= ($item == $it['item_id']) ? 'selected' : '' ?>><?= htmlspecialchars($it['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="action">
                <option value="">All Actions</option>
                <option value="Added" <?= $action=='Added' ? 'selected' : '' ?>>Added</option>
                <option value="Updated" <?= $action=='Updated' ? 'selected' : '' ?>>Updated</option>
                <option value="Withdrawn" <?= $action=='Withdrawn' ? 'selected' : '' ?>>Withdrawn</option>
                <option value="Returned" <?= $action=='Returned' ? 'selected' : '' ?>>Returned</option>
                <option value="Deleted" <?= $action=='Deleted' ? 'selected' : '' ?>>Deleted</option>
            </select>

            <button type="submit">Filter</button>
        </form>
    </div>

    <div class="table-wrap">
        <table class="inventory-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ITEM</th>
                    <th>ACTION</th>
                    <th>QTY</th>
                    <th>TECHNICIAN</th>
                    <th>NOTE</th>
                    <th>DATE</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($reports)): ?>
                    <tr><td colspan="7" style="text-align:center">No reports found.</td></tr>
                <?php else: foreach($reports as $rep): ?>
                    <tr>
                        <td><?= $rep['report_id'] ?></td>
                        <td><?= htmlspecialchars($rep['item_name'] ?? 'N/A') ?></td>
                        <td><span class="status-badge status-<?= $rep['action'] ?>"><?= $rep['action'] ?></span></td>
                        <td><?= htmlspecialchars($rep['quantity'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars(($rep['fname'] ?? '') . ' ' . ($rep['lname'] ?? '') ?: 'N/A') ?></td>
                        <td><?= htmlspecialchars($rep['note'] ?? 'No note') ?></td>
                        <td><?= date('M j, Y g:i A', strtotime($rep['created_at'])) ?></td>
                    </tr>
                <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>