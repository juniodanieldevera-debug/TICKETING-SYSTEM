<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit();
}

// fetch pending requests - UPDATED to include reason
$stmt = $conn->prepare("
    SELECT mr.*, t.fname, t.lname, inv.name as item_name, inv.stock
    FROM material_requests mr
    JOIN technicians t ON t.tech_id = mr.tech_id
    JOIN inventory inv ON inv.item_id = mr.item_id
    ORDER BY mr.created_at DESC
");
$stmt->execute();
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

// handle approve/reject
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rid = (int)$_POST['request_id'];
    $action = $_POST['action']; // Approve or Reject

    // fetch request
    $q = $conn->prepare("SELECT * FROM material_requests WHERE request_id = ?");
    $q->execute([$rid]);
    $r = $q->fetch(PDO::FETCH_ASSOC);
    if (!$r) { header("Location: AMaterial_Request.php"); exit(); }

    if ($action === 'approve') {
        // check stock
        $itemQ = $conn->prepare("SELECT stock FROM inventory WHERE item_id = ?");
        $itemQ->execute([$r['item_id']]);
        $it = $itemQ->fetch(PDO::FETCH_ASSOC);
        $available = (int)$it['stock'];

        if ($available >= $r['quantity']) {
            // decrement stock
            $newStock = $available - (int)$r['quantity'];
            $u = $conn->prepare("UPDATE inventory SET stock = ?, status = ? WHERE item_id = ?");
            $status = $newStock <= 0 ? 'Out of Stock' : ($newStock < 5 ? 'Low' : 'Available');
            $u->execute([$newStock, $status, $r['item_id']]);

            // update request
            $upd = $conn->prepare("UPDATE material_requests SET status = 'Approved' WHERE request_id = ?");
            $upd->execute([$rid]);

            // log withdrawal - FIXED: Check if note column exists
            $columns = "item_id, tech_id, action, quantity";
            $values = "?, ?, 'Withdrawn', ?";
            
            // Create note with reason if available
            $note = "Approved material request #$rid";
            if (isset($r['reason']) && !empty($r['reason'])) {
                $note .= " - Reason: " . $r['reason'];
            }
            
            // Try to insert with note if column exists, otherwise without
            try {
                $log = $conn->prepare("INSERT INTO inventory_reports ($columns, note) VALUES ($values, ?)");
                $log->execute([$r['item_id'], $r['tech_id'], $r['quantity'], $note]);
            } catch (PDOException $e) {
                // If note column doesn't exist, insert without it
                $log = $conn->prepare("INSERT INTO inventory_reports ($columns) VALUES ($values)");
                $log->execute([$r['item_id'], $r['tech_id'], $r['quantity']]);
            }

            header("Location: AMaterial_Request.php?success=approved");
            exit();
        } else {
            // insufficient stock
            $upd = $conn->prepare("UPDATE material_requests SET status = 'Rejected' WHERE request_id = ?");
            $upd->execute([$rid]);
            header("Location: AMaterial_Request.php?error=insufficient_stock");
            exit();
        }
    } else { // reject
        $upd = $conn->prepare("UPDATE material_requests SET status = 'Rejected' WHERE request_id = ?");
        $upd->execute([$rid]);
        header("Location: AMaterial_Request.php?success=rejected");
        exit();
    }
}

// Check if reason column exists in material_requests table
$columnCheck = $conn->query("SHOW COLUMNS FROM material_requests LIKE 'reason'");
$reasonColumnExists = $columnCheck->rowCount() > 0;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Material Requests</title>
    <link rel="stylesheet" href="AInventory.css">
</head>
<body>
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li ><a href="../Dashboard/ADashboard.php">
        <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
        Dashboard
      </a></li>
      <li><a href="../Update/ARequest.php">
        <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
        Requests
      </a></li>
      <li><a href="../Users/AUsers.php">
        <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
        Users
      </a></li>
      <li><a href="../Technicians/ATechnicians.php">
        <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
        Technician
      </a></li>
      <li class="active"><a href="../Inventory/AInventory.php">
        <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
        Inventory
      </a></li>
      <li class="logout"><a href="../../auth/logout.php">
        <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
        Logout
      </a></li>
    </ul>
  </aside>

<div class="admin-content">
    <div class="header"><h1>MATERIAL REQUESTS</h1></div>

    <!-- ADDED TABS -->
    <div class="tabs">
        <a class="tab" href="AInventory.php">MATERIAL INVENTORY</a>
        <a class="tab active" href="AMaterial_Request.php">MATERIAL REQUESTS</a>
        <a class="tab" href="AMaterial_Reports.php">MATERIAL REPORTS</a>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert success">
            <?php 
            if ($_GET['success'] === 'approved') echo "Request approved successfully!";
            if ($_GET['success'] === 'rejected') echo "Request rejected successfully!";
            ?>
        </div>
    <?php endif; ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="alert error">
            <?php 
            if ($_GET['error'] === 'insufficient_stock') echo "Error: Insufficient stock to approve this request!";
            ?>
        </div>
    <?php endif; ?>

    <div class="requests-list">
        <?php if (empty($requests)): ?>
            <div class="no-requests">
                <p>No material requests found.</p>
            </div>
        <?php else: foreach($requests as $r): ?>
            <div class="request-card">
                <div class="left">
                    <p class="meta">Requested on: <?= htmlspecialchars($r['created_at']) ?></p>
                    <h3><?= htmlspecialchars($r['item_name']) ?> (x<?= $r['quantity'] ?>)</h3>
                    <p><strong>Requested by:</strong> <?= htmlspecialchars($r['fname'].' '.$r['lname']) ?></p>
                    <p><strong>Current Stock:</strong> <?= $r['stock'] ?></p>
                    <?php if ($reasonColumnExists && isset($r['reason']) && !empty($r['reason'])): ?>
                        <p><strong>Reason:</strong> <?= htmlspecialchars($r['reason']) ?></p>
                    <?php endif; ?>
                </div>
                <div class="right">
                    <p><strong>Status:</strong> <span class="status-<?= strtolower($r['status']) ?>"><?= $r['status'] ?></span></p>
                    <?php if ($r['status'] === 'Pending'): ?>
                        <div class="action-buttons">
                            <button class="btn small primary assign-btn" 
                                    data-request-id="<?= $r['request_id'] ?>"
                                    data-item-name="<?= htmlspecialchars($r['item_name']) ?>"
                                    data-quantity="<?= $r['quantity'] ?>"
                                    data-technician="<?= htmlspecialchars($r['fname'].' '.$r['lname']) ?>"
                                    data-stock="<?= $r['stock'] ?>"
                                    data-reason="<?= htmlspecialchars($r['reason'] ?? 'No reason provided') ?>">
                                ASSIGN
                            </button>
                            <form method="POST" class="inline-form">
                                <input type="hidden" name="request_id" value="<?= $r['request_id'] ?>">
                                <button name="action" value="reject" class="btn small danger" onclick="return confirm('Reject this request?')">REJECT</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; endif; ?>
    </div>
</div>

<!-- Assign Modal -->
<div id="assignModal" class="modal-bg">
    <div class="modal-content">
        <h3>Assign Material Request</h3>
        <div id="requestDetails" class="request-details">
            <!-- Details will be populated by JavaScript -->
        </div>
        <form method="POST" id="assignForm">
            <input type="hidden" name="request_id" id="modalRequestId">
            <input type="hidden" name="action" value="approve">
            <div class="modal-actions">
                <button type="submit" class="btn primary">Confirm Assign</button>
                <button type="button" class="btn secondary" id="closeModal">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const assignBtns = document.querySelectorAll('.assign-btn');
    const modal = document.getElementById('assignModal');
    const requestDetails = document.getElementById('requestDetails');
    const modalRequestId = document.getElementById('modalRequestId');
    const closeModal = document.getElementById('closeModal');
    const assignForm = document.getElementById('assignForm');

    assignBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const requestId = this.dataset.requestId;
            const itemName = this.dataset.itemName;
            const quantity = this.dataset.quantity;
            const technician = this.dataset.technician;
            const stock = this.dataset.stock;
            const reason = this.dataset.reason;

            modalRequestId.value = requestId;
            
            let detailsHTML = `
                <p><strong>Item:</strong> ${itemName}</p>
                <p><strong>Quantity:</strong> ${quantity}</p>
                <p><strong>Requested by:</strong> ${technician}</p>
                <p><strong>Current Stock:</strong> ${stock}</p>
                <p><strong>Stock After Assignment:</strong> ${stock - quantity}</p>
            `;
            
            if (reason && reason !== 'No reason provided') {
                detailsHTML += `<p><strong>Reason:</strong> ${reason}</p>`;
            }
            
            requestDetails.innerHTML = detailsHTML;
            modal.style.display = 'flex';
        });
    });

    closeModal.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Prevent multiple submissions
    assignForm.addEventListener('submit', function() {
        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing...';
    });
});
</script>

</body>
</html>