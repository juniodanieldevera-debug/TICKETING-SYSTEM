// ==== MODAL CONTROL ====
function openAddModal() {
    document.getElementById("modalTitle").textContent = "Add Technician";
    document.getElementById("techForm").reset();
    document.getElementById("tech_id").value = "";
    document.getElementById("passwordField").required = true;
    document.getElementById("techModal").classList.add("show");
}

function openEditModal(id) {
    fetch(`get_technician.php?tech_id=${id}`)
        .then(res => res.json())
        .then(data => {
            const form = document.getElementById("techForm");
            form.tech_id.value = data.tech_id;
            form.fname.value = data.fname || '';
            document.getElementById("mname").value = data.mname || '';
            form.lname.value = data.lname || '';
            form.email.value = data.email || '';
            form.password.value = "";
            document.getElementById("passwordField").required = false;
            form.specialization.value = data.specialization || '';
            form.contact_no.value = data.contact_no || '';
            form.status.value = data.status || 'Available';

            document.getElementById("modalTitle").textContent = "Edit Technician";
            document.getElementById("techModal").classList.add("show");
        })
        .catch(error => {
            console.error('Error fetching technician:', error);
            Swal.fire('Error', 'Unable to load technician data.', 'error');
        });
}

function closeModal() {
    document.getElementById("techModal").classList.remove("show");
}

// ==== SAVE TECHNICIAN (ADD/EDIT) ====
document.getElementById("techForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    const formData = new FormData(this);

    if (!formData.get('specialization') || !formData.get('status')) {
        Swal.fire('Warning', 'Please select both specialization and status.', 'warning');
        return;
    }

    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to save this technician?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, save it!',
        cancelButtonText: 'Cancel'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                const res = await fetch("save_technician.php", {
                    method: "POST",
                    body: formData
                });
                const text = await res.text();
                Swal.fire('Saved!', text, 'success').then(() => location.reload());
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Unable to save technician.', 'error');
            }
        }
    });
});

// ==== SOFT DELETE TECHNICIAN ====
function deleteTech(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This technician will be deleted!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                const formData = new FormData();
                formData.append('tech_id', id);

                const res = await fetch("delete_technician.php", {
                    method: "POST",
                    body: formData
                });

                const text = await res.text();
                Swal.fire('Deleted!', text, 'success').then(() => location.reload());
            } catch (err) {
                console.error(err);
                Swal.fire('Error', 'Unable to delete technician.', 'error');
            }
        }
    });
}

// ==== SEARCH FUNCTION ====
function filterTechs() {
    const q = document.getElementById("searchInput").value.toLowerCase();
    document.querySelectorAll("#techTable tbody tr").forEach(tr => {
        tr.style.display = tr.textContent.toLowerCase().includes(q) ? "" : "none";
    });
}

// Close modal when clicking outside
window.onclick = e => {
    if (e.target == document.getElementById('techModal')) closeModal();
};
