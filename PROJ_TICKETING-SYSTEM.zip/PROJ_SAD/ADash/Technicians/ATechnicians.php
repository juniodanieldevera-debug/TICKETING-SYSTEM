<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
  header("Location: ../../auth/login.php");
  exit;
}
require_once '../../config/db_connect.php';

// ====== SUMMARY ======
try {
  $stmt = $conn->query("SELECT ROUND(AVG(rating),1) AS avg_rating, SUM(tasks_completed) AS total_tasks, SUM(working_hours) AS total_hours FROM technicians WHERE isDeleted = 1");
  $summary = $stmt->fetch(PDO::FETCH_ASSOC);
  $avg_rating = $summary['avg_rating'] ?? 0;
  $total_tasks = $summary['total_tasks'] ?? 0;
  $total_hours = $summary['total_hours'] ?? 0;

  $techs = $conn->query("SELECT * FROM technicians WHERE isDeleted = 1 ORDER BY date_registered DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) { die("Database Error: " . $e->getMessage()); }

$specializations = [
    'Computer Technician','Electrician','Carpenter','Aircon Technician','Plumber','Network Technician','General Maintenance'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Technician Management</title>
  <link rel="stylesheet" href="ATechnicians.css?v=<?= time() ?>">
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.all.min.js"></script>
  <style>
    .id-display-field {
      background: #e7f3ff;
      border: 2px solid #004aad;
      font-weight: bold;
      color: #004aad;
      cursor: not-allowed;
    }
    .id-info-text {
      font-size: 11px;
      color: #666;
      font-style: italic;
      margin-top: -10px;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>
<div class="page-container">
  <!-- SIDEBAR -->
  <aside class="sidebar">
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="MOP Logo">
      <h2>MOP ADMIN</h2>
    </div>
    <ul>
      <li><a href="../Dashboard/ADashboard.php"><img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">Dashboard</a></li>
      <li><a href="../Update/ARequest.php"><img src="../../pic/request.png" alt="Requests" class="sidebar-icon">Requests</a></li>
      <li><a href="../Users/AUsers.php"><img src="../../pic/user.png" alt="Users" class="sidebar-icon">Users</a></li>
      <li class="active"><a href="../Technicians/ATechnicians.php"><img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">Technician</a></li>
      <li><a href="../Inventory/AInventory.php"><img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">Inventory</a></li>
      <li class="logout"><a href="../../auth/logout.php"><img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">Logout</a></li>
    </ul>
  </aside>

  <main class="main-content">
    <header><h1>Technician Management</h1></header>

    <div class="summary-section">
      <div class="summary-card rating"><h3>AVERAGE RATING</h3><p class="value"><?= $avg_rating ?> ⭐</p></div>
      <div class="summary-card tasks"><h3>TOTAL TASKS</h3><p class="value"><?= $total_tasks ?></p></div>
      <div class="summary-card hours"><h3>TOTAL HOURS</h3><p class="value"><?= $total_hours ?> hrs</p></div>
    </div>

    <div class="top-bar">
      <button class="add-btn" onclick="openAddModal()">➕ New Technician</button>
      <input type="text" id="searchInput" placeholder="Search technician..." onkeyup="filterTechs()">
    </div>

    <section class="table-section">
      <table id="techTable">
        <thead>
          <tr>
            <th>Tech ID</th><th>Name</th><th>Email</th><th>Specialization</th>
            <th>Rating</th><th>Tasks</th><th>Hours</th><th>Status</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($techs as $t): ?>
            <tr>
              <td>#<?= str_pad($t['tech_id'], 5, '0', STR_PAD_LEFT) ?></td>
              <td><?= htmlspecialchars($t['fname'] . ($t['mname'] ? ' ' . $t['mname'] . ' ' : ' ') . $t['lname']) ?></td>
              <td><?= htmlspecialchars($t['email']) ?></td>
              <td><?= htmlspecialchars($t['specialization']) ?></td>
              <td><?= number_format($t['rating'],1) ?> ⭐</td>
              <td><?= $t['tasks_completed'] ?></td>
              <td><?= $t['working_hours'] ?></td>
              <td><?= htmlspecialchars($t['status']) ?></td>
              <td>
                <button class="edit-btn" onclick="openEditModal(<?= $t['tech_id'] ?>)">✏️</button>
                <button class="delete-btn" onclick="deleteTech(<?= $t['tech_id'] ?>)">🗑️</button>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </section>
  </main>
</div>

<div id="techModal" class="modal">
  <div class="modal-content">
    <button class="close-btn" onclick="closeModal()">×</button>
    <h2 id="modalTitle">Add Technician</h2>
    <form id="techForm">
      <input type="hidden" id="tech_id" name="tech_id">
      
      <!-- Tech ID Display (only shown when editing) -->
      <div id="techIdDisplay" style="display:none;">
        <input type="text" id="tech_id_display" class="id-display-field" readonly disabled>
        <p class="id-info-text">Technician ID is auto-generated and cannot be changed</p>
      </div>
      
      <input type="text" name="fname" placeholder="First Name" required>
      <input type="text" name="mname" placeholder="Middle Name" id="mname">
      <input type="text" name="lname" placeholder="Last Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" id="passwordField">
      <select name="specialization" required>
        <option value="">Select Technician Type</option>
        <?php foreach($specializations as $spec) echo "<option value='$spec'>$spec</option>"; ?>
      </select>
      <input type="text" name="contact_no" placeholder="Contact Number" required>
      <select name="status" required>
        <option value="">Select Status</option>
        <option value="Available">Available</option>
        <option value="Busy">Busy</option>
      </select>
      <div class="button-group">
        <button type="button" onclick="closeModal()">Cancel</button>
        <button type="submit">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
// ==== MODAL CONTROL ====
function openAddModal() {
  document.getElementById("modalTitle").textContent = "Add Technician";
  document.getElementById("techForm").reset();
  document.getElementById("tech_id").value = "";
  document.getElementById("passwordField").required = true;
  document.getElementById("techIdDisplay").style.display = "none";
  document.getElementById("techModal").classList.add("show");
}

function openEditModal(id) {
  fetch(`get_technician.php?tech_id=${id}`)
    .then(res => res.json())
    .then(data => {
      const form = document.getElementById("techForm");
      form.tech_id.value = data.tech_id;
      form.fname.value = data.fname || '';
      document.getElementById("mname").value = data.mname || '';
      form.lname.value = data.lname || '';
      form.email.value = data.email || '';
      form.password.value = "";
      document.getElementById("passwordField").required = false;
      form.specialization.value = data.specialization || '';
      form.contact_no.value = data.contact_no || '';
      form.status.value = data.status || 'Available';
      
      // Show Tech ID Display
      document.getElementById("tech_id_display").value = "Tech ID: #" + String(data.tech_id).padStart(5, '0');
      document.getElementById("techIdDisplay").style.display = "block";
      
      document.getElementById("modalTitle").textContent = "Edit Technician";
      document.getElementById("techModal").classList.add("show");
    })
    .catch(err => {
      console.error(err);
      Swal.fire('Error', 'Unable to load technician data.', 'error');
    });
}

function closeModal() {
  document.getElementById("techModal").classList.remove("show");
}

// ==== SAVE TECHNICIAN ====
document.getElementById("techForm").addEventListener("submit", async function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  if (!formData.get('specialization') || !formData.get('status')) {
    Swal.fire('Warning', 'Please select specialization and status.', 'warning');
    return;
  }
  Swal.fire({
    title: 'Confirm',
    text: 'Save technician details?',
    icon: 'question',
    showCancelButton: true,
    confirmButtonText: 'Yes',
    cancelButtonText: 'Cancel'
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        const res = await fetch("save_technician.php", { method: "POST", body: formData });
        const text = await res.text();
        Swal.fire('Saved!', text, 'success').then(() => location.reload());
      } catch(err) {
        console.error(err);
        Swal.fire('Error','Unable to save technician','error');
      }
    }
  });
});

// ==== DELETE TECHNICIAN ====
function deleteTech(id) {
  Swal.fire({
    title: 'Confirm',
    text: 'Technician will be deleted (soft delete)!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes, delete',
    cancelButtonText: 'Cancel'
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        const formData = new FormData();
        formData.append('tech_id', id);
        const res = await fetch("delete_technician.php", { method: 'POST', body: formData });
        const text = await res.text();
        Swal.fire('Deleted!', text, 'success').then(() => location.reload());
      } catch(err) {
        console.error(err);
        Swal.fire('Error','Unable to delete technician','error');
      }
    }
  });
}

// ==== SEARCH ====
function filterTechs() {
  const q = document.getElementById("searchInput").value.toLowerCase();
  document.querySelectorAll("#techTable tbody tr").forEach(tr => {
    tr.style.display = tr.textContent.toLowerCase().includes(q) ? "" : "none";
  });
}

// Close modal when clicking outside
window.onclick = e => { 
  if (e.target == document.getElementById('techModal')) closeModal(); 
}
</script>
</body>
</html>