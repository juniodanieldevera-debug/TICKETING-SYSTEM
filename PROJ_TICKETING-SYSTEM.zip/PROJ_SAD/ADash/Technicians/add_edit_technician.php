<?php
require '../../config/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tech_id = $_POST['tech_id'] ?? null;
  $fname = $_POST['fname'];
  $mname = $_POST['mname'] ?? '';
  $lname = $_POST['lname'];
  $suffix = $_POST['suffix'] ?? '';
  $age = $_POST['age'] ?? null;
  $birthday = $_POST['birthday'] ?? null;
  $contact = $_POST['contact'];
  $email = $_POST['email'];
  $gender = $_POST['gender'] ?? '';
  $specialization = $_POST['specialization'];
  $street = $_POST['street'] ?? '';
  $barangay = $_POST['barangay'] ?? '';
  $city = $_POST['city'] ?? '';
  $zip = $_POST['zip'] ?? '';

  if ($tech_id) {
    $stmt = $conn->prepare("UPDATE technicians SET fname=?, mname=?, lname=?, suffix=?, age=?, birthday=?, contact=?, email=?, gender=?, specialization=?, street=?, barangay=?, city=?, zip=? WHERE tech_id=?");
    $stmt->execute([$fname,$mname,$lname,$suffix,$age,$birthday,$contact,$email,$gender,$specialization,$street,$barangay,$city,$zip,$tech_id]);
    echo "Technician updated successfully.";
  } else {
    $stmt = $conn->prepare("INSERT INTO technicians (fname, mname, lname, suffix, age, birthday, contact, email, gender, specialization, street, barangay, city, zip) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([$fname,$mname,$lname,$suffix,$age,$birthday,$contact,$email,$gender,$specialization,$street,$barangay,$city,$zip]);
    echo "Technician added successfully.";
  }
}
?>
