<?php
require '../../config/db_connect.php';

if (!isset($_POST['tech_id'])) {
  echo "Error: Missing technician ID.";
  exit;
}

$tech_id = $_POST['tech_id'];

try {
    // Soft delete: set isDeleted = 0
    $stmt = $conn->prepare("UPDATE technicians SET isDeleted = 0 WHERE tech_id = ?");
    $stmt->execute([$tech_id]);

    echo "Technician deleted (soft delete) successfully.";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
