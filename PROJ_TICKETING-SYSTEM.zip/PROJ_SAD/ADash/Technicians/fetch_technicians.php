<?php
require '../../config/db_connect.php';
header('Content-Type: application/json');

try {
    $stmt = $conn->query("SELECT * FROM technicians ORDER BY date_registered DESC");
    $technicians = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($technicians);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>  