<?php
require '../../config/db_connect.php';

if (isset($_GET['tech_id'])) {
    $stmt = $conn->prepare("SELECT * FROM technicians WHERE tech_id = ?");
    $stmt->execute([$_GET['tech_id']]);
    $technician = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($technician) {
        header('Content-Type: application/json');
        echo json_encode($technician);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Technician not found']);
    }
} else {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'No technician ID provided']);
}
?>