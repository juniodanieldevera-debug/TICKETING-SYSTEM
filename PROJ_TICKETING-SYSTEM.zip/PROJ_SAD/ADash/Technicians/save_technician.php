<?php
require '../../config/db_connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $tech_id        = $_POST['tech_id'] ?? '';
  $fname          = trim($_POST['fname']);
  $mname          = trim($_POST['mname'] ?? '');
  $lname          = trim($_POST['lname']);
  $email          = trim($_POST['email']);
  $password       = $_POST['password'] ?? '';
  $specialization = trim($_POST['specialization']);
  $contact_no     = trim($_POST['contact_no']);
  $status         = $_POST['status'] ?? 'Available';

  if (empty($fname) || empty($lname) || empty($email)) {
    exit("⚠️ Please fill out all required fields.");
  }

  try {
    // Check if email already exists (excluding same tech on update)
    $check = $conn->prepare("
      SELECT a.account_id 
      FROM accounts a
      JOIN technicians t ON a.account_id = t.account_id
      WHERE a.email = ? AND t.tech_id != ?
    ");
    $check->execute([$email, $tech_id ?: 0]);
    if ($check->fetch()) exit("⚠️ Email already exists.");

    if ($tech_id) {
      // === UPDATE TECHNICIAN ===
      $updateTech = $conn->prepare("
        UPDATE technicians 
        SET fname=?, mname=?, lname=?, email=?, specialization=?, contact_no=?, status=? 
        WHERE tech_id=?
      ");
      $updateTech->execute([$fname, $mname, $lname, $email, $specialization, $contact_no, $status, $tech_id]);

      // Update password only if changed
      if (!empty($password)) {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $updateAcc = $conn->prepare("
          UPDATE accounts 
          SET email=?, password=? 
          WHERE account_id=(SELECT account_id FROM technicians WHERE tech_id=?)
        ");
        $updateAcc->execute([$email, $hashed, $tech_id]);
      } else {
        $conn->prepare("
          UPDATE accounts 
          SET email=? 
          WHERE account_id=(SELECT account_id FROM technicians WHERE tech_id=?)
        ")->execute([$email, $tech_id]);
      }

      echo "✅ Technician updated successfully.";
    } else {
      // === ADD NEW TECHNICIAN ===
      if (empty($password)) {
        exit("⚠️ Password is required for new technicians.");
      }
      
      $hashed = password_hash($password, PASSWORD_DEFAULT);
      $acc = $conn->prepare("INSERT INTO accounts (email, password, role) VALUES (?, ?, 'Technician')");
      $acc->execute([$email, $hashed]);
      $account_id = $conn->lastInsertId();

      $addTech = $conn->prepare("
        INSERT INTO technicians (fname, mname, lname, email, contact_no, specialization, status, account_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ");
      $addTech->execute([$fname, $mname, $lname, $email, $contact_no, $specialization, $status, $account_id]);

      echo "✅ Technician added successfully.";
    }

  } catch (PDOException $e) {
    echo "❌ Database Error: " . htmlspecialchars($e->getMessage());
  }
}
?>