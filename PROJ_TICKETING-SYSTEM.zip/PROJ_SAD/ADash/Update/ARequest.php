<?php
session_start();
require '../../config/db_connect.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit;
}

// SUMMARY
$total = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status != 'Archived'")->fetchColumn();
$pending = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status='Pending'")->fetchColumn();
$assigned = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status='Assigned'")->fetchColumn();
$completed = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status='Completed'")->fetchColumn();

// GET ALL ACTIVE REQUESTS
$requests = $conn->query("
    SELECT ur.*, t.fname AS tech_fname, t.lname AS tech_lname, t.specialization AS tech_specialization,
           DATEDIFF(ur.request_date, CURDATE()) AS days_remaining
    FROM user_requests ur
    LEFT JOIN technicians t ON ur.tech_id = t.tech_id
    WHERE ur.status != 'Archived'
    ORDER BY ur.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// SPLIT PRIORITY & NORMAL
$priorityRequests = [];
$normalRequests = [];

foreach ($requests as $r) {
    $days = $r['days_remaining'];

    if ($days <= 5) {
        $priorityRequests[] = $r;  // HIGH + MEDIUM
    } else {
        $normalRequests[] = $r;    // NORMAL
    }
}

// ARCHIVED
$archived = $conn->query("
    SELECT ur.*, t.fname AS tech_fname, t.lname AS tech_lname, t.specialization AS tech_specialization
    FROM user_requests ur
    LEFT JOIN technicians t ON ur.tech_id = t.tech_id
    WHERE ur.status = 'Archived'
    ORDER BY ur.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// TECHNICIANS
$techs = $conn->query("SELECT tech_id,fname,lname,specialization FROM technicians ORDER BY fname")
        ->fetchAll(PDO::FETCH_ASSOC);

// Specializations
$specializations = $conn->query("SELECT DISTINCT specialization FROM technicians WHERE specialization!=''")
        ->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Management</title>
    <link rel="stylesheet" href="ARequest.css?v=<?= time() ?>">
</head>
<body>

<div class="page-container">

<!-- UPDATED SIDEBAR TO MATCH ADMIN DASHBOARD -->
<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP ADMIN</h2>
    </div>
    <ul>
        <li><a href="../Dashboard/ADashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li class="active"><a href="../Update/ARequest.php">
            <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
            Requests
        </a></li>
        <li><a href="../Users/AUsers.php">
            <img src="../../pic/user.png" alt="Users" class="sidebar-icon">
            Users
        </a></li>
        <li><a href="../Technicians/ATechnicians.php">
            <img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">
            Technician
        </a></li>
        <li><a href="../Inventory/AInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<!-- MAIN -->
<main class="main-content">

<header>
    <h1>Request Management</h1>
    <div class="top-controls">
        <input type="text" id="searchInput" placeholder="Search..." onkeyup="searchRequest()">
        <button onclick="toggleArchive()" class="archive-btn" id="archiveButton">📦 Archives</button>
    </div>
</header>

<!-- ACTIVE REQUESTS SECTION (Default View) -->
<div id="activeSection">
    <!-- SUMMARY -->
    <section class="summary-section">
        <div class="card blue"><h3>Total</h3><p><?= $total ?></p></div>
        <div class="card yellow"><h3>Pending</h3><p><?= $pending ?></p></div>
        <div class="card green"><h3>Assigned</h3><p><?= $assigned ?></p></div>
        <div class="card pink"><h3>Completed</h3><p><?= $completed ?></p></div>
    </section>

    <!-- 🔥 PRIORITY REQUESTS (HORIZONTAL SCROLL) -->
    <?php if(count($priorityRequests) > 0): ?>
    <h2 class="section-label">🔥 Priority Requests</h2>
    <div class="priority-container">
        <?php foreach ($priorityRequests as $r): ?>
            <?php 
                $days = $r['days_remaining'];
                $priorityClass = ($days <= 2) ? 'high-priority' : 'medium-priority';
            ?>
            <div class="request-card <?= $priorityClass ?>">
                <h3><?= htmlspecialchars($r['request_title'] ?? (isset($r['request_details']) ? substr($r['request_details'],0,50) : 'No Title')) ?>...</h3>

                <p><b>Requester:</b> <?= $r['fname'].' '.$r['lname'] ?></p>
                <p><b>Department:</b> <?= $r['department'] ?></p>
                <p><b>Room:</b> <?= $r['room'] ?></p>
                <p><b>Date Needed:</b> <?= $r['request_date'] ?> ⚠️</p>
                <p><b>Status:</b> <?= $r['status'] ?></p>

                <?php if(!empty($r['technician_type'])): ?>
                    <p><b>Technician Type:</b> <?= $r['technician_type'] ?></p>
                <?php endif; ?>

                <?php if(!empty($r['tech_fname'])): ?>
                    <p><b>Assigned:</b> <?= $r['tech_fname'].' '.$r['tech_lname'] ?></p>
                <?php endif; ?>

                <div class="actions">
                    <select onchange="assignTech(<?= $r['id'] ?>,this.value)">
                        <option value="">Assign Technician</option>
                        <?php 
                        // Filter technicians by type
                        $filteredTechs = array_filter($techs, function($t) use ($r) {
                            return $t['specialization'] === $r['technician_type'];
                        });
                        foreach($filteredTechs as $t): ?>
                            <option value="<?= $t['tech_id'] ?>"><?= $t['fname']." ".$t['lname']." (".$t['specialization'].")" ?></option>
                        <?php endforeach; ?>
                        <?php if(empty($filteredTechs)): ?>
                            <option value="" disabled>No <?= $r['technician_type'] ?> available</option>
                        <?php endif; ?>
                    </select>

                    <select onchange="updateStatus(<?= $r['id'] ?>,this.value)">
                        <option value="">Update Status</option>
                        <option <?= ($r['status']=='Pending'?'selected':'') ?>>Pending</option>
                        <option <?= ($r['status']=='Assigned'?'selected':'') ?>>Assigned</option>
                        <option <?= ($r['status']=='In Progress'?'selected':'') ?>>In Progress</option>
                        <option <?= ($r['status']=='Completed'?'selected':'') ?>>Completed</option>
                    </select>

                    <?php if($r['status']=='Completed'): ?>
                        <button class="archive-btn" onclick="archiveRequest(<?= $r['id'] ?>)">📦 Archive</button>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- NORMAL REQUESTS -->
    <h2 class="section-label">Requests</h2>
    <section id="activeRequests" class="requests-list">

    <?php foreach ($normalRequests as $r): ?>
        <div class="request-card normal-priority">
            <h3><?= htmlspecialchars($r['request_title'] ?? (isset($r['request_details']) ? substr($r['request_details'],0,50) : 'No Title')) ?>...</h3>

            <p><b>Requester:</b> <?= $r['fname'].' '.$r['lname'] ?></p>
            <p><b>Department:</b> <?= $r['department'] ?></p>
            <p><b>Room:</b> <?= $r['room'] ?></p>
            <p><b>Date Needed:</b> <?= $r['request_date'] ?></p>
            <p><b>Status:</b> <?= $r['status'] ?></p>

            <?php if(!empty($r['technician_type'])): ?>
                <p><b>Technician Type:</b> <?= $r['technician_type'] ?></p>
            <?php endif; ?>

            <?php if(!empty($r['tech_fname'])): ?>
                <p><b>Assigned:</b> <?= $r['tech_fname'].' '.$r['tech_lname'] ?></p>
            <?php endif; ?>

            <div class="actions">
                <select onchange="assignTech(<?= $r['id'] ?>,this.value)">
                    <option value="">Assign Technician</option>
                    <?php 
                    // Filter technicians by type
                    $filteredTechs = array_filter($techs, function($t) use ($r) {
                        return $t['specialization'] === $r['technician_type'];
                    });
                    foreach($filteredTechs as $t): ?>
                        <option value="<?= $t['tech_id'] ?>"><?= $t['fname']." ".$t['lname']." (".$t['specialization'].")" ?></option>
                    <?php endforeach; ?>
                    <?php if(empty($filteredTechs)): ?>
                        <option value="" disabled>No <?= $r['technician_type'] ?> available</option>
                    <?php endif; ?>
                </select>

                <select onchange="updateStatus(<?= $r['id'] ?>,this.value)">
                    <option value="">Update Status</option>
                    <option <?= ($r['status']=='Pending'?'selected':'') ?>>Pending</option>
                    <option <?= ($r['status']=='Assigned'?'selected':'') ?>>Assigned</option>
                    <option <?= ($r['status']=='In Progress'?'selected':'') ?>>In Progress</option>
                    <option <?= ($r['status']=='Completed'?'selected':'') ?>>Completed</option>
                </select>

                <?php if($r['status']=='Completed'): ?>
                    <button class="archive-btn" onclick="archiveRequest(<?= $r['id'] ?>)">📦 Archive</button>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>

    </section>
</div>

<!-- ARCHIVE SECTION (Hidden by Default) -->
<section id="archiveSection" style="display:none;">
    <h2 class="section-label">📦 Archived Requests</h2>
    <div class="requests-list">
        <?php foreach ($archived as $a): ?>
            <div class="request-card archived">
                <h3><?= htmlspecialchars($a['request_title'] ?? (isset($a['request_details']) ? substr($a['request_details'],0,50) : 'No Title')) ?></h3>
                <p><b>Requester:</b> <?= $a['fname'].' '.$a['lname'] ?></p>
                <p><b>Department:</b> <?= $a['department'] ?></p>
                <p><b>Room:</b> <?= $a['room'] ?></p>
                <p><b>Date Needed:</b> <?= $a['request_date'] ?></p>
                <p><b>Status:</b> <?= $a['status'] ?></p>
                <p><b>Archived Date:</b> <?= $a['created_at'] ?></p>
                
                <?php if(!empty($a['tech_fname'])): ?>
                    <p><b>Completed by:</b> <?= $a['tech_fname'].' '.$a['tech_lname'] ?></p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</section>

</main>
</div>

<script>
const technicians = <?= json_encode($techs) ?>;
let archiveMode = false;

function searchRequest(){
    let text = document.getElementById("searchInput").value.toLowerCase();
    
    if (archiveMode) {
        // Search in archive
        document.querySelectorAll("#archiveSection .request-card").forEach(card=>{
            card.style.display = card.textContent.toLowerCase().includes(text) ? "block" : "none";
        });
    } else {
        // Search in active requests
        document.querySelectorAll(".request-card").forEach(card=>{
            card.style.display = card.textContent.toLowerCase().includes(text) ? "block" : "none";
        });
    }
}

function toggleArchive(){
    const activeSection = document.getElementById("activeSection");
    const archiveSection = document.getElementById("archiveSection");
    const archiveButton = document.getElementById("archiveButton");
    
    if(!archiveMode){
        // Switch to Archive view
        activeSection.style.display = "none";
        archiveSection.style.display = "block";
        archiveButton.textContent = "📦 Active Requests";
        archiveMode = true;
    } else {
        // Switch back to Active view
        activeSection.style.display = "block";
        archiveSection.style.display = "none";
        archiveButton.textContent = "📦 Archives";
        archiveMode = false;
    }
    
    // Clear search when switching views
    document.getElementById("searchInput").value = "";
    searchRequest(); // Reset display
}

async function assignTech(id, techId){
    if(!techId) return;
    await fetch(`assign_tech.php?id=${id}&tech_id=${techId}`);
    location.reload();
}

async function updateStatus(id,status){
    if(!status) return;
    await fetch(`update_status.php?id=${id}&status=${status}`);
    location.reload();
}

async function archiveRequest(id){
    if(!confirm("Archive request?")) return;
    await fetch(`update_status.php?id=${id}&status=Archived`);
    location.reload();
}
</script>

</body>
</html>