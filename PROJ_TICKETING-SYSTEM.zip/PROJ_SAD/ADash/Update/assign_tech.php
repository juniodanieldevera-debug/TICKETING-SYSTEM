<?php
require '../../config/db_connect.php';
require '../../config/notification_functions.php';

$id = $_GET['id'];
$tech = $_GET['tech_id'];

// Validate inputs
if (empty($id) || empty($tech)) {
    echo "Error: Missing parameters";
    exit;
}

try {
    // Get request details including user_id
    $requestStmt = $conn->prepare("SELECT ur.*, u.user_id, u.fname as user_fname, u.lname as user_lname FROM user_requests ur JOIN users u ON ur.user_id = u.user_id WHERE ur.id = ?");
    $requestStmt->execute([$id]);
    $request = $requestStmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        echo "Error: Request not found";
        exit;
    }

    // Get technician details
    $techStmt = $conn->prepare("SELECT fname, lname, specialization FROM technicians WHERE tech_id = ?");
    $techStmt->execute([$tech]);
    $technician = $techStmt->fetch(PDO::FETCH_ASSOC);

    if (!$technician) {
        echo "Error: Technician not found";
        exit;
    }

    // Update the request with assigned technician
    $stmt = $conn->prepare("UPDATE user_requests SET tech_id=?, status='Assigned' WHERE id=?");
    $stmt->execute([$tech, $id]);

    // ✅ INCREMENT TASKS_COMPLETED BY 1 WHEN ASSIGNED
    $updateTasks = $conn->prepare("UPDATE technicians SET tasks_completed = tasks_completed + 1 WHERE tech_id = ?");
    $updateTasks->execute([$tech]);

    // Create notification for the user
    $technician_name = $technician['fname'] . ' ' . $technician['lname'];
    $technician_specialization = $technician['specialization'];
    
    $notification_title = "Technician Assigned";
    $notification_message = "{$technician_name} ({$technician_specialization}) has been assigned to your maintenance request";
    
    $notification_created = createNotification(
        $request['user_id'],
        $notification_title,
        $notification_message,
        'assignment',
        $id
    );

    if ($notification_created) {
        echo "Technician Assigned Successfully - Notification sent - Task count updated";
    } else {
        echo "Technician Assigned Successfully - Notification failed - Task count updated";
    }
    
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>