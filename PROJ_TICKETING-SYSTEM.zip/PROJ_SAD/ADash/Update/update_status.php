<?php
require '../../config/db_connect.php';
require '../../config/notification_functions.php';

$id = $_GET['id'];
$status = $_GET['status'];

try {
    // Get request details including user_id and tech_id
    $requestStmt = $conn->prepare("SELECT ur.*, u.user_id, u.fname as user_fname, u.lname as user_lname, ur.tech_id FROM user_requests ur JOIN users u ON ur.user_id = u.user_id WHERE ur.id = ?");
    $requestStmt->execute([$id]);
    $request = $requestStmt->fetch(PDO::FETCH_ASSOC);

    if (!$request) {
        echo "Error: Request not found";
        exit;
    }

    // Update the request status
    $stmt = $conn->prepare("UPDATE user_requests SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    // ✅ ADD WORKING HOURS WHEN STATUS IS "IN PROGRESS" OR "COMPLETED"
    if ($status === 'In Progress' && !empty($request['tech_id'])) {
        // Add 1 hour when work starts
        $updateHours = $conn->prepare("UPDATE technicians SET working_hours = working_hours + 1 WHERE tech_id = ?");
        $updateHours->execute([$request['tech_id']]);
    }
    elseif ($status === 'Completed' && !empty($request['tech_id'])) {
        // Add 2 more hours when completed (total 3 hours per task)
        $updateHours = $conn->prepare("UPDATE technicians SET working_hours = working_hours + 2 WHERE tech_id = ?");
        $updateHours->execute([$request['tech_id']]);
    }

    // Create notification for the user
    $notification_title = "Request Status Updated";
    $notification_message = "Your maintenance request status has been updated to: {$status}";
    
    // Add additional context based on status
    switch($status) {
        case 'In Progress':
            $notification_message .= " - Technician is now working on your request";
            break;
        case 'Completed':
            $notification_message .= " - Your request has been completed. You can now rate the technician in your history.";
            break;
        case 'Cancelled':
            $notification_message .= " - Your request has been cancelled";
            break;
    }
    
    $notification_created = createNotification(
        $request['user_id'],
        $notification_title,
        $notification_message,
        'status_update',
        $id
    );

    if ($notification_created) {
        echo "Status Updated Successfully - Notification sent";
        // Add hours message if applicable
        if (($status === 'In Progress' || $status === 'Completed') && !empty($request['tech_id'])) {
            echo " - Working hours updated";
        }
    } else {
        echo "Status Updated Successfully - Notification failed";
        // Add hours message if applicable
        if (($status === 'In Progress' || $status === 'Completed') && !empty($request['tech_id'])) {
            echo " - Working hours updated";
        }
    }

} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>