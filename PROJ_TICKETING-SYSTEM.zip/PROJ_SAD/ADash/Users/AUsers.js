function openUserModal() {
    document.getElementById("modalTitle").textContent = "Add User";
    document.getElementById("userForm").reset();
    document.getElementById("user_id").value = "";
    document.getElementById("password").required = true;
    document.getElementById("passwordHelp").style.display = "none";
    document.getElementById("userModal").classList.add("show");
}

function closeUserModal() {
    document.getElementById("userModal").classList.remove("show");
}

function editUser(id, fname, mname, lname, department, email) {
    document.getElementById("modalTitle").textContent = "Edit User";

    document.getElementById("user_id").value = id;
    document.getElementById("fname").value = fname;
    document.getElementById("mname").value = mname || '';
    document.getElementById("lname").value = lname;
    document.getElementById("department").value = department;
    document.getElementById("email").value = email;

    document.getElementById("password").required = false;
    document.getElementById("passwordHelp").style.display = "block";

    document.getElementById("userModal").classList.add("show");
}

// SAVE / ADD USER WITH SWEETALERT2
document.getElementById("userForm").addEventListener("submit", async function (e) {
    e.preventDefault();
    
    const password = document.getElementById("password").value;
    const isEdit = document.getElementById("user_id").value !== "";

    if (!isEdit && !password) {
        Swal.fire({
            icon: 'error',
            title: 'Password Required',
            text: 'Password is required for new users.',
        });
        return;
    }

    const formData = new FormData(this);

    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to save this user?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, save it!',
        cancelButtonText: 'No, cancel'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                const res = await fetch("save_user.php", {
                    method: "POST",
                    body: formData
                });
                const data = await res.json();

                if (data.status === "success") {
                    Swal.fire({
                        icon: 'success',
                        title: 'Saved!',
                        text: data.message || 'User saved successfully.',
                    }).then(() => {
                        closeUserModal();
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Failed to save user.',
                    });
                }
            } catch (error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Unable to connect to server.'
                });
            }
        }
    });
});

// DELETE USER WITH SWEETALERT2
function deleteUser(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "This user will be permanently deleted!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel'
    }).then(async (result) => {
        if (result.isConfirmed) {
            try {
                const res = await fetch(`delete_user.php?id=${id}`);
                const data = await res.json();

                if (data.status === "success") {
                    Swal.fire({
                        icon: 'success',
                        title: 'Deleted!',
                        text: data.message || 'User deleted successfully.',
                    }).then(() => location.reload());
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: data.message || 'Could not delete user.',
                    });
                }
            } catch (error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Unable to connect to server.'
                });
            }
        }
    });
}

// SEARCH USERS
function searchUser() {
    let filter = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("#userTableBody tr");
    rows.forEach(row => {
        let rowText = row.textContent.toLowerCase();
        row.style.display = rowText.includes(filter) ? "" : "none";
    });
}

// CLOSE MODAL ON OUTSIDE CLICK
window.onclick = function(e) {
    if (e.target == document.getElementById('userModal')) {
        closeUserModal();
    }
}
