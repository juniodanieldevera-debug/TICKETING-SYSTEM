<?php
session_start();
require '../../config/db_connect.php';

// Restrict access to Admin only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../../auth/login.php");
    exit;
}

// Fetch all users
$stmt = $conn->query("
    SELECT u.user_id, u.fname, u.mname, u.lname, u.id_number, u.department, a.email 
    FROM users u
    LEFT JOIN accounts a ON u.account_id = a.account_id
    WHERE u.isDeleted = 1
    ORDER BY u.user_id DESC
");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Department options
$departments = [
    "HR Department",
    "IT Department", 
    "Engineering Department",
    "Facilities Department",
    "Sales Department",
    "Security Department"
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management</title>
    <link rel="stylesheet" href="AUsers.css?v=<?= time() ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<div class="page-container">

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="logo">
            <img src="../../pic/moplogo.png" alt="MOP Logo">
            <h2>MOP ADMIN</h2>
        </div>
        <ul>
            <li><a href="../Dashboard/ADashboard.php"><img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">Dashboard</a></li>
            <li><a href="../Update/ARequest.php"><img src="../../pic/request.png" alt="Requests" class="sidebar-icon">Requests</a></li>
            <li class="active"><a href="../Users/AUsers.php"><img src="../../pic/user.png" alt="Users" class="sidebar-icon">Users</a></li>
            <li><a href="../Technicians/ATechnicians.php"><img src="../../pic/tech.png" alt="Technicians" class="sidebar-icon">Technician</a></li>
            <li><a href="../Inventory/AInventory.php"><img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">Inventory</a></li>
            <li class="logout"><a href="../../auth/logout.php"><img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">Logout</a></li>
        </ul>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="main-content">
        <header><h1>User Management</h1></header>
        <div class="top-bar">
            <button onclick="openUserModal()" class="add-btn">+ Add User</button>
            <input type="text" id="searchInput" placeholder="Search..." onkeyup="searchUser()">
        </div>

        <table class="user-table">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>ID Number</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="userTableBody">
                <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['user_id'] ?></td>
                    <td><?= htmlspecialchars($u['id_number'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($u['fname'] . ($u['mname'] ? ' ' . $u['mname'] . ' ' : ' ') . $u['lname']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td><?= htmlspecialchars($u['department']) ?></td>
                    <td>
                        <button class="edit-btn"
                                onclick="editUser(
                                    '<?= $u['user_id'] ?>',
                                    '<?= htmlspecialchars($u['fname']) ?>',
                                    '<?= htmlspecialchars($u['mname'] ?? '') ?>',
                                    '<?= htmlspecialchars($u['lname']) ?>',
                                    '<?= htmlspecialchars($u['id_number'] ?? '') ?>',
                                    '<?= htmlspecialchars($u['department']) ?>',
                                    '<?= htmlspecialchars($u['email']) ?>'
                                )">
                            Edit
                        </button>
                        <button class="delete-btn" onclick="deleteUser(<?= $u['user_id'] ?>)">Delete</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</div>

<!-- MODAL -->
<div id="userModal" class="modal">
    <div class="modal-content">
        <button class="close-btn" onclick="closeUserModal()">×</button>
        <h2 id="modalTitle">Add User</h2>
        <form id="userForm">
            <input type="hidden" name="user_id" id="user_id">
            <input type="text" name="fname" id="fname" placeholder="First Name" required>
            <input type="text" name="mname" id="mname" placeholder="Middle Name">
            <input type="text" name="lname" id="lname" placeholder="Last Name" required>
            <input type="text" name="id_number" id="id_number" placeholder="ID Number (e.g., 2021-00001)" required>
            <select name="department" id="department" required>
                <option value="">Select Department</option>
                <?php foreach ($departments as $dept): ?>
                    <option value="<?= $dept ?>"><?= $dept ?></option>
                <?php endforeach; ?>
            </select>
            <input type="email" name="email" id="email" placeholder="Email" required>
            <input type="password" name="password" id="password" placeholder="Password">
            <small id="passwordHelp">Leave blank to keep current password</small>
            <div class="button-group">
                <button type="button" onclick="closeUserModal()">Cancel</button>
                <button type="submit">Save</button>
            </div>
        </form>
    </div>
</div>

<script>
// ----- MODAL FUNCTIONS -----
function openUserModal() {
    document.getElementById("modalTitle").textContent = "Add User";
    document.getElementById("userForm").reset();
    document.getElementById("user_id").value = "";
    document.getElementById("password").required = true;
    document.getElementById("id_number").required = true;
    document.getElementById("passwordHelp").style.display = "none";
    document.getElementById("userModal").classList.add("show");
}

function closeUserModal() {
    document.getElementById("userModal").classList.remove("show");
}

function editUser(id, fname, mname, lname, id_number, department, email) {
    document.getElementById("modalTitle").textContent = "Edit User";
    document.getElementById("user_id").value = id;
    document.getElementById("fname").value = fname;
    document.getElementById("mname").value = mname || '';
    document.getElementById("lname").value = lname;
    document.getElementById("id_number").value = id_number || '';
    document.getElementById("department").value = department;
    document.getElementById("email").value = email;
    document.getElementById("password").required = false;
    document.getElementById("id_number").required = true;
    document.getElementById("passwordHelp").style.display = "block";
    document.getElementById("userModal").classList.add("show");
}

// ----- SAVE / ADD USER -----
document.getElementById("userForm").addEventListener("submit", async function(e){
    e.preventDefault();
    const password = document.getElementById("password").value;
    const isEdit = document.getElementById("user_id").value !== "";
    if (!isEdit && !password) {
        Swal.fire({icon:'error', title:'Password Required', text:'Password is required for new users.'});
        return;
    }
    const formData = new FormData(this);
    Swal.fire({
        title: 'Are you sure?',
        text: "Do you want to save this user?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Yes, save it!',
        cancelButtonText: 'No, cancel'
    }).then(async (result)=>{
        if(result.isConfirmed){
            try {
                const res = await fetch("save_user.php",{method:"POST",body:formData});
                const data = await res.json();
                if(data.status==="success"){
                    Swal.fire({icon:'success', title:'Saved!', text:data.message||'User saved successfully.'}).then(()=>{closeUserModal(); location.reload();});
                } else {
                    Swal.fire({icon:'error', title:'Error', text:data.message||'Failed to save user.'});
                }
            } catch(e){
                Swal.fire({icon:'error', title:'Error', text:'Unable to connect to server.'});
            }
        }
    });
});

// ----- DELETE USER -----
function deleteUser(id){
    Swal.fire({
        title:'Are you sure?',
        text:'This user will be permanently deleted!',
        icon:'warning',
        showCancelButton:true,
        confirmButtonText:'Yes, delete it!',
        cancelButtonText:'No, cancel'
    }).then(async (result)=>{
        if(result.isConfirmed){
            try {
                const res = await fetch(`delete_user.php?id=${id}`);
                const data = await res.json();
                if(data.status==="success"){
                    Swal.fire({icon:'success', title:'Deleted!', text:data.message||'User deleted successfully.'}).then(()=>location.reload());
                } else {
                    Swal.fire({icon:'error', title:'Error', text:data.message||'Could not delete user.'});
                }
            } catch(e){
                Swal.fire({icon:'error', title:'Error', text:'Unable to connect to server.'});
            }
        }
    });
}

// ----- SEARCH USERS -----
function searchUser(){
    let filter = document.getElementById("searchInput").value.toLowerCase();
    let rows = document.querySelectorAll("#userTableBody tr");
    rows.forEach(row=>row.style.display=row.textContent.toLowerCase().includes(filter)?"":"none");
}

// ----- CLOSE MODAL ON OUTSIDE CLICK -----
window.onclick = function(e){ if(e.target==document.getElementById('userModal')) closeUserModal(); }
</script>

</body>
</html>