<?php
require '../../config/db_connect.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(['status'=>'error', 'message'=>'Invalid request. Missing user ID.']);
    exit;
}

$id = $_GET['id'];

try {
    // Check if user exists and is not already deleted
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ? AND isDeleted = 1");
    $stmt->execute([$id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode(['status'=>'error', 'message'=>'User not found or already deleted.']);
        exit;
    }

    // Soft delete: set isDeleted to 0
    $stmt = $conn->prepare("UPDATE users SET isDeleted = 0 WHERE user_id = ?");
    $stmt->execute([$id]);

    echo json_encode(['status'=>'success','message'=>'User soft-deleted successfully!']);
} catch (PDOException $e) {
    echo json_encode(['status'=>'error','message'=>'Database Error: ' . $e->getMessage()]);
}
?>
