<?php
require '../../config/db_connect.php';
$stmt = $conn->query("SELECT u.user_id, u.fname, u.mname, u.lname, u.department, a.email FROM users u LEFT JOIN accounts a ON u.account_id = a.account_id WHERE u.isDeleted = 1 ORDER BY u.user_id DESC");
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>