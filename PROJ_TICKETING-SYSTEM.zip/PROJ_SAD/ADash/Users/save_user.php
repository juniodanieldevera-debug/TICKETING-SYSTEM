<?php
require '../../config/db_connect.php';

header('Content-Type: application/json'); // return JSON

try {
    $user_id = $_POST['user_id'] ?? null;
    $fname = trim($_POST['fname']);
    $mname = trim($_POST['mname'] ?? '');
    $lname = trim($_POST['lname']);
    $department = trim($_POST['department']);
    $email = trim($_POST['email']);
    $password = $_POST['password'] ?? null;
    $id_number = trim($_POST['id_number'] ?? ''); // Added this line

    // Validate required fields
    if (empty($fname) || empty($lname) || empty($department) || empty($email) || empty($id_number)) {
        echo json_encode(['status'=>'error','message'=>'All fields are required!']);
        exit;
    }

    // Check email uniqueness
    if ($user_id) {
        // For update: check if email exists for other users
        $stmt = $conn->prepare("SELECT account_id FROM accounts WHERE email=? AND account_id != (SELECT account_id FROM users WHERE user_id=?)");
        $stmt->execute([$email, $user_id]);
        if ($stmt->fetch()) {
            echo json_encode(['status'=>'error','message'=>'Email already exists!']);
            exit;
        }
    } else {
        // For new user: check if email exists at all
        $stmt = $conn->prepare("SELECT account_id FROM accounts WHERE email=?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            echo json_encode(['status'=>'error','message'=>'Email already exists!']);
            exit;
        }
        if (empty($password)) {
            echo json_encode(['status'=>'error','message'=>'Password is required for new users!']);
            exit;
        }
    }

    // Insert or update account
    if ($user_id) {
        // Update existing user
        if ($password) {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE accounts SET email=?, password=? WHERE account_id=(SELECT account_id FROM users WHERE user_id=?)");
            $stmt->execute([$email, $hash, $user_id]);
        } else {
            $stmt = $conn->prepare("UPDATE accounts SET email=? WHERE account_id=(SELECT account_id FROM users WHERE user_id=?)");
            $stmt->execute([$email, $user_id]);
        }
        
        // Update user information including ID number
        $stmt = $conn->prepare("UPDATE users SET fname=?, mname=?, lname=?, department=?, id_number=? WHERE user_id=?");
        $stmt->execute([$fname, $mname, $lname, $department, $id_number, $user_id]);

        echo json_encode(['status'=>'success','message'=>'User updated successfully!']);
    } else {
        // NEW USER
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare("INSERT INTO accounts (email, password, role) VALUES (?, ?, 'User')");
        $stmt->execute([$email, $hash]);
        $account_id = $conn->lastInsertId();

        $stmt = $conn->prepare("INSERT INTO users (account_id, fname, mname, lname, department, email, id_number) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$account_id, $fname, $mname, $lname, $department, $email, $id_number]);

        echo json_encode(['status'=>'success','message'=>'User added successfully!']);
    }

} catch (PDOException $e) {
    echo json_encode(['status'=>'error','message'=>'Database Error: ' . $e->getMessage()]);
}
?>