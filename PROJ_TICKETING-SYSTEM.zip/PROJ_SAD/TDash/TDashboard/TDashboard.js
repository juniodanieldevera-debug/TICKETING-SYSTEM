class RequestModal {
    constructor() {
        this.modal = document.getElementById('requestModal');
        this.modalBody = document.getElementById('modalBody');
        this.fullDetailsLink = document.getElementById('fullDetailsLink');
        this.initEventListeners();
    }

    initEventListeners() {
        // View buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const requestData = JSON.parse(e.target.getAttribute('data-request'));
                this.openModal(requestData);
            });
        });

        // Close button
        document.querySelector('.close-btn').addEventListener('click', () => {
            this.closeModal();
        });

        // Secondary close button
        document.querySelector('.btn-secondary').addEventListener('click', () => {
            this.closeModal();
        });

        // Close modal when clicking outside
        this.modal.addEventListener('click', (e) => {
            if (e.target === this.modal) {
                this.closeModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.modal.style.display === 'block') {
                this.closeModal();
            }
        });
    }

    openModal(requestData) {
        // Populate modal content
        this.modalBody.innerHTML = this.generateModalContent(requestData);
        
        // Set full details link
        this.fullDetailsLink.href = `../TRequests/TRequests_View.php?id=${requestData.id}`;
        
        // Show modal
        this.modal.style.display = 'block';
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
    }

    closeModal() {
        this.modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }

    generateModalContent(requestData) {
        const statusClass = `status-${requestData.status.toLowerCase().replace(' ', '-')}`;
        
        return `
            <div class="detail-row">
                <div class="detail-label">Unit Name:</div>
                <div class="detail-value">${this.escapeHtml(requestData.unit_name) || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Unit Number:</div>
                <div class="detail-value">${this.escapeHtml(requestData.unit_number) || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Request Details:</div>
                <div class="detail-value">${this.escapeHtml(requestData.request_details) || 'No details provided'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Location:</div>
                <div class="detail-value">Floor ${this.escapeHtml(requestData.floor) || 'N/A'}, Room ${this.escapeHtml(requestData.room) || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Department:</div>
                <div class="detail-value">${this.escapeHtml(requestData.department) || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Request Date:</div>
                <div class="detail-value">${this.escapeHtml(requestData.request_date) || 'N/A'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Status:</div>
                <div class="detail-value">
                    <span class="status-badge ${statusClass}">
                        ${this.escapeHtml(requestData.status)}
                    </span>
                </div>
            </div>
            ${requestData.image_path ? `
            <div class="detail-row">
                <div class="detail-label">Attachment:</div>
                <div class="detail-value">
                    <img src="../../${this.escapeHtml(requestData.image_path)}" alt="Request Image" class="image-preview" onerror="this.style.display='none'">
                </div>
            </div>
            ` : ''}
            <div class="detail-row">
                <div class="detail-label">Created:</div>
                <div class="detail-value">${new Date(requestData.created_at).toLocaleDateString()}</div>
            </div>
        `;
    }

    escapeHtml(unsafe) {
        if (!unsafe) return unsafe;
        return unsafe
            .toString()
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
}

// Initialize modal when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new RequestModal();
});