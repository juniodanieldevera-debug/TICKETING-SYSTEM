<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: ../../auth/login.php");
    exit();
}

$account_id = $_SESSION['account_id'];

/* FETCH TECHNICIAN INFO */
$techQuery = $conn->prepare("SELECT * FROM technicians WHERE account_id = ?");
$techQuery->execute([$account_id]);
$tech = $techQuery->fetch(PDO::FETCH_ASSOC);

if (!$tech) {
    die("Technician record not found for account_id = " . $account_id);
}

/* FETCH RECENT REQUESTS */
$reqQuery = $conn->prepare("
    SELECT * FROM user_requests 
    WHERE tech_id = ?
    ORDER BY created_at DESC 
    LIMIT 5
");
$reqQuery->execute([$tech['tech_id']]);
$requests = $reqQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Technician Dashboard</title>
    <link rel="stylesheet" href="TDashboard.css?v=<?= time() ?>">
</head>

<body>
<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP TECHNICIAN</h2>
    </div>
    <ul>
        <li class="active"><a href="../TDashboard/TDashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li><a href="../TNotification/TNotification.php">
            <img src="../../pic/notifb.png" alt="Requests" class="sidebar-icon">
            Notification
        </a></li>
        <li><a href="../TRequest/TRequest.php">
            <img src="../../pic/request.png" alt="Users" class="sidebar-icon">
            Request
        </a></li>
        <li><a href="../THistory/THistory.php">
            <img src="../../pic/historyb.png" alt="Technicians" class="sidebar-icon">
            History 
        </a></li>
        <li><a href="../TInventory/TInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
        <li><a href="../TProfile/TProfile.php">
            <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
            Profile
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<div class="main-content">
    <header><h1>Technician Dashboard</h1></header>

    <div class="stats-row">
        <div class="stat-card">
            <h3>Rating</h3>
            <h1><?= $tech['rating'] ?> ★</h1>
        </div>

        <div class="stat-card">
            <h3>Working Hours</h3>
            <h1><?= $tech['working_hours'] ?> hrs</h1>
        </div>

        <div class="stat-card">
            <h3>Completed Tasks</h3>
            <h1><?= $tech['tasks_completed'] ?></h1>
        </div>
    </div>

    <h2 class="section-title">Recent Requests</h2>

    <div class="requests-row">
        <?php foreach ($requests as $r): ?>
            <div class="req-card">
                <h3><?= htmlspecialchars($r['unit_name']) ?></h3>
                <p><?= htmlspecialchars($r['request_details']) ?></p>
                <p><b>Status:</b> <?= $r['status'] ?></p>

                <button class="view-btn" 
                        data-request='<?= htmlspecialchars(json_encode($r), ENT_QUOTES, 'UTF-8') ?>'>
                    View
                </button>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal Structure -->
<div id="requestModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Request Details</h2>
            <button class="close-btn">&times;</button>
        </div>
        <div class="modal-body" id="modalBody">
            <!-- Content will be populated by JavaScript -->
        </div>
        <div class="modal-actions">
            <button class="btn-secondary" id="fullDetailsLink">Close</button>
     
        </div>
    </div>
</div>

<script src="TDashboard.js?v=<?= time() ?>"></script>
</body>
</html>