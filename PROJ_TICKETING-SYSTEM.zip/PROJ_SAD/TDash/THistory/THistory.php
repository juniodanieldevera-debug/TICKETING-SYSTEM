<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: ../../auth/login.php");
    exit();
}

$account_id = $_SESSION['account_id'];

/* GET TECHNICIAN */
$techQuery = $conn->prepare("SELECT * FROM technicians WHERE account_id = ?");
$techQuery->execute([$account_id]);
$tech = $techQuery->fetch(PDO::FETCH_ASSOC);

if (!$tech) {
    die("Technician not found.");
}

/* GET COMPLETED TASKS - Fixed query without phone_number */
$historyQuery = $conn->prepare("
    SELECT ur.* 
    FROM user_requests ur 
    WHERE ur.tech_id = ? AND ur.status = 'Completed'
    ORDER BY ur.created_at DESC
");
$historyQuery->execute([$tech['tech_id']]);
$tasks = $historyQuery->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="THistory.css?v=<?= time() ?>">
    <title>Technician History</title>
</head>

<body>
<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP TECHNICIAN</h2>
    </div>
    <ul>
        <li><a href="../TDashboard/TDashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li><a href="../TNotification/TNotification.php">
            <img src="../../pic/notifb.png" alt="Requests" class="sidebar-icon">
            Notification
        </a></li>
        <li><a href="../TRequest/TRequest.php">
            <img src="../../pic/request.png" alt="Users" class="sidebar-icon">
            Request
        </a></li>
        <li class="active"><a href="../THistory/THistory.php">
            <img src="../../pic/historyb.png" alt="Technicians" class="sidebar-icon">
            History 
        </a></li>
        <li><a href="../TInventory/TInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
         <li><a href="../TProfile/TProfile.php">
            <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
            Profile
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<div class="main-content">

    <div class="header-bar">
        <header>
        <h1>History</h1>
        </header>
    </div>

    <div class="search-filter">
        <input type="text" placeholder="Search completed task...">
        <input type="date">
    </div>

    <div class="history-list">

        <?php if (empty($tasks)): ?>
            <p class="no-data">No completed tasks yet.</p>

        <?php else: foreach ($tasks as $t): ?>
            <div class="history-card">
                <div class="left">
                    <p class="room"><?= $t['floor'] ?> FLOOR • <?= $t['department'] ?></p>
                    <h3><?= $t['fname'] . " " . $t['lname'] ?></h3>
                    <p class="desc"><?= $t['request_details'] ?></p>
                </div>

                <div class="right">
                    <span class="status">COMPLETED</span>
                    <button class="view-btn" onclick="openModal(<?= htmlspecialchars(json_encode($t), ENT_QUOTES, 'UTF-8') ?>)">VIEW</button>
                </div>
            </div>
        <?php endforeach; endif; ?>

    </div>

</div>

<!-- Modal -->
<div id="taskModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Task Details</h2>
        <div class="task-details">
            <div class="detail-row">
                <div class="detail-label">Request ID:</div>
                <div class="detail-value" id="modal-id"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Requester:</div>
                <div class="detail-value" id="modal-name"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Location:</div>
                <div class="detail-value" id="modal-location"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Room:</div>
                <div class="detail-value" id="modal-room"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Request Details:</div>
                <div class="detail-value" id="modal-details"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Priority:</div>
                <div class="detail-value" id="modal-priority"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Created At:</div>
                <div class="detail-value" id="modal-created"></div>
            </div>
            <div class="detail-row">
                <div class="detail-label">Completed At:</div>
                <div class="detail-value" id="modal-completed"></div>
            </div>
            <div class="detail-row" id="modal-notes-row" style="display: none;">
                <div class="detail-label">Technician Notes:</div>
                <div class="detail-value" id="modal-notes"></div>
            </div>
        </div>
    </div>
</div>

<script>
function openModal(task) {
    // Populate modal with task data
    document.getElementById('modal-id').textContent = '#' + task.id;
    document.getElementById('modal-name').textContent = task.fname + ' ' + task.lname;
    document.getElementById('modal-location').textContent = task.floor + ' Floor • ' + task.department;
    document.getElementById('modal-room').textContent = task.room || 'N/A';
    document.getElementById('modal-details').textContent = task.request_details;
    document.getElementById('modal-priority').textContent = task.priority || 'Normal';
    document.getElementById('modal-created').textContent = formatDate(task.created_at);
    document.getElementById('modal-completed').textContent = formatDate(task.completed_at || task.updated_at);
    
    // Show notes if available
    if (task.tech_notes) {
        document.getElementById('modal-notes').textContent = task.tech_notes;
        document.getElementById('modal-notes-row').style.display = 'flex';
    } else {
        document.getElementById('modal-notes-row').style.display = 'none';
    }
    
    // Show modal
    document.getElementById('taskModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('taskModal').style.display = 'none';
}

function formatDate(dateString) {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('taskModal');
    if (event.target === modal) {
        closeModal();
    }
}

// Close modal with ESC key
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeModal();
    }
});
</script>

</body>
</html>