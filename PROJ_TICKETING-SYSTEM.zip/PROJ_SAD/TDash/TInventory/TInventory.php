<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: ../../auth/login.php");
    exit();
}

$account_id = $_SESSION['account_id'];

/* FETCH TECHNICIAN INFO */
$techQuery = $conn->prepare("SELECT * FROM technicians WHERE account_id = ?");
$techQuery->execute([$account_id]);
$tech = $techQuery->fetch(PDO::FETCH_ASSOC);

if (!$tech) {
    die("Technician record not found");
}

/* CHECK IF REASON COLUMN EXISTS */
$columnCheck = $conn->query("SHOW COLUMNS FROM material_requests LIKE 'reason'");
$reasonColumnExists = $columnCheck->rowCount() > 0;

/* FETCH INVENTORY ITEMS */
$search = $_GET['q'] ?? '';
$filter_cat = $_GET['cat'] ?? '';

$sql = "SELECT * FROM inventory WHERE 1=1";
$params = [];

if ($search !== '') {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
}
if ($filter_cat !== '') {
    $sql .= " AND category = ?";
    $params[] = $filter_cat;
}

$sql .= " ORDER BY name ASC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* FETCH MY MATERIAL REQUESTS */
$myRequestsQuery = $conn->prepare("
    SELECT mr.*, inv.name as item_name, inv.unit_number 
    FROM material_requests mr 
    JOIN inventory inv ON mr.item_id = inv.item_id 
    WHERE mr.tech_id = ? 
    ORDER BY mr.created_at DESC
");
$myRequestsQuery->execute([$tech['tech_id']]);
$myRequests = $myRequestsQuery->fetchAll(PDO::FETCH_ASSOC);

/* FETCH CATEGORIES */
$catStmt = $conn->prepare("SELECT DISTINCT category FROM inventory WHERE category IS NOT NULL ORDER BY category");
$catStmt->execute();
$cats = $catStmt->fetchAll(PDO::FETCH_COLUMN);

/* HANDLE MATERIAL REQUEST */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_item'])) {
    $item_id = (int)$_POST['item_id'];
    $quantity = (int)$_POST['quantity'];
    $reason = trim($_POST['reason'] ?? '');
    
    if ($quantity > 0) {
        if ($reasonColumnExists) {
            // If reason column exists, include it in the insert
            $requestStmt = $conn->prepare("
                INSERT INTO material_requests (tech_id, item_id, quantity, reason, status) 
                VALUES (?, ?, ?, ?, 'Pending')
            ");
            $requestStmt->execute([$tech['tech_id'], $item_id, $quantity, $reason]);
        } else {
            // If reason column doesn't exist, insert without it
            $requestStmt = $conn->prepare("
                INSERT INTO material_requests (tech_id, item_id, quantity, status) 
                VALUES (?, ?, ?, 'Pending')
            ");
            $requestStmt->execute([$tech['tech_id'], $item_id, $quantity]);
        }
        
        header("Location: TInventory.php?success=request_submitted");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Technician Inventory</title>
    <link rel="stylesheet" href="TInventory.css?v=<?= time() ?>">
</head>
<body>


<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP TECHNICIAN</h2>
    </div>
    <ul>
        <li><a href="../TDashboard/TDashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li><a href="../TNotification/TNotification.php">
            <img src="../../pic/notifb.png" alt="Requests" class="sidebar-icon">
            Notification
        </a></li>
        <li><a href="../TRequest/TRequest.php">
            <img src="../../pic/request.png" alt="Users" class="sidebar-icon">
            Request
        </a></li>
        <li><a href="../THistory/THistory.php">
            <img src="../../pic/historyb.png" alt="Technicians" class="sidebar-icon">
            History 
        </a></li>
        <li class="active"><a href="../TInventory/TInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
          <li><a href="../TProfile/TProfile.php">
            <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
            Profile
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<div class="main-content">
    <div class="header-bg">
   <header>     
        <h1>Inventory Management</h1>
        <p>Request materials for your maintenance tasks</p>
   </header>


    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert success">
            <?php 
            if ($_GET['success'] === 'request_submitted') echo "Material request submitted successfully!";
            ?>
        </div>
    <?php endif; ?>

    <!-- INVENTORY SEARCH AND FILTER -->
    <div class="toolbar">
        <form method="GET" class="search-form">
            <input type="text" name="q" placeholder="Search items..." value="<?= htmlspecialchars($search) ?>">
            <select name="cat">
                <option value="">All Categories</option>
                <?php foreach($cats as $c): ?>
                    <option value="<?= htmlspecialchars($c) ?>" <?= $filter_cat===$c ? 'selected' : '' ?>>
                        <?= htmlspecialchars($c) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn">Search</button>
            <a href="TInventory.php" class="btn secondary">Clear</a>
        </form>
    </div>

    <!-- INVENTORY ITEMS -->
    <section class="inventory-section">
        <h2 class="section-title">Available Items</h2>
        
        <?php if (empty($items)): ?>
            <div class="no-items">
                <p>No inventory items found.</p>
            </div>
        <?php else: ?>
            <div class="inventory-grid">
                <?php foreach ($items as $item): ?>
                    <div class="inventory-card">
                        <div class="item-header">
                            <h3><?= htmlspecialchars($item['name']) ?></h3>
                            <span class="stock-badge status-<?= strtolower(str_replace(' ', '-', $item['status'])) ?>">
                                <?= $item['status'] ?>
                            </span>
                        </div>
                        
                        <div class="item-details">
                            <p><strong>Unit No:</strong> <?= htmlspecialchars($item['unit_number']) ?></p>
                            <p><strong>Category:</strong> <?= htmlspecialchars($item['category']) ?></p>
                            <p><strong>Supplier:</strong> <?= htmlspecialchars($item['supplier']) ?></p>
                            <p><strong>Stock:</strong> <?= $item['stock'] ?> units</p>
                        </div>
                        
                        <?php if ($item['status'] !== 'Out of Stock'): ?>
                        <div class="item-actions">
                            <button class="btn primary request-btn" 
                                    data-item-id="<?= $item['item_id'] ?>"
                                    data-item-name="<?= htmlspecialchars($item['name']) ?>"
                                    data-max-stock="<?= $item['stock'] ?>">
                                Request Item
                            </button>
                        </div>
                        <?php else: ?>
                        <div class="item-actions">
                            <button class="btn disabled" disabled>Out of Stock</button>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- MY MATERIAL REQUESTS -->
    <section class="requests-section">
        <h2 class="section-title">My Material Requests</h2>
        
        <?php if (empty($myRequests)): ?>
            <div class="no-requests">
                <p>You haven't made any material requests yet.</p>
            </div>
        <?php else: ?>
            <div class="requests-table">
                <table>
                    <thead>
                        <tr>
                            <th>Item Name</th>
                            <th>Unit No</th>
                            <th>Quantity</th>
                            <?php if ($reasonColumnExists): ?>
                                <th>Reason</th>
                            <?php endif; ?>
                            <th>Status</th>
                            <th>Date Requested</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($myRequests as $request): ?>
                            <tr>
                                <td><?= htmlspecialchars($request['item_name']) ?></td>
                                <td><?= htmlspecialchars($request['unit_number']) ?></td>
                                <td><?= $request['quantity'] ?></td>
                                <?php if ($reasonColumnExists): ?>
                                    <td><?= htmlspecialchars($request['reason'] ?? 'No reason provided') ?></td>
                                <?php endif; ?>
                                <td>
                                    <span class="status-badge status-<?= strtolower($request['status']) ?>">
                                        <?= $request['status'] ?>
                                    </span>
                                </td>
                                <td><?= date('M j, Y g:i A', strtotime($request['created_at'])) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
</div>

<!-- REQUEST MODAL -->
<div id="requestModal" class="modal-bg">
    <div class="modal-content">
        <h3>Request Material</h3>
        <div id="itemDetails" class="item-details-modal">
            <!-- Details will be populated by JavaScript -->
        </div>
        <form method="POST" id="requestForm">
            <input type="hidden" name="request_item" value="1">
            <input type="hidden" name="item_id" id="modalItemId">
            
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" name="quantity" id="quantity" min="1" value="1" required>
                <span id="maxStockText" class="max-stock"></span>
            </div>
            
            <?php if ($reasonColumnExists): ?>
            <div class="form-group">
                <label for="reason">Reason/Purpose:</label>
                <textarea name="reason" id="reason" placeholder="Explain why you need this item (e.g., for repair, replacement, maintenance task)" rows="3"></textarea>
            </div>
            <?php endif; ?>
            
            <div class="modal-actions">
                <button type="submit" class="btn primary">Submit Request</button>
                <button type="button" class="btn secondary" id="closeModal">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const requestBtns = document.querySelectorAll('.request-btn');
    const modal = document.getElementById('requestModal');
    const itemDetails = document.getElementById('itemDetails');
    const modalItemId = document.getElementById('modalItemId');
    const quantityInput = document.getElementById('quantity');
    const maxStockText = document.getElementById('maxStockText');
    const closeModal = document.getElementById('closeModal');
    const requestForm = document.getElementById('requestForm');

    requestBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const itemId = this.dataset.itemId;
            const itemName = this.dataset.itemName;
            const maxStock = this.dataset.maxStock;

            modalItemId.value = itemId;
            quantityInput.max = maxStock;
            quantityInput.value = 1;
            maxStockText.textContent = `(Max: ${maxStock})`;
            
            itemDetails.innerHTML = `
                <p><strong>Item:</strong> ${itemName}</p>
                <p><strong>Available Stock:</strong> ${maxStock}</p>
            `;

            modal.style.display = 'flex';
        });
    });

    closeModal.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    // Validate quantity input
    quantityInput.addEventListener('change', function() {
        const max = parseInt(this.max);
        const value = parseInt(this.value);
        
        if (value > max) {
            this.value = max;
            alert(`Maximum available stock is ${max}`);
        }
        
        if (value < 1) {
            this.value = 1;
        }
    });

    // Prevent multiple submissions
    requestForm.addEventListener('submit', function() {
        const submitBtn = this.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
    });
});
</script>

</body>
</html>