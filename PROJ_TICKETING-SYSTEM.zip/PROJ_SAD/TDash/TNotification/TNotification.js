// Notification Management Functions
function markAsRead(notificationId) {
    const notificationItem = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
    if (notificationItem) {
        // Remove unread class and add read class
        notificationItem.classList.remove('unread');
        notificationItem.classList.add('read');
        
        // Hide the mark as read button
        const markReadBtn = notificationItem.querySelector('.btn-mark-read');
        if (markReadBtn) {
            markReadBtn.style.display = 'none';
        }
        
        // Update notification icon
        const notificationIcon = notificationItem.querySelector('.notification-icon');
        notificationIcon.style.background = '#f1f5f9';
        notificationIcon.style.color = '#64748b';
        
        // Update unread count in sidebar
        updateUnreadCount(-1);
        
        // In a real application, you would send an AJAX request to the server
        console.log(`Marked notification ${notificationId} as read`);
    }
}

function markAllAsRead() {
    const unreadNotifications = document.querySelectorAll('.notification-item.unread');
    
    unreadNotifications.forEach(notification => {
        const notificationId = notification.dataset.id;
        markAsRead(notificationId);
    });
    
    // Show confirmation message
    showToast('All notifications marked as read');
}

function deleteNotification(notificationId) {
    const notificationItem = document.querySelector(`.notification-item[data-id="${notificationId}"]`);
    if (notificationItem) {
        // Check if it's unread to update count
        const wasUnread = notificationItem.classList.contains('unread');
        
        // Remove the notification element
        notificationItem.style.opacity = '0';
        notificationItem.style.height = '0';
        notificationItem.style.padding = '0';
        notificationItem.style.margin = '0';
        notificationItem.style.border = 'none';
        
        setTimeout(() => {
            notificationItem.remove();
            
            // Check if no notifications left
            const notificationsList = document.querySelector('.notifications-list');
            if (!notificationsList.children.length) {
                showEmptyState();
            }
        }, 300);
        
        // Update unread count if necessary
        if (wasUnread) {
            updateUnreadCount(-1);
        }
        
        // In a real application, you would send an AJAX request to the server
        console.log(`Deleted notification ${notificationId}`);
    }
}

function updateUnreadCount(change) {
    const badge = document.querySelector('.notification-badge');
    let currentCount = badge ? parseInt(badge.textContent) : 0;
    
    currentCount += change;
    
    if (currentCount <= 0) {
        // Remove badge if no unread notifications
        if (badge) {
            badge.remove();
        }
    } else {
        // Update or create badge
        if (badge) {
            badge.textContent = currentCount;
        } else {
            const navLink = document.querySelector('.nav-link[href="notifications.php"]');
            if (navLink) {
                const newBadge = document.createElement('span');
                newBadge.className = 'notification-badge';
                newBadge.textContent = currentCount;
                navLink.appendChild(newBadge);
            }
        }
    }
}

function showEmptyState() {
    const container = document.querySelector('.notifications-container');
    container.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-bell-slash"></i>
            <h3>No notifications</h3>
            <p>You're all caught up! New notifications will appear here.</p>
        </div>
    `;
}

function showToast(message) {
    // Create toast element
    const toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.textContent = message;
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    // Add styles for animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
            document.head.removeChild(style);
        }, 300);
    }, 3000);
}

// Simulate real-time notifications (for demo purposes)
function simulateNewNotification() {
    const types = ['assignment', 'rating', 'inventory'];
    const priorities = ['high', 'medium'];
    const type = types[Math.floor(Math.random() * types.length)];
    const priority = priorities[Math.floor(Math.random() * priorities.length)];
    
    const notifications = {
        assignment: {
            title: 'New Repair Assignment',
            message: 'You have been assigned to a new maintenance task at Location ' + Math.floor(Math.random() * 100)
        },
        rating: {
            title: 'New Rating Received',
            message: 'A customer rated your service ' + (Math.floor(Math.random() * 2) + 4) + ' stars'
        },
        inventory: {
            title: 'Inventory Update',
            message: 'New stock has been added to the inventory system'
        }
    };
    
    const newNotification = {
        id: Date.now(),
        type: type,
        title: notifications[type].title,
        message: notifications[type].message,
        time: 'Just now',
        read: false,
        priority: priority
    };
    
    addNotificationToDOM(newNotification);
}

function addNotificationToDOM(notification) {
    const notificationsList = document.querySelector('.notifications-list');
    const emptyState = document.querySelector('.empty-state');
    
    // Remove empty state if it exists
    if (emptyState) {
        emptyState.remove();
    }
    
    // Create notification element
    const notificationElement = document.createElement('div');
    notificationElement.className = `notification-item unread priority-${notification.priority}`;
    notificationElement.dataset.id = notification.id;
    
    notificationElement.innerHTML = `
        <div class="notification-icon">
            <i class="fas ${
                notification.type === 'assignment' ? 'fa-tools' :
                notification.type === 'rating' ? 'fa-star' :
                notification.type === 'inventory' ? 'fa-boxes' : 'fa-bell'
            }"></i>
        </div>
        <div class="notification-content">
            <div class="notification-header">
                <h4 class="notification-title">${notification.title}</h4>
                <span class="notification-time">${notification.time}</span>
            </div>
            <p class="notification-message">${notification.message}</p>
            ${notification.priority === 'high' ? '<span class="priority-badge high-priority">High Priority</span>' : ''}
        </div>
        <div class="notification-actions">
            <button class="btn-mark-read" onclick="markAsRead(${notification.id})">
                <i class="fas fa-check"></i>
            </button>
            <button class="btn-delete" onclick="deleteNotification(${notification.id})">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    // Add to top of list
    if (notificationsList.firstChild) {
        notificationsList.insertBefore(notificationElement, notificationsList.firstChild);
    } else {
        notificationsList.appendChild(notificationElement);
    }
    
    // Update unread count
    updateUnreadCount(1);
    
    // Show notification alert
    showToast('New notification received!');
}

// Demo: Add a new notification every 30 seconds (for testing)
// setInterval(simulateNewNotification, 30000);

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    console.log('TNotifications system initialized');
});