<?php
session_start();

// Block non-technicians
if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    $_SESSION['error_message'] = "Please log in as a technician to access this page";
    header("Location: ../../auth/login.php");
    exit();
}

$account_id = $_SESSION['account_id'];

// Include files with error handling
try {
    require_once '../../config/db_connect.php';
    require_once '../../config/notification_functions.php';
} catch (Exception $e) {
    error_log("Include Error: " . $e->getMessage());
    die("System error. Please contact administrator.");
}

/* FETCH TECHNICIAN INFO */
try {
    $techQuery = $conn->prepare("SELECT * FROM technicians WHERE account_id = :account_id");
    $techQuery->bindParam(':account_id', $account_id, PDO::PARAM_INT);
    $techQuery->execute();
    $tech = $techQuery->fetch(PDO::FETCH_ASSOC);

    if (!$tech) {
        throw new Exception("Technician record not found for account_id = " . $account_id);
    }
    
} catch (Exception $e) {
    error_log("Technician Fetch Error: " . $e->getMessage());
    die("Technician record not found. Please contact administrator.");
}

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['mark_as_read'])) {
            $notification_id = filter_input(INPUT_POST, 'notification_id', FILTER_VALIDATE_INT);
            
            if (!$notification_id) {
                throw new Exception("Invalid notification ID");
            }
            
            if (markNotificationAsRead($notification_id)) {
                $_SESSION['success_message'] = "Notification marked as read";
            } else {
                $_SESSION['error_message'] = "Failed to mark notification as read";
            }
        }
        
        if (isset($_POST['mark_all_read'])) {
            if (markAllNotificationsAsRead($account_id)) {
                $_SESSION['success_message'] = "All notifications marked as read";
            } else {
                $_SESSION['error_message'] = "Failed to mark all notifications as read";
            }
        }
        
    } catch (Exception $e) {
        error_log("POST Action Error: " . $e->getMessage());
        $_SESSION['error_message'] = "An error occurred. Please try again.";
    }
    
    header("Location: TNotification.php");
    exit();
}

// Get filter and notifications
try {
    $filter = filter_input(INPUT_GET, 'filter', FILTER_SANITIZE_STRING) ?? 'all';
    if (!in_array($filter, ['all', 'unread'])) {
        $filter = 'all';
    }
    
    $notifications = getTechnicianNotifications($account_id, $filter);
    $unread_count = getTechnicianUnreadCount($account_id);
    
} catch (Exception $e) {
    error_log("Notification Fetch Error: " . $e->getMessage());
    $notifications = [];
    $unread_count = 0;
    $_SESSION['error_message'] = "Unable to load notifications";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Technician Notifications</title>
    <link rel="stylesheet" href="TNotification.css?v=<?= time() ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .error-banner {
            background: #f8d7da;
            color: #721c24;
            padding: 12px 20px;
            border-radius: 4px;
            margin: 20px;
            border: 1px solid #f5c6cb;
            text-align: center;
        }
        
        .success-banner {
            background: #d4edda;
            color: #155724;
            padding: 12px 20px;
            border-radius: 4px;
            margin: 20px;
            border: 1px solid #c3e6cb;
            text-align: center;
        }
    </style>
</head>

<body>
<div class="page-container">
    <aside class="sidebar">
        <div class="logo">
            <img src="../../pic/moplogo.png" alt="MOP Logo">
            <h2>MOP TECHNICIAN</h2>
        </div>
        <ul>
            <li><a href="../TDashboard/TDashboard.php">
                <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
                Dashboard
            </a></li>
            <li class="active"><a href="../TNotification/TNotification.php">
                <img src="../../pic/notifb.png" alt="Notifications" class="sidebar-icon">
                Notification <?= $unread_count > 0 ? "<span class='nav-badge'>$unread_count</span>" : '' ?>
            </a></li>
            <li><a href="../TRequest/TRequest.php">
                <img src="../../pic/request.png" alt="Requests" class="sidebar-icon">
                Request
            </a></li>
            <li><a href="../THistory/THistory.php">
                <img src="../../pic/historyb.png" alt="History" class="sidebar-icon">
                History 
            </a></li>
            <li><a href="../TInventory/TInventory.php">
                <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
                Inventory
            </a></li>
            <li><a href="../TProfile/TProfile.php">
                <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
                Profile
            </a></li>
            <li class="logout"><a href="../../auth/logout.php">
                <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
                Logout
            </a></li>
        </ul>
    </aside>

    <div class="main-content">
        <header>
            <h1>Technician Notifications</h1>
        </header>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="error-banner">
                <?= htmlspecialchars($_SESSION['error_message']) ?>
            </div>
            <?php unset($_SESSION['error_message']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-banner">
                <?= htmlspecialchars($_SESSION['success_message']) ?>
            </div>
            <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>

        <div class="notification-container">
            <div class="notification-header">
                <button class="back-btn" onclick="window.location.href='../TDashboard/TDashboard.php'">←</button>
                <div class="filter-buttons">
                    <button class="filter <?= $filter === 'all' ? 'active' : '' ?>" onclick="setFilter('all')">
                        ALL <?= $unread_count > 0 ? "<span class='badge'>$unread_count</span>" : '' ?>
                    </button>
                    <button class="filter <?= $filter === 'unread' ? 'active' : '' ?>" onclick="setFilter('unread')">UNREAD</button>
                </div>
                <?php if ($unread_count > 0): ?>
                    <form method="POST" style="display: inline;">
                        <button type="submit" name="mark_all_read" class="mark-all-btn">
                            <i class="fas fa-check-double"></i> Mark All as Read
                        </button>
                    </form>
                <?php endif; ?>
            </div>

            <div class="notification-list">
                <?php if (empty($notifications)): ?>
                    <div class="no-notifications">
                        <i class="fas fa-bell-slash"></i>
                        <p>No notifications found</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?= $notification['is_read'] ? 'read' : 'unread' ?>">
                            <div class="notification-icon">
                                <?php
                                $icon = 'fas fa-bell';
                                $color = '#004aad';
                                switch ($notification['type']) {
                                    case 'assignment':
                                        $icon = 'fas fa-user-check';
                                        $color = '#28a745';
                                        break;
                                    case 'status_update':
                                        $icon = 'fas fa-sync-alt';
                                        $color = '#17a2b8';
                                        break;
                                    case 'message':
                                        $icon = 'fas fa-comment';
                                        $color = '#6f42c1';
                                        break;
                                    case 'system':
                                    default:
                                        $icon = 'fas fa-bell';
                                        $color = '#004aad';
                                }
                                ?>
                                <i class="<?= $icon ?>" style="color: <?= $color ?>"></i>
                            </div>
                            <div class="notification-text">
                                <p><strong><?= htmlspecialchars($notification['title']) ?></strong></p>
                                <p><?= htmlspecialchars($notification['message']) ?></p>
                                <span class="time"><?= timeAgo($notification['created_at']) ?></span>
                            </div>
                            <div class="notification-actions">
                                <?php if (!$notification['is_read']): ?>
                                    <form method="POST" style="display: inline;">
                                        <input type="hidden" name="notification_id" value="<?= $notification['id'] ?>">
                                        <button type="submit" name="mark_as_read" class="mark-read-btn" title="Mark as Read">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                                <?php if ($notification['related_request_id']): ?>
                                    <button class="view-btn" onclick="viewRequest(<?= $notification['related_request_id'] ?>)">VIEW</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
function setFilter(filter) {
    if (!filter || !['all', 'unread'].includes(filter)) {
        console.error('Invalid filter:', filter);
        return;
    }
    
    try {
        window.location.href = `TNotification.php?filter=${filter}`;
    } catch (error) {
        console.error('Filter error:', error);
        alert('Unable to change filter. Please refresh the page.');
    }
}

function viewRequest(requestId) {
    if (!requestId || isNaN(requestId)) {
        alert('Invalid request ID');
        return;
    }
    
    try {
        window.location.href = `../TRequest/TRequest.php?view=${requestId}`;
    } catch (error) {
        console.error('Navigation error:', error);
        alert('Unable to view request. Please try again.');
    }
}

// Auto-refresh notifications every 30 seconds
setTimeout(function() {
    window.location.reload();
}, 30000);

// Global error handler
window.addEventListener('error', function(event) {
    console.error('JavaScript Error:', event.error);
});
</script>

</body>
</html>