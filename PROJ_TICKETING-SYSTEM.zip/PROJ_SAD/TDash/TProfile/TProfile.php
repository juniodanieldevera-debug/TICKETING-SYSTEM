<?php
session_start();
require '../../config/db_connect.php';

// CHECK LOGIN
if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: ../../auth/login.php");
    exit;
}

$account_id = $_SESSION['account_id'];

// GET TECHNICIAN INFO
try {
    $stmt = $conn->prepare("SELECT * FROM technicians WHERE account_id = ?");
    $stmt->execute([$account_id]);
    $technician = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$technician) {
        die("Technician profile not found.");
    }
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}

// GET UNREAD NOTIFICATION COUNT
try {
    $stmtUnread = $conn->prepare("
        SELECT COUNT(*) 
        FROM notifications 
        WHERE account_id = ? AND is_read = 0
    ");
    $stmtUnread->execute([$account_id]);
    $unread_count = (int)$stmtUnread->fetchColumn();
} catch (Exception $e) {
    $unread_count = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Technician Profile</title>
<link rel="stylesheet" href="TProfile.css?v=<?= time() ?>">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
/* ID Display Styling */
.id-display {
    background: #e7f3ff;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #004aad;
}

.id-display h3 {
    margin: 0 0 10px 0;
    color: #004aad;
    font-size: 16px;
}

.id-info {
    display: flex;
    gap: 30px;
    flex-wrap: wrap;
}

.id-item {
    display: flex;
    flex-direction: column;
}

.id-label {
    font-size: 12px;
    color: #666;
    font-weight: 500;
    margin-bottom: 4px;
}

.id-value {
    font-size: 16px;
    color: #004aad;
    font-weight: bold;
}
</style>

</head>
<body>

<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP TECHNICIAN</h2>
    </div>
    <ul>
        <li><a href="../TDashboard/TDashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li><a href="../TNotification/TNotification.php">
            <img src="../../pic/notifb.png" alt="Requests" class="sidebar-icon">
            Notification
            <?php if ($unread_count > 0): ?>
                <span class="nav-badge"><?= $unread_count ?></span>
            <?php endif; ?>
        </a></li>
        <li><a href="../TRequest/TRequest.php">
            <img src="../../pic/request.png" alt="Users" class="sidebar-icon">
            Request
        </a></li>
        <li><a href="../THistory/THistory.php">
            <img src="../../pic/historyb.png" alt="Technicians" class="sidebar-icon">
            History 
        </a></li>
        <li><a href="../TInventory/TInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
        <li class="active"><a href="../TProfile/TProfile.php">
            <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
            Profile
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<div class="main-content">
    <div class="header-bg">
        <header>     
            <h1>Technician Profile</h1>
        </header>
    </div>

    <section class="profile-section">
        <div class="profile-container">
            <div class="profile-header">
                <h2>My Profile</h2>
                <button id="editBtn" class="edit-btn">Edit Profile</button>
            </div>

            <!-- ID DISPLAY SECTION -->
            <div class="id-display">
                <h3>Technician Information</h3>
                <div class="id-info">
                    <div class="id-item">
                        <span class="id-label">Technician ID</span>
                        <span class="id-value">#<?= str_pad($technician['tech_id'], 5, '0', STR_PAD_LEFT) ?></span>
                    </div>
                    <div class="id-item">
                        <span class="id-label">Email</span>
                        <span class="id-value"><?= htmlspecialchars($technician['email']) ?></span>
                    </div>
                    <div class="id-item">
                        <span class="id-label">Specialization</span>
                        <span class="id-value"><?= htmlspecialchars($technician['specialization']) ?></span>
                    </div>
                    <div class="id-item">
                        <span class="id-label">Rating</span>
                        <span class="id-value">⭐ <?= number_format($technician['rating'], 1) ?> / 5.0</span>
                    </div>
                </div>
            </div>

            <form id="profileForm" method="POST" action="update_tech_profile.php">
                <input type="hidden" name="account_id" value="<?= $technician['account_id'] ?>">

                <div class="form-row">
                    <input type="text" name="fname" placeholder="First Name" value="<?= htmlspecialchars($technician['fname'] ?? '') ?>" disabled>
                    <input type="text" name="mname" placeholder="Middle Name" value="<?= htmlspecialchars($technician['mname'] ?? '') ?>" disabled>
                    <input type="text" name="lname" placeholder="Last Name" value="<?= htmlspecialchars($technician['lname'] ?? '') ?>" disabled>
                </div>

                <div class="form-row">
                    <input type="text" name="contact_no" placeholder="Contact No" value="<?= htmlspecialchars($technician['contact_no'] ?? '') ?>" disabled>
                    <input type="text" placeholder="Status" value="<?= htmlspecialchars($technician['status'] ?? 'Available') ?>" disabled>
                    <input type="text" placeholder="Date Registered" value="<?= htmlspecialchars($technician['date_registered'] ?? 'Not set') ?>" disabled>
                </div>

                <div class="form-row">
                    <input type="text" placeholder="Tasks Completed" value="<?= htmlspecialchars($technician['tasks_completed'] ?? '0') ?>" disabled>
                    <input type="text" placeholder="Working Hours" value="<?= htmlspecialchars($technician['working_hours'] ?? '0') ?> hrs" disabled>
                </div>

                <div class="form-buttons">
                    <button type="button" class="cancel" disabled>Cancel</button>
                    <button type="submit" class="save" disabled>Save Changes</button>
                </div>

                <h3>Change Password</h3>
                <div class="form-row">
                    <input type="password" name="current_password" placeholder="Current Password" disabled>
                    <input type="password" name="new_password" placeholder="New Password" disabled>
                    <input type="password" name="confirm_password" placeholder="Confirm Password" disabled>
                </div>

                <div class="form-buttons">
                    <button type="button" class="cancel" disabled>Cancel</button>
                    <button type="submit" class="save" disabled>Save Password</button>
                </div>
            </form>

        </div>
    </section>
</div>

<script>
// Enable edit mode
const editBtn = document.getElementById('editBtn');
const form = document.getElementById('profileForm');
const inputs = form.querySelectorAll('input:not([type="hidden"])');
const cancelBtns = form.querySelectorAll('.cancel');
const saveBtns = form.querySelectorAll('.save');

editBtn.addEventListener('click', () => {
    inputs.forEach(i => {
        // Only enable editable fields
        if (i.name === 'fname' || i.name === 'mname' || i.name === 'lname' || 
            i.name === 'contact_no' || i.type === 'password') {
            i.disabled = false;
        }
    });
    cancelBtns.forEach(c => c.disabled = false);
    saveBtns.forEach(s => s.disabled = false);

    editBtn.textContent = "Editing Mode";
    editBtn.classList.add("editing");
});

// Cancel edit → reload page
cancelBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        window.location.reload();
    });
});

// SweetAlert messages
<?php if (isset($_SESSION['success'])): ?>
Swal.fire({
    icon: 'success',
    title: 'Success',
    text: '<?= $_SESSION['success']; ?>',
    timer: 2500,
    showConfirmButton: false
});
<?php unset($_SESSION['success']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: '<?= $_SESSION['error']; ?>',
    timer: 3000,
    showConfirmButton: true
});
<?php unset($_SESSION['error']); endif; ?>
</script>

</body>
</html>