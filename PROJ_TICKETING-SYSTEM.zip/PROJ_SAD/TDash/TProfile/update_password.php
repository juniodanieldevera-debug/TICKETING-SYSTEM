<?php
session_start();
require '../../config/db_connect.php';

$userId = $_SESSION['account_id']; // DO NOT use user_id

$current = $_POST['current_password'];
$new = $_POST['new_password'];
$confirm = $_POST['confirm_password'];

if ($new !== $confirm) {
    echo "Password mismatch";
    exit;
}

// GET CURRENT HASH
$stmt = $conn->prepare("SELECT password FROM accounts WHERE account_id = ?");
$stmt->execute([$userId]);
$row = $stmt->fetch();

if (!$row || !password_verify($current, $row['password'])) {
    echo "Incorrect current password";
    exit;
}

$newHash = password_hash($new, PASSWORD_BCRYPT);

$update = $conn->prepare("UPDATE accounts SET password = ? WHERE account_id = ?");
$update->execute([$newHash, $userId]);

echo "success";
?>