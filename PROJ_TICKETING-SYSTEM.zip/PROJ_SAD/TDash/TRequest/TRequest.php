<?php
session_start();
require_once '../../config/db_connect.php';

if (!isset($_SESSION['account_id']) || $_SESSION['role'] !== 'Technician') {
    header("Location: ../../auth/login.php");
    exit();
}

$account_id = $_SESSION['account_id'];

/* FETCH TECHNICIAN INFO */
$techQuery = $conn->prepare("SELECT * FROM technicians WHERE account_id = ?");
$techQuery->execute([$account_id]);
$tech = $techQuery->fetch(PDO::FETCH_ASSOC);

if (!$tech) {
    die("Technician record not found");
}

/* FETCH AVAILABLE REQUESTS (Pending requests that match technician's specialization) */
$availableQuery = $conn->prepare("
    SELECT ur.*, u.fname, u.lname, u.department, u.room 
    FROM user_requests ur 
    JOIN users u ON ur.user_id = u.user_id 
    WHERE ur.status = 'Pending' 
    AND ur.technician_type = ?
    ORDER BY ur.created_at DESC
");
$availableQuery->execute([$tech['specialization']]);
$availableRequests = $availableQuery->fetchAll(PDO::FETCH_ASSOC);

/* FETCH MY ASSIGNED REQUESTS */
$myRequestsQuery = $conn->prepare("
    SELECT ur.*, u.fname, u.lname, u.department, u.room 
    FROM user_requests ur 
    JOIN users u ON ur.user_id = u.user_id 
    WHERE ur.tech_id = ? 
    AND ur.status IN ('Assigned', 'In Progress')
    ORDER BY ur.created_at DESC
");
$myRequestsQuery->execute([$tech['tech_id']]);
$myRequests = $myRequestsQuery->fetchAll(PDO::FETCH_ASSOC);

/* HANDLE SELF-ASSIGNMENT */
if (isset($_GET['assign']) && isset($_GET['request_id'])) {
    $request_id = (int)$_GET['request_id'];
    
    // Verify request exists and matches technician's specialization
    $verifyQuery = $conn->prepare("
        SELECT * FROM user_requests 
        WHERE id = ? AND status = 'Pending' AND technician_type = ?
    ");
    $verifyQuery->execute([$request_id, $tech['specialization']]);
    $request = $verifyQuery->fetch(PDO::FETCH_ASSOC);
    
    if ($request) {
        // Assign technician to request
        $assignStmt = $conn->prepare("
            UPDATE user_requests 
            SET tech_id = ?, status = 'Assigned' 
            WHERE id = ?
        ");
        $assignStmt->execute([$tech['tech_id'], $request_id]);
        
        // Create notification for user
        require_once '../../config/notification_functions.php';
        createNotification(
            $request['user_id'],
            "Technician Assigned",
            "{$tech['fname']} {$tech['lname']} ({$tech['specialization']}) has been assigned to your maintenance request",
            'assignment',
            $request_id
        );
        
        header("Location: TRequest.php?success=assigned");
        exit();
    }
}

/* HANDLE STATUS UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $request_id = (int)$_POST['request_id'];
    $status = $_POST['status'];
    
    // Verify technician owns this request
    $verifyQuery = $conn->prepare("SELECT * FROM user_requests WHERE id = ? AND tech_id = ?");
    $verifyQuery->execute([$request_id, $tech['tech_id']]);
    $request = $verifyQuery->fetch(PDO::FETCH_ASSOC);
    
    if ($request) {
        $updateStmt = $conn->prepare("UPDATE user_requests SET status = ? WHERE id = ?");
        $updateStmt->execute([$status, $request_id]);
        
        // Create notification for user
        require_once '../../config/notification_functions.php';
        createNotification(
            $request['user_id'],
            "Request Status Updated",
            "Your maintenance request status has been updated to: {$status}",
            'status_update',
            $request_id
        );
        
        header("Location: TRequest.php?success=status_updated");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Technician Requests</title>
    <link rel="stylesheet" href="TRequest.css?v=<?= time() ?>">
</head>
<body>

<aside class="sidebar">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="MOP Logo">
        <h2>MOP TECHNICIAN</h2>
    </div>
    <ul>
        <li><a href="../TDashboard/TDashboard.php">
            <img src="../../pic/dashboard.png" alt="Dashboard" class="sidebar-icon">
            Dashboard
        </a></li>
        <li><a href="../TNotification/TNotification.php">
            <img src="../../pic/notifb.png" alt="Requests" class="sidebar-icon">
            Notification
        </a></li>
        <li  class="active"><a href="../TRequest/TRequest.php">
            <img src="../../pic/request.png" alt="Users" class="sidebar-icon">
            Request
        </a></li>
        <li><a href="../THistory/THistory.php">
            <img src="../../pic/historyb.png" alt="Technicians" class="sidebar-icon">
            History 
        </a></li>
        <li><a href="../TInventory/TInventory.php">
            <img src="../../pic/inventory.png" alt="Inventory" class="sidebar-icon">
            Inventory
        </a></li>
         <li><a href="../TProfile/TProfile.php">
            <img src="../../pic/user.png" alt="Profile" class="sidebar-icon">
            Profile
        </a></li>
        <li class="logout"><a href="../../auth/logout.php">
            <img src="../../pic/logout.png" alt="Logout" class="sidebar-icon">
            Logout
        </a></li>
    </ul>
</aside>

<div class="main-content">
    <div class="header-bg">
      <header>
         <h1>Request Management</h1>
        <p>Specialization: <?= htmlspecialchars($tech['specialization']) ?></p>
      </header>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert success">
            <?php 
            if ($_GET['success'] === 'assigned') echo "Successfully assigned to request!";
            if ($_GET['success'] === 'status_updated') echo "Status updated successfully!";
            ?>
        </div>
    <?php endif; ?>

    <!-- AVAILABLE REQUESTS SECTION -->
    <section class="requests-section">
        <h2 class="section-title">Available Requests</h2>
        
        <?php if (empty($availableRequests)): ?>
            <div class="no-requests">
                <p>No available requests matching your specialization.</p>
            </div>
        <?php else: ?>
            <div class="requests-grid">
                <?php foreach ($availableRequests as $request): ?>
                    <div class="request-card available">
                        <h3><?= htmlspecialchars($request['unit_name'] . ' - ' . $request['unit_number']) ?></h3>
                        <p><strong>Requester:</strong> <?= htmlspecialchars($request['fname'] . ' ' . $request['lname']) ?></p>
                        <p><strong>Department:</strong> <?= htmlspecialchars($request['department']) ?></p>
                        <p><strong>Room:</strong> <?= htmlspecialchars($request['room']) ?></p>
                        <p><strong>Details:</strong> <?= htmlspecialchars(substr($request['request_details'], 0, 100)) ?>...</p>
                        <p><strong>Date Needed:</strong> <?= $request['request_date'] ?></p>
                        
                        <div class="request-actions">
                            <a href="TRequest.php?assign=1&request_id=<?= $request['id'] ?>" 
                               class="btn primary" 
                               onclick="return confirm('Assign yourself to this request?')">
                                Assign to Me
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

    <!-- MY ASSIGNED REQUESTS SECTION -->
    <section class="requests-section">
        <h2 class="section-title">My Assigned Requests</h2>
        
        <?php if (empty($myRequests)): ?>
            <div class="no-requests">
                <p>You don't have any assigned requests.</p>
            </div>
        <?php else: ?>
            <div class="requests-grid">
                <?php foreach ($myRequests as $request): ?>
                    <div class="request-card assigned">
                        <h3><?= htmlspecialchars($request['unit_name'] . ' - ' . $request['unit_number']) ?></h3>
                        <p><strong>Requester:</strong> <?= htmlspecialchars($request['fname'] . ' ' . $request['lname']) ?></p>
                        <p><strong>Department:</strong> <?= htmlspecialchars($request['department']) ?></p>
                        <p><strong>Room:</strong> <?= htmlspecialchars($request['room']) ?></p>
                        <p><strong>Details:</strong> <?= htmlspecialchars(substr($request['request_details'], 0, 100)) ?>...</p>
                        <p><strong>Date Needed:</strong> <?= $request['request_date'] ?></p>
                        <p><strong>Current Status:</strong> <span class="status-<?= strtolower(str_replace(' ', '-', $request['status'])) ?>"><?= $request['status'] ?></span></p>
                        
                        <div class="request-actions">
                            <form method="POST" class="status-form">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <input type="hidden" name="update_status" value="1">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="Assigned" <?= $request['status'] === 'Assigned' ? 'selected' : '' ?>>Assigned</option>
                                    <option value="In Progress" <?= $request['status'] === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                    <option value="Completed" <?= $request['status'] === 'Completed' ? 'selected' : '' ?>>Completed</option>
                                </select>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

</body>
</html>