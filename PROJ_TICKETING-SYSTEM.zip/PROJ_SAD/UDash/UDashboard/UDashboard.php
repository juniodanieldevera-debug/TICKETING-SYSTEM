<?php
session_start();

// Allow only Users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    header("Location: ../../auth/login.php");
    exit;
}

require '../../config/db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="UDashboard.css?v=<?= time() ?>">
</head>
<body>

<!-- MAIN PANEL -->
<div class="panel">
    <div class="panel-header">
        <img src="../../pic/moplogo.png" alt="logo">
        <h2>Maintenance Operation Platform</h2>
    </div>

    <div class="panel-body">
        <h1><strong>WELCOME</strong></h1>
        <h2>To Maintenance</h2>
        <h2>Operation Platform</h2>
        <h3>Helps you easily manage, track, and</h3>
        <h3>schedule all your maintenance tasks.</h3>
    </div>
</div>

<!-- RIGHT MENU BUTTONS -->
<div class="menu">

    <button onclick="location.href='/PROJ_SAD/UDash/UForm/UForm.php'">
        <img src='../../pic/requestw.png'>
        <strong>REQUEST FORM</strong>
    </button>

    <button onclick="location.href='/PROJ_SAD/UDash/UHistory/UHistory.php'">
        <img src='../../pic/history.png'>
        <strong>VIEW HISTORY</strong>
    </button>

    <button onclick="location.href='/PROJ_SAD/UDash/UNotification/UNotification.php'">
        <img src='../../pic/notif.png'>
        <strong>VIEW NOTIFICATION</strong>
    </button>

    <button onclick="location.href='/PROJ_SAD/UDash/UProfile/UProfile.php'">
     <img src='../../pic/userw.png'>   
    <strong>VIEW PROFILE</strong>
    </button>

</div>



</body>
</html>
