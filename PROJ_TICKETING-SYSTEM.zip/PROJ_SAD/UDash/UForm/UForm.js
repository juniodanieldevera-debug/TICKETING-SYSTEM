// Date settings: allow future dates only (no past dates)
document.addEventListener('DOMContentLoaded', function() {
    const dateNeeded = document.getElementById("date_needed");
    const today = new Date().toISOString().split("T")[0];
    
    // Set min to today - cannot pick past dates
    dateNeeded.setAttribute("min", today);
    
    // Set default value to today
    dateNeeded.value = today;

    // Initialize floor-to-room functionality
    initFloorToRoom();
});

// FLOOR → ROOM AUTO-FILL
function initFloorToRoom() {
    const floorSelect = document.getElementById("floorSelect");
    const roomSelect = document.getElementById("roomSelect");

    if (!floorSelect || !roomSelect) {
        console.error('Floor or Room select elements not found');
        return;
    }

    floorSelect.addEventListener("change", function() {
        const floor = parseInt(this.value);
        roomSelect.innerHTML = "";
        
        if (!floor) {
            roomSelect.innerHTML = "<option value=''>Select Floor First</option>";
            return;
        }
        
        // Create room options based on floor
        const startRoom = floor * 100 + 1; // 101, 201, 301, etc.
        const endRoom = floor * 100 + 20;  // 120, 220, 320, etc.
        
        for (let roomNum = startRoom; roomNum <= endRoom; roomNum++) {
            const option = document.createElement("option");
            option.value = roomNum;
            option.textContent = "Room " + roomNum;
            roomSelect.appendChild(option);
        }
    });

    // Form validation with SweetAlert2
    const form = document.querySelector('form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const floor = floorSelect.value;
            const room = roomSelect.value;
            const unitName = document.querySelector('[name="unit_name"]').value;
            const unitNumber = document.querySelector('[name="unit_number"]').value;
            const technicianType = document.querySelector('[name="technician_type"]').value;
            const requestTitle = document.querySelector('[name="request_title"]').value;
            const requestDetails = document.querySelector('[name="request"]').value;
            
            if (!floor || !room || !unitName || !unitNumber || !technicianType || !requestTitle || !requestDetails) {
                e.preventDefault(); // prevent form submission
                
                // SweetAlert2 popup
                Swal.fire({
                    icon: 'error',
                    title: 'Missing Fields',
                    text: 'Please fill all required fields before submitting the form.',
                    confirmButtonText: 'OK'
                });
                return;
            }
        });
    }
}
