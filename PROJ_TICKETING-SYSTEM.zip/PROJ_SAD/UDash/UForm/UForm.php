<?php
session_start();
require '../../config/db_connect.php';

// Block non-users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    header("Location: ../../auth/login.php");
    exit;
}

// Get the logged-in user's email from session
$email = $_SESSION['email'] ?? null;
if (!$email) die("User not properly logged in.");

// Get the logged-in user
$stmt = $conn->prepare("SELECT user_id, fname, mname, lname, department FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("Error: User account not found. Please contact administrator.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Request</title>
    <link rel="stylesheet" href="UForm.css">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

<nav class="nav">
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="logo">
        <span>MOP</span>
    </div>
    <div class="nav-links">
        <a href="../UDashboard/UDashboard.php">HOME</a>
        <a href="../UHistory/UHistory.php">HISTORY</a>
        <a href="../UNotification/UNotification.php">NOTIFICATION</a>
    </div>
    <a href="../UProfile/UProfile.php" class="profile-icon">👤</a>
</nav>

<div class="form-container">
    <h2>Maintenance Request Form</h2>

    <form id="maintenanceForm" enctype="multipart/form-data">
        <input type="hidden" name="user_id" value="<?= $user['user_id'] ?>">

        <div class="row">
            <input type="text" value="<?= htmlspecialchars($user['fname']) ?>" readonly placeholder="First Name">
            <input type="text" value="<?= htmlspecialchars($user['lname']) ?>" readonly placeholder="Last Name">
            <input type="text" value="<?= htmlspecialchars($user['mname'] ?? '') ?>" readonly placeholder="M.I" maxlength="1">
        </div>

        <div class="row">
            <input type="text" value="<?= (1000 + intval($user['user_id'])) ?>" readonly placeholder="ID Number">
            <input type="text" value="<?= htmlspecialchars($user['department']) ?>" readonly placeholder="Department">
        </div>

        <div class="row">
            <select id="floorSelect" name="floor" required>
                <option value="">Select Floor</option>
                <option value="1">1st Floor</option>
                <option value="2">2nd Floor</option>
                <option value="3">3rd Floor</option>
                <option value="4">4th Floor</option>
                <option value="5">5th Floor</option>
            </select>
            <select id="roomSelect" name="room" required>
                <option value="">Select Floor First</option>
            </select>
        </div>

        <div class="row">
            <select name="unit_name" required>
                <option value="">Select Unit Name</option>
                <option value="Computer">Computer</option>
                <option value="Air Conditioner">Air Conditioner</option>
                <option value="Printer">Printer</option>
                <option value="Projector">Projector</option>
                <option value="Lighting">Lighting</option>
                <option value="Network Equipment">Network Equipment</option>
                <option value="Furniture">Furniture</option>
                <option value="Electrical Outlet">Electrical Outlet</option>
                <option value="Plumbing">Plumbing</option>
                <option value="Other">Other</option>
            </select>
            <select name="unit_number" required>
                <?php for($i=1;$i<=10;$i++): ?>
                    <option value="Unit <?= $i ?>">Unit <?= $i ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <label class="label-title">Technician Needed</label>
        <select name="technician_type" required>
            <option value="">Select Technician Type</option>
            <option value="Computer Technician">Computer Technician</option>
            <option value="Electrician">Electrician</option>
            <option value="Carpenter">Carpenter</option>
            <option value="Aircon Technician">Aircon Technician</option>
            <option value="Plumber">Plumber</option>
            <option value="Network Technician">Network Technician</option>
            <option value="General Maintenance">General Maintenance</option>
        </select>

        <label class="label-title">Date Needed:</label>
        <input type="date" name="date_needed" required id="date_needed">

        <input type="text" name="request_title" placeholder="Request Title" required>
        <textarea name="request" placeholder="Describe your issue..." required></textarea>

        <label class="label-title">Attach Images (optional)</label>
        <input type="file" name="attachments[]" multiple accept="image/*">

        <button type="submit" class="submit-btn">SUBMIT</button>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const dateNeeded = document.getElementById("date_needed");
    const today = new Date().toISOString().split("T")[0];
    dateNeeded.setAttribute("min", today);
    dateNeeded.value = today;

    // Floor → Room auto-fill
    const floorSelect = document.getElementById("floorSelect");
    const roomSelect = document.getElementById("roomSelect");
    floorSelect.addEventListener("change", function() {
        const floor = parseInt(this.value);
        roomSelect.innerHTML = "";
        if (!floor) {
            roomSelect.innerHTML = "<option value=''>Select Floor First</option>";
            return;
        }
        for(let i=floor*100+1;i<=floor*100+20;i++){
            const opt = document.createElement("option");
            opt.value = i;
            opt.textContent = "Room " + i;
            roomSelect.appendChild(opt);
        }
    });

    // Form submission with Yes/No confirmation
    const form = document.getElementById("maintenanceForm");
    form.addEventListener("submit", function(e){
        e.preventDefault();

        const requiredFields = form.querySelectorAll("[required]");
        let empty = false;
        requiredFields.forEach(f => { if(!f.value) empty = true; });

        if(empty){
            Swal.fire({
                icon: 'error',
                title: 'Missing Fields',
                text: 'Please fill all required fields.',
                confirmButtonText: 'OK'
            });
            return;
        }

        // Confirm submission
        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to submit this request?",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, submit it!',
            cancelButtonText: 'No, cancel'
        }).then((result) => {
            if(result.isConfirmed){
                // Submit via AJAX
                const formData = new FormData(form);
                fetch('submit_request.php', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if(data.status === "success"){
                        Swal.fire({
                            icon: 'success',
                            title: 'Submitted!',
                            text: data.message || 'Request submitted successfully.',
                            confirmButtonText: 'OK'
                        });
                        form.reset();
                        roomSelect.innerHTML = "<option value=''>Select Floor First</option>";
                        dateNeeded.value = today;
                    } else {
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: data.message || 'Something went wrong.',
                            confirmButtonText: 'OK'
                        });
                    }
                })
                .catch(err => {
                    console.error(err);
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Unable to connect to server.',
                        confirmButtonText: 'OK'
                    });
                });
            }
        });
    });
});
</script>

</body>
</html>
