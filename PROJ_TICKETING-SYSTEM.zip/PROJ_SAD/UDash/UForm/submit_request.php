<?php
session_start();
require '../../config/db_connect.php';
header('Content-Type: application/json');

try {
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') throw new Exception("Not logged in.");
    $email = $_SESSION['email'] ?? '';
    if (!$email) throw new Exception("User not logged in.");

    $stmt = $conn->prepare("SELECT user_id, fname, mname, lname, department FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$user) throw new Exception("User not found.");

    $fields = ['floor','room','unit_name','unit_number','technician_type','request_title','request','date_needed'];
    foreach($fields as $f){
        if(empty($_POST[$f])) throw new Exception("Please fill all required fields.");
    }

    $sql = "INSERT INTO user_requests (user_id,fname,mname,lname,department,floor,room,unit_name,unit_number,technician_type,request_details,request_date,status)
            VALUES (:user_id,:fname,:mname,:lname,:department,:floor,:room,:unit_name,:unit_number,:technician_type,:request_details,:request_date,'Pending')";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':user_id'=>$user['user_id'],
        ':fname'=>$user['fname'],
        ':mname'=>$user['mname'] ?? '',
        ':lname'=>$user['lname'],
        ':department'=>$user['department'],
        ':floor'=>$_POST['floor'],
        ':room'=>$_POST['room'],
        ':unit_name'=>$_POST['unit_name'],
        ':unit_number'=>$_POST['unit_number'],
        ':technician_type'=>$_POST['technician_type'],
        ':request_details'=>$_POST['request_title'].' - '.$_POST['request'],
        ':request_date'=>$_POST['date_needed']
    ]);

    echo json_encode(['status'=>'success','message'=>'Request submitted successfully!']);

} catch(Exception $e){
    echo json_encode(['status'=>'error','message'=>$e->getMessage()]);
}