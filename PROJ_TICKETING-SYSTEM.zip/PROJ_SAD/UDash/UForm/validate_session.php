<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    header("Location: ../../auth/login.php");
    exit;
}
?>