<?php
session_start();
require '../../config/db_connect.php';

// Block non-users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    header("Location: ../../auth/login.php");
    exit;
}

// Get the logged-in user's email from session
$email = $_SESSION['email'] ?? null;
if (!$email) {
    die("User not properly logged in. Please login again.");
}

// Get user_id from database using email
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    die("User account not found. Please contact administrator.");
}
$user_id = $user['user_id'];

// Fetch requests for this user
try {
    $stmt = $conn->prepare("
        SELECT 
            ur.*, 
            CONCAT(t.fname, ' ', t.lname) AS tech_name,
            t.tech_id,
            tr.rating AS user_rating,
            tr.comment AS user_comment
        FROM user_requests ur
        LEFT JOIN technicians t ON ur.tech_id = t.tech_id
        LEFT JOIN technician_ratings tr ON ur.id = tr.request_id AND tr.user_id = ?
        WHERE ur.user_id = ?
        ORDER BY ur.created_at DESC
    ");
    $stmt->execute([$user_id, $user_id]);
    $all_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Request History</title>
    <link rel="stylesheet" href="UHistory.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- NAVIGATION BAR -->
    <nav>
        <div class="logo">
            <img src="../../pic/moplogo.png" alt="logo" />
            <span>MOP</span>
        </div>
        <div class="nav-links">
            <a href="../UDashboard/UDashboard.php">HOME</a>
            <a href="UHistory.php" class="active">HISTORY</a>
            <a href="../UNotification/UNotification.php">NOTIFICATION</a>
        </div>
        <a href="../UProfile/UProfile.php" class="profile-icon">👤</a>
    </nav>

    <div class="form-container">
        <div class="history-container">
            <h2>REQUEST HISTORY</h2>

            <!-- TOP CONTROLS -->
            <div class="top-controls">
                <label class="switch">
                    <input type="checkbox" id="statusToggle" checked />
                    <span class="slider"></span>
                    <span class="switch-label">ONGOING</span>
                </label>

                <div class="search-group">
                    <input type="text" id="searchInput" placeholder="Search request or technician..." />
                    <button type="button" onclick="filterTable()">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </div>

            <!-- TABLE CONTAINER -->
            <div class="table-container">
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Request Title</th>
                            <th>Unit Name</th>
                            <th>Room</th>
                            <th>Floor</th>
                            <th>Status</th>
                            <th>Technician</th>
                            <th>Date Requested</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="historyBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- RATING MODAL -->
    <div id="ratingModal" class="modal">
        <div class="modal-content">
            <span class="close-btn" onclick="closeRatingModal()">&times;</span>
            <h3>Rate Technician</h3>
            <p id="techName">Technician: </p>
            <div class="rating-stars">
                <i class="far fa-star" data-rating="1"></i>
                <i class="far fa-star" data-rating="2"></i>
                <i class="far fa-star" data-rating="3"></i>
                <i class="far fa-star" data-rating="4"></i>
                <i class="far fa-star" data-rating="5"></i>
            </div>
            <p class="rating-text" id="ratingText">Select your rating</p>
            <textarea id="ratingComment" placeholder="Optional: Add a comment about the service..." rows="4"></textarea>
            <div class="modal-buttons">
                <button type="button" onclick="submitRating()" class="submit-rating-btn">
                    <i class="fas fa-star"></i> Submit Rating
                </button>
                <button type="button" onclick="closeRatingModal()" class="cancel-btn">Cancel</button>
            </div>
            <input type="hidden" id="currentRequestId">
            <input type="hidden" id="currentTechId">
        </div>
    </div>

    <script>
    const toggle = document.getElementById('statusToggle');
    const tbody = document.getElementById('historyBody');
    const searchInput = document.getElementById('searchInput');
    let allRequests = <?= json_encode($all_requests) ?>;
    let currentRating = 0;

    function filterRequests() {
        const showOngoing = toggle.checked;
        const searchTerm = searchInput.value.toLowerCase();

        let filteredRequests = allRequests.filter(request => {
            const status = (request.status || '').trim().toLowerCase();

            const matchesStatus = showOngoing ? 
                status !== 'completed' && status !== 'cancelled' && status !== 'archived' : 
                status === 'completed';

            const matchesSearch = !searchTerm ||
                (request.unit_name && request.unit_name.toLowerCase().includes(searchTerm)) ||
                (request.tech_name && request.tech_name.toLowerCase().includes(searchTerm)) ||
                (request.room && request.room.toString().includes(searchTerm)) ||
                (request.request_details && request.request_details.toLowerCase().includes(searchTerm));

            return matchesStatus && matchesSearch;
        });

        displayRequests(filteredRequests);
        updateToggleLabel(showOngoing);
    }

    function displayRequests(requests) {
        if (requests.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" class="no-data">No requests found</td></tr>';
            return;
        }

        tbody.innerHTML = requests.map(request => {
            let requestTitle = 'Maintenance Request';
            if (request.request_details) {
                const parts = request.request_details.split(' - ');
                requestTitle = parts[0] || 'Maintenance Request';
                if (requestTitle.length > 25) requestTitle = requestTitle.substring(0,25) + '...';
            }

            const status = (request.status || '').trim().toLowerCase();
            const alreadyRated = request.user_rating ? true : false;

            return `
                <tr>
                    <td>${escapeHtml(requestTitle)}</td>
                    <td>${escapeHtml(request.unit_name || 'N/A')}</td>
                    <td>${escapeHtml(request.room || 'N/A')}</td>
                    <td>${escapeHtml(request.floor || 'N/A')}</td>
                    <td class="status-${status.replace(' ', '-')}">
                        ${escapeHtml(request.status)}
                        ${alreadyRated ? `<br><small>Rated: ${request.user_rating} ⭐</small>` : ''}
                    </td>
                    <td>${escapeHtml(request.tech_name || 'Unassigned')}</td>
                    <td>${formatDate(request.created_at)}</td>
                    <td>
                        <div class="action-buttons">
                        ${status === 'completed' && request.tech_id ? 
                            alreadyRated ?
                                `<span class="rated-badge">Rated</span>
                                 <button class="view-btn" onclick="viewRequest(${request.id})">
                                    <i class="fas fa-eye"></i> View
                                 </button>` :
                                `<button class="rate-btn" onclick="openRatingModal(${request.id}, ${request.tech_id}, '${escapeHtml(request.tech_name || 'Unknown Technician')}')">
                                    <i class="fas fa-star"></i> Rate
                                 </button>
                                 <button class="view-btn" onclick="viewRequest(${request.id})">
                                    <i class="fas fa-eye"></i> View
                                 </button>` :
                        status === 'pending' ?
                            `<button class="edit-btn" onclick="editRequest(${request.id})">
                                <i class="fas fa-edit"></i> Edit
                             </button>
                             <button class="cancel-btn" onclick="cancelRequest(${request.id})">
                                <i class="fas fa-times"></i> Cancel
                             </button>` :
                            `<button class="view-btn" onclick="viewRequest(${request.id})">
                                <i class="fas fa-eye"></i> View
                             </button>
                             ${status !== 'cancelled' && status !== 'archived' ? 
                             `<button class="cancel-btn" onclick="cancelRequest(${request.id})">
                                <i class="fas fa-times"></i> Cancel
                             </button>` : ''}`
                        }
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    function updateToggleLabel(showOngoing) {
        const label = document.querySelector('.switch-label');
        label.innerHTML = showOngoing ? 
            '<span style="color: #f59e0b; font-weight: bold;">ONGOING</span>' :
            '<span style="color: #10b981; font-weight: bold;">COMPLETED</span>';
    }

    function filterTable() {
        filterRequests();
    }

    // Rating Modal Functions
    function openRatingModal(requestId, techId, techName) {
        if (!techId || techId === 0) { 
            alert('No technician assigned to this request.'); 
            return; 
        }
        document.getElementById('currentRequestId').value = requestId;
        document.getElementById('currentTechId').value = techId;
        document.getElementById('techName').textContent = 'Technician: ' + techName;
        currentRating = 0; 
        updateStars(0);
        document.getElementById('ratingComment').value = '';
        document.getElementById('ratingText').textContent = 'Select your rating';
        document.getElementById('ratingModal').style.display = 'flex';
    }

    function closeRatingModal() { 
        document.getElementById('ratingModal').style.display = 'none'; 
        currentRating = 0; 
    }

    function updateStars(rating) {
        const stars = document.querySelectorAll('.rating-stars i');
        const ratingText = document.getElementById('ratingText');
        const descriptions = {
            0: 'Select your rating',
            1: 'Poor - Very dissatisfied',
            2: 'Fair - Needs improvement', 
            3: 'Good - Satisfactory',
            4: 'Very Good - Exceeded expectations',
            5: 'Excellent - Outstanding service'
        };
        
        stars.forEach((star, index) => {
            star.className = index < rating ? 'fas fa-star' : 'far fa-star';
        });
        
        ratingText.textContent = descriptions[rating];
        ratingText.style.color = rating >= 4 ? '#10b981' : rating >= 3 ? '#f59e0b' : '#ef4444';
        ratingText.style.fontWeight = rating > 0 ? 'bold' : 'normal';
    }

    function submitRating() {
        const requestId = document.getElementById('currentRequestId').value;
        const techId = document.getElementById('currentTechId').value;
        const comment = document.getElementById('ratingComment').value.trim();
        
        if (currentRating === 0) {
            alert('Please select a rating before submitting.');
            return;
        }
        
        fetch('submit_rating.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `request_id=${requestId}&tech_id=${techId}&rating=${currentRating}&comment=${encodeURIComponent(comment)}`
        })
        .then(response => response.text())
        .then(result => { 
            alert(result); 
            if (result.includes('Thank you') || result.includes('Success')) { 
                closeRatingModal(); 
                location.reload(); 
            }
        })
        .catch(error => alert('Error: ' + error));
    }

    // Event Listeners
    document.addEventListener('DOMContentLoaded', function(){
        document.getElementById('ratingModal').style.display = 'none';
        
        // Star rating events
        const stars = document.querySelectorAll('.rating-stars i');
        stars.forEach(star => {
            star.addEventListener('mouseover', () => updateStars(parseInt(star.getAttribute('data-rating'))));
            star.addEventListener('mouseout', () => updateStars(currentRating));
            star.addEventListener('click', () => { 
                currentRating = parseInt(star.getAttribute('data-rating')); 
                updateStars(currentRating); 
            });
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', e => { 
            if (e.target === document.getElementById('ratingModal')) closeRatingModal(); 
        });
        
        // Main functionality
        toggle.addEventListener('change', filterRequests);
        searchInput.addEventListener('input', filterRequests);
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') filterTable();
        });
        
        // Initial load
        toggle.checked = true;
        filterRequests();
    });

    function viewRequest(id){ 
        alert('Viewing request #' + id); 
        // You can implement actual view functionality here
    }
    
    function editRequest(id){ 
        if(confirm('Are you sure you want to edit this request?')){ 
            alert('Editing request #' + id); 
            // Implement edit functionality
        } 
    }
    
    function cancelRequest(id){
        if(confirm('Are you sure you want to cancel this request?')) {
            fetch('cancel_request.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: `request_id=${id}`
            })
            .then(response => response.text())
            .then(result => {
                alert(result); 
                if(result.includes('successfully')) location.reload();
            })
            .catch(error => alert('Error: ' + error));
        }
    }

    // Utility functions
    function escapeHtml(unsafe){ 
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
    
    function formatDate(dateString){ 
        const date = new Date(dateString); 
        return date.toLocaleDateString('en-US', {month: 'short', day: 'numeric', year: 'numeric'}); 
    }
    </script>
</body>
</html>