<?php
session_start();
require '../../config/db_connect.php';

// Block non-users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    echo "Error: You must be logged in to cancel requests.";
    exit;
}

// Get user_id from database using email
$email = $_SESSION['email'] ?? null;
if (!$email) {
    echo "Error: You must be logged in to cancel requests.";
    exit;
}

// Get user_id from database
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Error: User account not found.";
    exit;
}

$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = $_POST['request_id'] ?? null;
    
    if (!$request_id) {
        echo "Error: No request ID provided.";
        exit;
    }

    try {
        // Check if request belongs to user and can be cancelled
        $stmt = $conn->prepare("SELECT status FROM user_requests WHERE id = ? AND user_id = ?");
        $stmt->execute([$request_id, $user_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            echo "Error: Request not found or you don't have permission to cancel it.";
            exit;
        }

        if ($request['status'] === 'Completed' || $request['status'] === 'Cancelled' || $request['status'] === 'Archived') {
            echo "Error: Cannot cancel a completed, archived, or already cancelled request.";
            exit;
        }

        // Update request status to Cancelled
        $stmt = $conn->prepare("UPDATE user_requests SET status = 'Cancelled' WHERE id = ?");
        $stmt->execute([$request_id]);

        echo "Request cancelled successfully!";
        
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
} else {
    echo "Error: Invalid request method.";
}
?>