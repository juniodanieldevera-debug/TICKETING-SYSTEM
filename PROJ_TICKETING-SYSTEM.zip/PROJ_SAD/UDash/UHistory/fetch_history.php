<?php
require '../../config/db_connect.php';
session_start();

$user_id = $_SESSION['user_id'] ?? null;
if (!$user_id) exit;

$status = $_GET['status'] ?? 'ongoing';

try {
  if ($status === 'completed') {
    $stmt = $conn->prepare("
      SELECT ur.*, CONCAT(t.fname, ' ', t.lname) AS tech_name
      FROM user_requests ur
      LEFT JOIN technicians t ON ur.tech_id = t.tech_id
      WHERE ur.user_id = :user_id AND ur.status = 'Completed'
      ORDER BY ur.created_at DESC
    ");
  } else {
    $stmt = $conn->prepare("
      SELECT ur.*, CONCAT(t.fname, ' ', t.lname) AS tech_name
      FROM user_requests ur
      LEFT JOIN technicians t ON ur.tech_id = t.tech_id
      WHERE ur.user_id = :user_id AND ur.status IN ('Assigned', 'In Progress')
      ORDER BY ur.created_at DESC
    ");
  }

  $stmt->execute([':user_id' => $user_id]);
  $requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

  foreach ($requests as $r) {
    echo "<tr>
      <td>".htmlspecialchars($r['unit_name'])."</td>
      <td>".htmlspecialchars($r['room'])."</td>
      <td>".htmlspecialchars($r['floor'])."</td>
      <td class='".strtolower(str_replace(' ', '-', $r['status']))."'>".htmlspecialchars($r['status'])."</td>
      <td>".htmlspecialchars($r['tech_name'] ?? 'Unassigned')."</td>
      <td>";
    if ($r['status'] === 'Completed') {
      echo "<button class='view-btn'>View</button>";
    } else {
      echo "<button class='edit-btn'>Edit</button><button class='cancel-btn'>Cancel</button>";
    }
    echo "</td></tr>";
  }
} catch (PDOException $e) {
  echo "<tr><td colspan='6'>Database Error: {$e->getMessage()}</td></tr>";
}
?>
