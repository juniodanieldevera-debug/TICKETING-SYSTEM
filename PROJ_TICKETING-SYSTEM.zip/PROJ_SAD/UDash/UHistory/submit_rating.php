<?php
session_start();
require '../../config/db_connect.php';

// Include SweetAlert2 via CDN
echo '<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>';

// Function to show alert and redirect
function swal_alert($title, $text, $icon = 'error', $redirect = null) {
    $redirect_js = $redirect ? "window.location.href='$redirect';" : "";
    echo "<script>
        Swal.fire({
            icon: '$icon',
            title: '$title',
            text: '$text',
        }).then(() => { $redirect_js });
    </script>";
    exit;
}

// Block non-users
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    swal_alert("Error", "You must be logged in to submit ratings.");
}

// Get user_id from database using email
$email = $_SESSION['email'] ?? null;
if (!$email) {
    swal_alert("Error", "You must be logged in to submit ratings.");
}

// Get user_id from database
$stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    swal_alert("Error", "User account not found.");
}

$user_id = $user['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $request_id = $_POST['request_id'] ?? null;
    $tech_id = $_POST['tech_id'] ?? null;
    $rating = $_POST['rating'] ?? null;
    $comment = $_POST['comment'] ?? '';

    if (!$request_id || !$tech_id || !$rating) {
        swal_alert("Error", "Missing required rating information.");
    }

    if ($rating < 1 || $rating > 5) {
        swal_alert("Error", "Rating must be between 1 and 5 stars.");
    }

    try {
        // Verify the request belongs to user and is completed
        $stmt = $conn->prepare("SELECT status FROM user_requests WHERE id = ? AND user_id = ?");
        $stmt->execute([$request_id, $user_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$request) {
            swal_alert("Error", "Request not found or you don't have permission to rate this request.");
        }

        if ($request['status'] !== 'Completed') {
            swal_alert("Error", "You can only rate completed requests.");
        }

        // Check if already rated
        $stmt = $conn->prepare("SELECT id FROM technician_ratings WHERE request_id = ? AND user_id = ?");
        $stmt->execute([$request_id, $user_id]);
        if ($stmt->fetch()) {
            swal_alert("Error", "You have already rated this request.");
        }

        // Insert rating
        $stmt = $conn->prepare("INSERT INTO technician_ratings (request_id, tech_id, user_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$request_id, $tech_id, $user_id, $rating, $comment]);

        // Update technician's average rating
        $stmt = $conn->prepare("
            UPDATE technicians 
            SET rating = (
                SELECT ROUND(AVG(rating), 1) 
                FROM technician_ratings 
                WHERE tech_id = ?
            ) 
            WHERE tech_id = ?
        ");
        $stmt->execute([$tech_id, $tech_id]);

        swal_alert("Success", "Thank you! Your rating has been submitted successfully.", "success", "/path/to/rating_page.php");

    } catch (PDOException $e) {
        swal_alert("Database Error", $e->getMessage());
    }
} else {
    swal_alert("Error", "Invalid request method.");
}
?>
