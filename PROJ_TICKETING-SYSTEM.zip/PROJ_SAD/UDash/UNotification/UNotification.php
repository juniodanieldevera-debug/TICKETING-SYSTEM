<?php
session_start();

// Session validation
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'User') {
    $_SESSION['error_message'] = "Please log in to access this page";
    header("Location: ../../auth/login.php");
    exit;
}

// Include files with error handling
try {
    require '../../config/db_connect.php';
    require '../../config/notification_functions.php';
} catch (Exception $e) {
    error_log("Include Error: " . $e->getMessage());
    die("System error. Please contact administrator.");
}

// Get user with validation
$email = $_SESSION['email'] ?? null;
if (!$email) {
    $_SESSION['error_message'] = "Session expired. Please login again.";
    header("Location: ../../auth/login.php");
    exit;
}

try {
    $stmt = $conn->prepare("SELECT user_id, account_id FROM users WHERE email = :email");
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        throw new Exception("User account not found");
    }
    
    $user_id = $user['user_id'];
    $account_id = $user['account_id'];
    
} catch (Exception $e) {
    error_log("User Fetch Error: " . $e->getMessage());
    $_SESSION['error_message'] = "Unable to load user data. Please contact support.";
    header("Location: ../../auth/login.php");
    exit;
}

// Handle POST actions with validation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['mark_as_read'])) {
            $notification_id = filter_input(INPUT_POST, 'notification_id', FILTER_VALIDATE_INT);
            
            if (!$notification_id) {
                throw new Exception("Invalid notification ID");
            }
            
            if (markNotificationAsRead($notification_id)) {
                $_SESSION['success_message'] = "Notification marked as read";
            } else {
                $_SESSION['error_message'] = "Failed to mark notification as read";
            }
        }
        
        if (isset($_POST['mark_all_read'])) {
            if (markAllNotificationsAsRead($account_id)) {
                $_SESSION['success_message'] = "All notifications marked as read";
            } else {
                $_SESSION['error_message'] = "Failed to mark all notifications as read";
            }
        }
        
    } catch (Exception $e) {
        error_log("POST Action Error: " . $e->getMessage());
        $_SESSION['error_message'] = "An error occurred. Please try again.";
    }
    
    header("Location: UNotification.php");
    exit;
}

// Get notifications with error handling
try {
    $filter = filter_input(INPUT_GET, 'filter', FILTER_SANITIZE_STRING) ?? 'all';
    if (!in_array($filter, ['all', 'unread'])) {
        $filter = 'all';
    }
    
    $notifications = getUserNotifications($account_id, $filter);
    $unread_count = getUserUnreadCount($account_id);
    
} catch (Exception $e) {
    error_log("Notification Fetch Error: " . $e->getMessage());
    $notifications = [];
    $unread_count = 0;
    $_SESSION['error_message'] = "Unable to load notifications";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>USER NOTIFICATION</title>
  <link rel="stylesheet" href="UNotification.css?v=<?= time() ?>">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .error-banner {
      background: #f8d7da;
      color: #721c24;
      padding: 12px 20px;
      border-radius: 4px;
      margin: 20px auto;
      max-width: 900px;
      border: 1px solid #f5c6cb;
      text-align: center;
    }
    
    .success-banner {
      background: #d4edda;
      color: #155724;
      padding: 12px 20px;
      border-radius: 4px;
      margin: 20px auto;
      max-width: 900px;
      border: 1px solid #c3e6cb;
      text-align: center;
    }
  </style>
</head>
<body>
  <nav>
    <div class="logo">
      <img src="../../pic/moplogo.png" alt="logo" />
      <span>MOP</span>
    </div>
    <div class="nav-links">
      <a href="../UDashboard/UDashboard.php">HOME</a>
      <a href="../UHistory/UHistory.php">HISTORY</a>
      <a href="UNotification.php" class="active">NOTIFICATION <?= $unread_count > 0 ? "<span class='nav-badge'>$unread_count</span>" : '' ?></a>
    </div>
    <a href="../UProfile/UProfile.php" class="profile-icon">👤</a>
  </nav>

  <?php if (isset($_SESSION['error_message'])): ?>
    <div class="error-banner">
      <?= htmlspecialchars($_SESSION['error_message']) ?>
    </div>
    <?php unset($_SESSION['error_message']); ?>
  <?php endif; ?>

  <?php if (isset($_SESSION['success_message'])): ?>
    <div class="success-banner">
      <?= htmlspecialchars($_SESSION['success_message']) ?>
    </div>
    <?php unset($_SESSION['success_message']); ?>
  <?php endif; ?>

  <div class="notification-container">
    <div class="notification-header">
      <button class="back-btn" onclick="window.history.back()">←</button>
      <div class="filter-buttons">
        <button class="filter <?= $filter === 'all' ? 'active' : '' ?>" onclick="setFilter('all')">
          ALL <?= $unread_count > 0 ? "<span class='badge'>$unread_count</span>" : '' ?>
        </button>
        <button class="filter <?= $filter === 'unread' ? 'active' : '' ?>" onclick="setFilter('unread')">UNREAD</button>
      </div>
      <?php if ($unread_count > 0): ?>
        <form method="POST" style="display: inline;">
          <button type="submit" name="mark_all_read" class="mark-all-btn">
            <i class="fas fa-check-double"></i> Mark All as Read
          </button>
        </form>
      <?php endif; ?>
    </div>

    <div class="notification-list">
      <?php if (empty($notifications)): ?>
        <div class="no-notifications">
          <i class="fas fa-bell-slash"></i>
          <p>No notifications found</p>
        </div>
      <?php else: ?>
        <?php foreach ($notifications as $notification): ?>
          <div class="notification-item <?= $notification['is_read'] ? 'read' : 'unread' ?>">
            <div class="notification-icon">
              <?php
              $icon = 'fas fa-bell';
              $color = '#003399';
              switch ($notification['type']) {
                  case 'assignment':
                      $icon = 'fas fa-user-check';
                      $color = '#28a745';
                      break;
                  case 'status_update':
                      $icon = 'fas fa-sync-alt';
                      $color = '#17a2b8';
                      break;
                  case 'message':
                      $icon = 'fas fa-comment';
                      $color = '#6f42c1';
                      break;
                  case 'system':
                  default:
                      $icon = 'fas fa-bell';
                      $color = '#003399';
              }
              ?>
              <i class="<?= $icon ?>" style="color: <?= $color ?>"></i>
            </div>
            <div class="notification-text">
              <p><strong><?= htmlspecialchars($notification['title']) ?></strong></p>
              <p><?= htmlspecialchars($notification['message']) ?></p>
              <span class="time"><?= timeAgo($notification['created_at']) ?></span>
            </div>
            <div class="notification-actions">
              <?php if (!$notification['is_read']): ?>
                <form method="POST" style="display: inline;">
                  <input type="hidden" name="notification_id" value="<?= $notification['id'] ?>">
                  <button type="submit" name="mark_as_read" class="mark-read-btn" title="Mark as Read">
                    <i class="fas fa-check"></i>
                  </button>
                </form>
              <?php endif; ?>
              <?php if ($notification['related_request_id']): ?>
                <button class="view-btn" onclick="viewRequest(<?= $notification['related_request_id'] ?>)">VIEW</button>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <script>
  function setFilter(filter) {
    if (!filter || !['all', 'unread'].includes(filter)) {
      console.error('Invalid filter:', filter);
      return;
    }
    
    try {
      window.location.href = `UNotification.php?filter=${filter}`;
    } catch (error) {
      console.error('Filter error:', error);
      alert('Unable to change filter. Please refresh the page.');
    }
  }

  function viewRequest(requestId) {
    if (!requestId || isNaN(requestId)) {
      alert('Invalid request ID');
      return;
    }
    
    try {
      window.location.href = `../UHistory/UHistory.php?view=${requestId}`;
    } catch (error) {
      console.error('Navigation error:', error);
      alert('Unable to view request. Please try again.');
    }
  }

  // Auto-refresh every 30 seconds
  setTimeout(function() {
    window.location.reload();
  }, 30000);

  // Global error handler
  window.addEventListener('error', function(event) {
    console.error('JavaScript Error:', event.error);
  });
  </script>
</body>
</html>