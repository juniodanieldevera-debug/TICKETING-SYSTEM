<?php
session_start();
require '../../config/db_connect.php';

// CHECK LOGIN
if (!isset($_SESSION['account_id'])) {
    header("Location: ../../auth/login.php");
    exit;
}

$account_id = $_SESSION['account_id'];

// Always define unread_count to avoid warnings
$unread_count = 0;

// GET USER INFO
$stmt = $conn->prepare("SELECT * FROM users WHERE account_id = ?");
$stmt->execute([$account_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    die("User not found.");
}

// ================================
// GET UNREAD NOTIFICATION COUNT
// ================================
try {
    $stmtUnread = $conn->prepare("
        SELECT COUNT(*) 
        FROM notifications 
        WHERE account_id = ? AND is_read = 0
    ");
    $stmtUnread->execute([$account_id]);
    $unread_count = (int)$stmtUnread->fetchColumn();
} catch (Exception $e) {
    $unread_count = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PROFILE</title>
<link rel="stylesheet" href="UProfile.css?v=<?= time() ?>">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
/* EXTRA STYLE FOR LOGOUT BUTTON INSIDE CONTAINER */
.logout-btn {
    margin-top: 20px;
    width: 140px;
    padding: 10px;
    border: none;
    background: #d9534f;
    color: white;
    cursor: pointer;
    border-radius: 6px;
    font-size: 16px;
    font-weight: bold;
}
.logout-btn:hover {
    background: #c9302c;
}

/* ID Display Styling */
.id-display {
    background: #e7f3ff;
    padding: 15px;
    border-radius: 8px;
    margin-bottom: 20px;
    border-left: 4px solid #004aad;
}

.id-display h3 {
    margin: 0 0 10px 0;
    color: #004aad;
    font-size: 16px;
}

.id-info {
    display: flex;
    gap: 30px;
    flex-wrap: wrap;
}

.id-item {
    display: flex;
    flex-direction: column;
}

.id-label {
    font-size: 12px;
    color: #666;
    font-weight: 500;
    margin-bottom: 4px;
}

.id-value {
    font-size: 16px;
    color: #004aad;
    font-weight: bold;
}
</style>

</head>
<body>

<nav>
    <div class="logo">
        <img src="../../pic/moplogo.png" alt="logo" />
        <span>MOP</span>
    </div>

    <div class="nav-links">
        <a href="../UDashboard/UDashboard.php">HOME</a>

        <a href="../UHistory/UHistory.php">HISTORY</a>

        <a href="../UNotification/UNotification.php">
            NOTIFICATION
            <?php if ($unread_count > 0): ?>
                <span class="nav-badge"><?= $unread_count ?></span>
            <?php endif; ?>
        </a>
    </div>

    <a href="../UProfile/UProfile.php" class="profile-icon" class="active">👤</a>
</nav>

<!-- PROFILE SECTION -->
<section class="profile-section">
    <div class="profile-container">

        <div class="profile-header">
            <h2>My Profile</h2>
            <button id="editBtn" class="edit-btn">Edit</button>
        </div>

        <!-- ID DISPLAY SECTION -->
        <div class="id-display">
            <h3>Account Information</h3>
            <div class="id-info">
                <div class="id-item">
                    <span class="id-label">User ID</span>
                    <span class="id-value">#<?= str_pad($user['user_id'], 5, '0', STR_PAD_LEFT) ?></span>
                </div>
                <div class="id-item">
                    <span class="id-label">ID Number</span>
                    <span class="id-value"><?= htmlspecialchars($user['id_number'] ?? 'Not Set') ?></span>
                </div>
                <div class="id-item">
                    <span class="id-label">Email</span>
                    <span class="id-value"><?= htmlspecialchars($user['email']) ?></span>
                </div>
            </div>
        </div>

        <form id="profileForm" method="POST" action="update_profile.php">
            <input type="hidden" name="account_id" value="<?= $user['account_id'] ?>">

            <div class="form-row">
                <input type="text" name="fname" placeholder="First Name" value="<?= $user['fname'] ?>" disabled>
                <input type="text" name="mname" placeholder="Middle Name" value="<?= $user['mname'] ?>" disabled>
                <input type="text" name="lname" placeholder="Last Name" value="<?= $user['lname'] ?>" disabled>
            </div>

            <div class="form-row">
                <input type="text" name="contact" placeholder="Contact No" value="<?= $user['contact'] ?>" disabled>
                <input type="text" name="gender" placeholder="Gender" value="<?= $user['gender'] ?>" disabled>
                <input type="text" placeholder="Date Registered" value="<?= $user['date_registered'] ?>" disabled>
            </div>

            <div class="form-row">
                <input type="text" name="department" placeholder="Department" value="<?= $user['department'] ?>" disabled>
            </div>

            <div class="form-buttons">
                <button type="button" class="cancel" disabled>Cancel</button>
                <button type="submit" class="save" disabled>Save</button>
            </div>

            <h3>Password</h3>
            <div class="form-row">
                <input type="password" name="current_password" placeholder="Current Password" disabled>
                <input type="password" name="new_password" placeholder="New Password" disabled>
                <input type="password" name="confirm_password" placeholder="Confirm Password" disabled>
            </div>

            <div class="form-buttons">
                <button type="button" class="cancel" disabled>Cancel</button>
                <button type="submit" class="save" disabled>Save</button>
            </div>
        </form>

        <!-- 🔻 LOGOUT BUTTON (BOTTOM LEFT) -->
        <button class="logout-btn" id="logoutBtn">Logout</button>

    </div>
</section>

<script>
// Enable edit mode
const editBtn = document.getElementById('editBtn');
const form = document.getElementById('profileForm');
const inputs = form.querySelectorAll('input');
const cancelBtns = form.querySelectorAll('.cancel');
const saveBtns = form.querySelectorAll('.save');

editBtn.addEventListener('click', () => {
    inputs.forEach(i => i.disabled = false);
    cancelBtns.forEach(c => c.disabled = false);
    saveBtns.forEach(s => s.disabled = false);

    editBtn.textContent = "Editing...";
    editBtn.classList.add("editing");
});

// Cancel edit → reload page
cancelBtns.forEach(btn => {
    btn.addEventListener('click', () => {
        window.location.reload();
    });
});

// SweetAlert messages
<?php if (isset($_SESSION['success'])): ?>
Swal.fire({
    icon: 'success',
    title: 'Success',
    text: '<?= $_SESSION['success']; ?>',
    timer: 2500,
    showConfirmButton: false
});
<?php unset($_SESSION['success']); endif; ?>

<?php if (isset($_SESSION['error'])): ?>
Swal.fire({
    icon: 'error',
    title: 'Error',
    text: '<?= $_SESSION['error']; ?>',
    timer: 3000,
    showConfirmButton: true
});
<?php unset($_SESSION['error']); endif; ?>


// ===========================
// LOGOUT BUTTON FUNCTION
// ===========================
document.getElementById('logoutBtn').addEventListener('click', () => {

    Swal.fire({
        title: "Logout?",
        text: "Are you sure you want to log out?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#d9534f",
        cancelButtonColor: "#3085d6",
        confirmButtonText: "Logout"
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "../../auth/logout.php";
        }
    });

});
</script>

</body>
</html>