<?php
session_start();
require '../../config/db_connect.php';

if (!isset($_POST['account_id'])) {
    header("Location: UProfile.php");
    exit;
}

$account_id = $_POST['account_id'];

// FETCH CURRENT USER
$stmt = $conn->prepare("SELECT * FROM users WHERE account_id = ?");
$stmt->execute([$account_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    $_SESSION['error'] = "User not found.";
    header("Location: UProfile.php");
    exit;
}

// ===== TRIM PROFILE FIELDS =====
$fname      = trim($_POST['fname']);
$mname      = trim($_POST['mname']);
$lname      = trim($_POST['lname']);
$contact    = trim($_POST['contact']);
$gender     = trim($_POST['gender']);
$department = trim($_POST['department']);

// ===== UPDATE PROFILE FIELDS =====
$update = $conn->prepare("
    UPDATE users SET
        fname = ?, 
        mname = ?, 
        lname = ?, 
        contact = ?, 
        gender = ?, 
        department = ?
    WHERE account_id = ?
");

$update->execute([
    $fname, $mname, $lname,
    $contact, $gender, $department,
    $account_id
]);

// ===== PASSWORD UPDATE =====
$current_pw = trim($_POST['current_password']);
$new_pw     = trim($_POST['new_password']);
$confirm_pw = trim($_POST['confirm_password']);

// Only if any password field is filled
if (!empty($current_pw) || !empty($new_pw) || !empty($confirm_pw)) {

    // Check if all password fields are filled
    if (empty($current_pw) || empty($new_pw) || empty($confirm_pw)) {
        $_SESSION['error'] = "Please fill all password fields.";
        header("Location: UProfile.php");
        exit;
    }

    // Get password from accounts table (where passwords are actually stored)
    $stmt = $conn->prepare("SELECT password FROM accounts WHERE account_id = ?");
    $stmt->execute([$account_id]);
    $account = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$account) {
        $_SESSION['error'] = "Account not found.";
        header("Location: UProfile.php");
        exit;
    }

    // Verify current password with hash from accounts table
    if (!password_verify($current_pw, $account['password'])) {
        $_SESSION['error'] = "Incorrect current password.";
        header("Location: UProfile.php");
        exit;
    }

    // Check new password confirmation
    if ($new_pw !== $confirm_pw) {
        $_SESSION['error'] = "New password and confirm password do not match.";
        header("Location: UProfile.php");
        exit;
    }

    // Hash and update new password in accounts table
    $hash = password_hash($new_pw, PASSWORD_DEFAULT);
    $updatePw = $conn->prepare("UPDATE accounts SET password = ? WHERE account_id = ?");
    $updatePw->execute([$hash, $account_id]);

    $_SESSION['success'] = "Profile and password updated successfully!";
} else {
    $_SESSION['success'] = "Profile updated successfully!";
}

// REDIRECT BACK TO PROFILE
header("Location: UProfile.php");
exit;