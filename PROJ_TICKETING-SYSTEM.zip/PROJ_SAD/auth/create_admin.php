<?php
require_once '../config/db_connect.php';

$email = 'admin@mop.com';
$password_plain = 'admin123';
$role = 'Admin';

$hashed_password = password_hash($password_plain, PASSWORD_DEFAULT);

try {
  $stmt = $conn->prepare("INSERT INTO accounts (email, password, role) VALUES (?, ?, ?)");
  $stmt->execute([$email, $hashed_password, $role]);
  echo "✅ Admin created successfully!<br>";
  echo "Email: $email<br>Password: $password_plain<br>Role: $role";
} catch (PDOException $e) {
  echo "❌ Error: " . $e->getMessage();
}
?>
