<?php
require_once '../config/db_connect.php';
session_start();

$error = '';
$success = '';
$step = 1; // Step 1: Email, Step 2: Security Questions, Step 3: Reset Password

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // STEP 1: Verify Email and Role
    if (isset($_POST['verify_email'])) {
        try {
            $email = trim($_POST['email']);
            $role = trim($_POST['role']);
            
            // Check if account exists
            $stmt = $conn->prepare("SELECT account_id, role FROM accounts WHERE email = ? AND role = ?");
            $stmt->execute([$email, $role]);
            $account = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$account) {
                $error = "No account found with this email and role.";
            } else {
                // Store in session and move to security questions
                $_SESSION['reset_account_id'] = $account['account_id'];
                $_SESSION['reset_email'] = $email;
                $_SESSION['reset_role'] = $role;
                $step = 2;
                $success = "Email verified! Please answer the security questions.";
            }
            
        } catch (PDOException $e) {
            error_log("Forgot Password Error: " . $e->getMessage());
            $error = "An error occurred. Please try again later.";
        }
    }
    
    // STEP 2: Verify Security Questions
    if (isset($_POST['verify_identity'])) {
        try {
            $role = $_SESSION['reset_role'];
            $user_data = null;
            
            if ($role === 'User') {
                $fname = trim($_POST['fname']);
                $mname = trim($_POST['mname']);
                $lname = trim($_POST['lname']);
                $id_number = trim($_POST['id_number']);
                $department = trim($_POST['department']);
                
                // First, check if the user exists with the given account_id
                $check_user_stmt = $conn->prepare("
                    SELECT id_number 
                    FROM users 
                    WHERE account_id = ?
                ");
                $check_user_stmt->execute([$_SESSION['reset_account_id']]);
                $user_record = $check_user_stmt->fetch(PDO::FETCH_ASSOC);
                
                if (empty($user_record['id_number'])) {
                    // If user has no ID number in database, verify without it
                    $stmt = $conn->prepare("
                        SELECT u.user_id, u.account_id 
                        FROM users u 
                        WHERE u.account_id = ? 
                        AND u.fname = ? 
                        AND u.mname = ?
                        AND u.lname = ? 
                        AND u.department = ?
                    ");
                    $stmt->execute([
                        $_SESSION['reset_account_id'], 
                        $fname, 
                        $mname,
                        $lname, 
                        $department
                    ]);
                } else {
                    // Use the normal verification with ID number
                    $stmt = $conn->prepare("
                        SELECT u.user_id, u.account_id 
                        FROM users u 
                        WHERE u.account_id = ? 
                        AND u.fname = ? 
                        AND u.mname = ?
                        AND u.lname = ? 
                        AND u.id_number = ? 
                        AND u.department = ?
                    ");
                    $stmt->execute([
                        $_SESSION['reset_account_id'], 
                        $fname, 
                        $mname,
                        $lname, 
                        $id_number, 
                        $department
                    ]);
                }
                
            } elseif ($role === 'Technician') {
                $fname = trim($_POST['fname']);
                $mname = trim($_POST['mname']);
                $lname = trim($_POST['lname']);
                $tech_id = trim($_POST['tech_id']);
                $contact_no = trim($_POST['contact_no']);
                $specialization = trim($_POST['specialization']);
                
                $stmt = $conn->prepare("
                    SELECT t.tech_id, t.account_id 
                    FROM technicians t 
                    WHERE t.account_id = ? 
                    AND t.fname = ? 
                    AND t.mname = ?
                    AND t.lname = ? 
                    AND t.tech_id = ?
                    AND t.contact_no = ? 
                    AND t.specialization = ?
                ");
                $stmt->execute([
                    $_SESSION['reset_account_id'], 
                    $fname,
                    $mname, 
                    $lname, 
                    $tech_id,
                    $contact_no, 
                    $specialization
                ]);
                
            } else {
                $error = "Password reset is only available for Users and Technicians.";
                $step = 2;
            }
            
            if (isset($stmt)) {
                $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            
            if ($user_data) {
                // Identity verified! Move to step 3
                $step = 3;
                $success = "Identity verified! Please enter your new password.";
            } else {
                $error = "The information provided does not match our records.";
                $step = 2;
            }
            
        } catch (PDOException $e) {
            error_log("Forgot Password Error: " . $e->getMessage());
            $error = "An error occurred. Please try again later.";
            $step = 2;
        }
    }
    
    // STEP 3: Reset Password
    if (isset($_POST['reset_password'])) {
        try {
            $new_password = trim($_POST['new_password']);
            $confirm_password = trim($_POST['confirm_password']);
            
            // Validation
            if (strlen($new_password) < 8) {
                $error = "Password must be at least 8 characters long.";
                $step = 3;
            } elseif ($new_password !== $confirm_password) {
                $error = "Passwords do not match.";
                $step = 3;
            } else {
                // Update password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE accounts SET password = ? WHERE account_id = ?");
                $stmt->execute([$hashed_password, $_SESSION['reset_account_id']]);
                
                // Clear session data
                unset($_SESSION['reset_account_id']);
                unset($_SESSION['reset_email']);
                unset($_SESSION['reset_role']);
                
                $success = "Password successfully reset! You can now login with your new password.";
                $step = 4; // Success step
            }
            
        } catch (PDOException $e) {
            error_log("Password Reset Error: " . $e->getMessage());
            $error = "An error occurred while resetting password.";
            $step = 3;
        }
    }
}

// Don't restore step from session - always start fresh at step 1
// User must complete the flow in one session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - MOP</title>
    <link rel="stylesheet" href="login.css?v=<?= time() ?>">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            padding: 10px 0;
        }

        .login-container {
            max-height: 90vh;
            overflow-y: auto;
            width: 420px;
            padding: 20px 25px;
            margin: auto;
        }

        .login-container::-webkit-scrollbar {
            width: 6px;
        }

        .login-container::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }

        .login-container::-webkit-scrollbar-thumb {
            background: #004aad;
            border-radius: 10px;
        }

        .login-container::-webkit-scrollbar-thumb:hover {
            background: #003d8f;
        }

        .logo-header {
            padding-bottom: 12px;
            margin-bottom: 12px;
        }

        .login-logo {
            width: 45px;
            height: 45px;
        }

        .platform-name {
            font-size: 16px;
        }

        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 15px;
            gap: 12px;
        }
        
        .step {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            color: #666;
            font-size: 13px;
            position: relative;
        }
        
        .step.active {
            background: #004aad;
            color: white;
            box-shadow: 0 0 8px rgba(0, 74, 173, 0.3);
        }
        
        .step.completed {
            background: #28a745;
            color: white;
        }

        .step::after {
            content: '';
            position: absolute;
            width: 35px;
            height: 2px;
            background: #ddd;
            right: -38px;
            top: 50%;
            transform: translateY(-50%);
        }

        .step:last-child::after {
            display: none;
        }

        .step.completed::after {
            background: #28a745;
        }
        
        .success {
            color: #28a745;
            font-weight: 600;
            margin-bottom: 12px;
            background: #d4edda;
            padding: 10px;
            border-radius: 6px;
            border: 1px solid #c3e6cb;
            font-size: 13px;
        }
        
        .back-link {
            display: block;
            text-align: center;
            margin-top: 12px;
            color: #004aad;
            text-decoration: none;
            font-weight: 500;
            font-size: 13px;
            transition: 0.3s;
        }
        
        .back-link:hover {
            text-decoration: underline;
            color: #003d8f;
        }
        
        .info-text {
            background: #e7f3ff;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 12px;
            font-size: 12px;
            color: #004aad;
            border-left: 4px solid #004aad;
            line-height: 1.4;
        }

        .info-text strong {
            display: block;
            margin-bottom: 4px;
            font-size: 13px;
        }
        
        select {
            width: 100%;
            padding: 9px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 13px;
            box-sizing: border-box;
            background: white;
        }

        h2 {
            margin-bottom: 12px;
            font-size: 19px;
        }

        .input-group {
            margin: 10px 0;
        }

        label {
            font-size: 13px;
            margin-bottom: 4px;
        }

        input, select {
            font-size: 13px;
            padding: 8px;
        }

        button {
            margin-top: 12px;
            padding: 10px;
            font-size: 14px;
        }

        .security-note {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            color: #856404;
            padding: 8px;
            border-radius: 6px;
            font-size: 11px;
            margin-top: 12px;
            line-height: 1.3;
        }

        .success-icon {
            font-size: 42px;
            color: #28a745;
            text-align: center;
            margin-bottom: 12px;
        }

        .error {
            font-size: 13px;
            padding: 9px;
            margin-bottom: 12px;
        }

        @media (max-width: 480px) {
            .login-container {
                width: 95%;
                max-height: 85vh;
                padding: 15px 20px;
            }

            .step {
                width: 28px;
                height: 28px;
                font-size: 12px;
            }

            .step::after {
                width: 25px;
                right: -27px;
            }

            h2 {
                font-size: 17px;
            }
        }
    </style>
</head>
<body>

<div class="login-container">
    <div class="logo-header">
        <img src="../pic/moplogo.png" alt="MOP Logo" class="login-logo">
        <h1 class="platform-name">Maintenance Operation Platform</h1>
    </div>

    <div class="login-box">
        <h2>Reset Password</h2>
        
        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step <?= $step >= 1 ? ($step > 1 ? 'completed' : 'active') : '' ?>">1</div>
            <div class="step <?= $step >= 2 ? ($step > 2 ? 'completed' : 'active') : '' ?>">2</div>
            <div class="step <?= $step >= 3 ? ($step > 3 ? 'completed' : 'active') : '' ?>">3</div>
            <div class="step <?= $step >= 4 ? 'active' : '' ?>">✓</div>
        </div>

        <?php if (!empty($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <?php if (!empty($success)): ?>
            <p class="success"><?= $success ?></p>
        <?php endif; ?>

        <!-- STEP 1: Verify Email -->
        <?php if ($step === 1): ?>
            <div class="info-text">
                <strong>Step 1: Account Verification</strong>
                Enter your email address and role to begin the password reset process.
            </div>
            
            <form method="POST">
                <div class="input-group">
                    <label>Email Address *</label>
                    <input type="email" name="email" required>
                </div>

                <div class="input-group">
                    <label>Account Role *</label>
                    <select name="role" required>
                        <option value="">-- Select Role --</option>
                        <option value="User">User</option>
                        <option value="Technician">Technician</option>
                    </select>
                </div>

                <button type="submit" name="verify_email">Continue</button>
            </form>

            <div class="security-note">
                🔒 For your security, you'll need to answer verification questions in the next step.
            </div>

            <a href="login.php" class="back-link">← Back to Login</a>

        <!-- STEP 2: Security Questions -->
        <?php elseif ($step === 2): ?>
            <div class="info-text">
                <strong>Step 2: Identity Verification</strong>
                Please provide additional information to verify your identity.
            </div>
            
            <form method="POST" id="verifyForm">
                <div class="input-group">
                    <label>First Name *</label>
                    <input type="text" name="fname" required>
                </div>

                <div class="input-group">
                    <label>Middle Name *</label>
                    <input type="text" name="mname" required>
                </div>

                <div class="input-group">
                    <label>Last Name *</label>
                    <input type="text" name="lname" required>
                </div>

                <?php if ($_SESSION['reset_role'] === 'User'): ?>
                    <div class="input-group">
                        <label>ID Number *</label>
                        <input type="text" name="id_number" required placeholder="Your employee/student ID">
                        <small style="color: #666; font-size: 11px; display: block; margin-top: 3px;">
                            Enter the ID number you registered with. If you don't remember, contact your administrator.
                        </small>
                    </div>

                    <div class="input-group">
                        <label>Department *</label>
                        <input type="text" name="department" required placeholder="e.g., Engineering Department">
                    </div>

                <?php elseif ($_SESSION['reset_role'] === 'Technician'): ?>
                    <div class="input-group">
                        <label>Technician ID *</label>
                        <input type="number" name="tech_id" required placeholder="Your technician ID number">
                    </div>

                    <div class="input-group">
                        <label>Contact Number *</label>
                        <input type="text" name="contact_no" required placeholder="e.g., 09123456789">
                    </div>

                    <div class="input-group">
                        <label>Specialization *</label>
                        <select name="specialization" required>
                            <option value="">-- Select Specialization --</option>
                            <option value="Aircon Technician">Aircon Technician</option>
                            <option value="Electrician">Electrician</option>
                            <option value="Plumber">Plumber</option>
                            <option value="Carpenter">Carpenter</option>
                            <option value="Network Technician">Network Technician</option>
                            <option value="Computer Technician">Computer Technician</option>
                            <option value="General Maintenance">General Maintenance</option>
                        </select>
                    </div>
                <?php endif; ?>

                <button type="submit" name="verify_identity">Verify Identity</button>
            </form>

            <div class="security-note">
                ⚠️ All information must match exactly with your registered account details.
            </div>

            <a href="forgot_password.php" class="back-link" onclick="return confirm('Cancel and start over?')">← Start Over</a>

        <!-- STEP 3: Reset Password -->
        <?php elseif ($step === 3): ?>
            <div class="info-text">
                <strong>Step 3: Create New Password</strong>
                Identity verified for: <strong><?= htmlspecialchars($_SESSION['reset_email']) ?></strong>
            </div>
            
            <form method="POST">
                <div class="input-group">
                    <label>New Password *</label>
                    <input type="password" name="new_password" required minlength="8" 
                           placeholder="Minimum 8 characters">
                </div>

                <div class="input-group">
                    <label>Confirm New Password *</label>
                    <input type="password" name="confirm_password" required minlength="8"
                           placeholder="Re-enter your password">
                </div>

                <button type="submit" name="reset_password">Reset Password</button>
            </form>

            <div class="security-note">
                💡 Choose a strong password with a mix of letters, numbers, and symbols.
            </div>

            <a href="forgot_password.php" class="back-link" onclick="return confirm('Cancel password reset?')">← Start Over</a>

        <!-- STEP 4: Success -->
        <?php elseif ($step === 4): ?>
            <div class="success-icon">✓</div>
            <div class="info-text" style="text-align: center; border-left: none; background: #d4edda; color: #155724;">
                <strong style="font-size: 16px;">Password Reset Successful!</strong>
                Your password has been changed. You can now login with your new credentials.
            </div>
            
            <a href="login.php">
                <button type="button">Go to Login</button>
            </a>
        <?php endif; ?>
    </div>
</div>

</body>
</html>