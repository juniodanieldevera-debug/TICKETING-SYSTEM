<?php
require_once '../config/db_connect.php';
session_start();

$error = '';
$disable = '';
$remaining = 0;

// Initialize attempts and cooldown
if (!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts'] = 0;
if (!isset($_SESSION['cooldown_until'])) $_SESSION['cooldown_until'] = 0;

$current_time = time();

// Check if cooldown is active
if ($current_time < $_SESSION['cooldown_until']) {
    $remaining = $_SESSION['cooldown_until'] - $current_time;
    $disable = "disabled";
    $error = "Too many attempts. Try again in <span id='countdown'>$remaining</span> seconds.";
}

// Only process login **on POST submission**
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // If cooldown active, ignore POST
    if ($current_time < $_SESSION['cooldown_until']) {
        // Do nothing
    } else {

        $email = trim($_POST['email']);
        $password = trim($_POST['password']);

        try {
            // Fetch user from database
            $stmt = $conn->prepare("SELECT * FROM accounts WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user && password_verify($password, $user['password'])) {
                // SUCCESS: reset attempts and cooldown
                $_SESSION['login_attempts'] = 0;
                $_SESSION['cooldown_until'] = 0;

                $_SESSION['account_id'] = $user['account_id'];
                $_SESSION['email']      = $user['email'];
                $_SESSION['role']       = $user['role'];

                // Redirect by role
                if ($user['role'] === "Admin") header("Location: ../ADash/Dashboard/ADashboard.php");
                if ($user['role'] === "Technician") header("Location: ../TDash/TDashboard/TDashboard.php");
                if ($user['role'] === "User") header("Location: ../UDash/UDashboard/UDashboard.php");

                exit;

            } else {
                // FAILED LOGIN → increment attempts
                $_SESSION['login_attempts']++;

                if ($_SESSION['login_attempts'] >= 3) {
                    $_SESSION['cooldown_until'] = time() + 5;
                    $remaining = 5;
                    $disable = "disabled";
                    $error = "Too many attempts. Try again in <span id='countdown'>$remaining</span> seconds.";
                } else {
                    $left = 3 - $_SESSION['login_attempts'];
                    $error = "Invalid email or password. Attempts left: $left";
                }
            }

        } catch (PDOException $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - MOP</title>
    <link rel="stylesheet" href="login.css?v=<?= time() ?>">
    <style>
        .forgot-password-link {
            display: block;
            text-align: center;
            margin-top: 12px;
            font-size: 14px;
        }
        
        .forgot-password-link a {
            color: #004aad;
            text-decoration: none;
            font-weight: 500;
            transition: 0.3s;
        }
        
        .forgot-password-link a:hover {
            text-decoration: underline;
            color: #003d8f;
        }
    </style>
</head>
<body>

<div class="login-container">
    <!-- LOGO AND PLATFORM NAME -->
    <div class="logo-header">
        <img src="../pic/moplogo.png" alt="MOP Logo" class="login-logo">
        <h1 class="platform-name">Maintenance Operation Platform</h1>
    </div>

    <div class="login-box">
        <h2>Welcome to Maintenance Portal</h2>

        <?php if (!empty($error)): ?>
            <p class="error"><?= $error ?></p>
        <?php endif; ?>

        <form method="POST">
            <div class="input-group">
                <label>Email</label>
                <input type="email" name="email" required <?= $disable ?>>
            </div>

            <div class="input-group">
                <label>Password</label>
                <input type="password" name="password" required <?= $disable ?>>
            </div>

            <button type="submit" <?= $disable ?>>LOGIN</button>
        </form>

        <div class="forgot-password-link">
            <a href="forgot_password.php">Forgot Password?</a>
        </div>

        <p class="note">For access, contact your Administrator.</p>
    </div>
</div>

<?php if ($disable && $remaining > 0): ?>
<script>
let countdown = <?= $remaining ?>;
const countdownElement = document.getElementById('countdown');
const emailInput = document.querySelector('input[name="email"]');
const passwordInput = document.querySelector('input[name="password"]');
const loginButton = document.querySelector('button[type="submit"]');

const timer = setInterval(() => {
    countdown--;
    if (countdownElement) countdownElement.textContent = countdown;
    if (countdown <= 0) {
        clearInterval(timer);
        if (countdownElement) countdownElement.textContent = '';
        emailInput.disabled = false;
        passwordInput.disabled = false;
        loginButton.disabled = false;
        location.reload(); // Refresh to reset attempts
    }
}, 1000);
</script>
<?php endif; ?>

</body>
</html>