<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $email = $_POST['email'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
  $contact = $_POST['contact_no'];
  $spec = $_POST['specialization'];

  // 1️⃣ Create account
  $stmt = $conn->prepare("INSERT INTO accounts (email, password, role) VALUES (?, ?, 'Technician')");
  $stmt->execute([$email, $password]);
  $account_id = $conn->lastInsertId();

  // 2️⃣ Create technician
  $stmt = $conn->prepare("INSERT INTO technicians (account_id, fname, lname, email, contact_no, specialization) 
                          VALUES (?, ?, ?, ?, ?, ?)");
  $stmt->execute([$account_id, $fname, $lname, $email, $contact, $spec]);

  echo json_encode(["success" => true]);
} catch (PDOException $e) {
  echo json_encode(["error" => $e->getMessage()]);
}
