<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $id = $_POST['tech_id'];

  $stmt = $conn->prepare("SELECT account_id FROM technicians WHERE tech_id=?");
  $stmt->execute([$id]);
  $acc = $stmt->fetch(PDO::FETCH_ASSOC);

  if ($acc) {
    $conn->prepare("DELETE FROM accounts WHERE account_id=?")->execute([$acc['account_id']]);
  }

  echo json_encode(["success" => true]);
} catch (PDOException $e) {
  echo json_encode(["error" => $e->getMessage()]);
}
