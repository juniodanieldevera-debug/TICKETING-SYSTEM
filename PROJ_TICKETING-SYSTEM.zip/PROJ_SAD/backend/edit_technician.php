<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $id = $_POST['tech_id'];
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $email = $_POST['email'];
  $contact = $_POST['contact_no'];
  $spec = $_POST['specialization'];
  $password = $_POST['password'] ?? '';

  // update account first
  if (!empty($password)) {
    $hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE accounts SET email=?, password=? WHERE account_id=(SELECT account_id FROM technicians WHERE tech_id=?)");
    $stmt->execute([$email, $hash, $id]);
  } else {
    $stmt = $conn->prepare("UPDATE accounts SET email=? WHERE account_id=(SELECT account_id FROM technicians WHERE tech_id=?)");
    $stmt->execute([$email, $id]);
  }

  // update technician info
  $stmt = $conn->prepare("UPDATE technicians SET fname=?, lname=?, email=?, contact_no=?, specialization=? WHERE tech_id=?");
  $stmt->execute([$fname, $lname, $email, $contact, $spec, $id]);

  echo json_encode(["success" => true]);
} catch (PDOException $e) {
  echo json_encode(["error" => $e->getMessage()]);
}
