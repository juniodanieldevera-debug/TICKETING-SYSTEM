<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $data = [
    'total_requests'   => 0,
    'completed_tasks'  => 0,
    'pending_tasks'    => 0
  ];

  // Total requests
  $stmt = $conn->query("SELECT COUNT(*) FROM user_requests");
  $data['total_requests'] = $stmt->fetchColumn();

  // Completed requests
  $stmt = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status = 'Completed'");
  $data['completed_tasks'] = $stmt->fetchColumn();

  // Pending requests
  $stmt = $conn->query("SELECT COUNT(*) FROM user_requests WHERE status IN ('Pending', 'Assigned', 'In Progress')");
  $data['pending_tasks'] = $stmt->fetchColumn();

  echo json_encode($data);
} catch (PDOException $e) {
  echo json_encode(['error' => $e->getMessage()]);
}
