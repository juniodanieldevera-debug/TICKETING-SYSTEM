<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $stmt = $conn->query("
    SELECT 
      CONCAT(u.fname, ' ', u.lname) AS user,
      ur.request_details AS action,
      DATE_FORMAT(ur.created_at, '%b %d, %Y %h:%i %p') AS time
    FROM user_requests ur
    JOIN accounts a ON ur.user_id = a.account_id
    JOIN users u ON u.account_id = a.account_id
    ORDER BY ur.created_at DESC
    LIMIT 10
  ");

  $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode($activities);
} catch (PDOException $e) {
  echo json_encode(['error' => $e->getMessage()]);
}
