<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $stmt = $conn->query("SELECT * FROM technicians ORDER BY date_registered DESC");
  echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch (PDOException $e) {
  echo json_encode(["error" => $e->getMessage()]);
}
