<?php
require_once '../config/db_connect.php';
header('Content-Type: application/json');

try {
  $stmt = $conn->query("
    SELECT 
      CONCAT(fname, ' ', lname) AS full_name,
      specialization,
      tasks_completed,
      ROUND(rating, 1) AS rating
    FROM technicians
    ORDER BY tasks_completed DESC, rating DESC
    LIMIT 5
  ");

  $techs = $stmt->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode($techs);
} catch (PDOException $e) {
  echo json_encode(['error' => $e->getMessage()]);
}
