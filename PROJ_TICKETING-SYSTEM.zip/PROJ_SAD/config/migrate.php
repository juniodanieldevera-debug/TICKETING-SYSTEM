<?php
// migrate_technician_notifs.php - Run this once then delete
session_start();

// If saved in config folder (htdocs/PROJ_SAD/config/migrate_technician_notifs.php)
require_once 'db_connect.php';
require_once 'notification_functions.php';

// Only allow admins
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'Admin') {
    die("Access denied. Only administrators can run this script.");
}

echo "<h3>Migrating Technician Notifications...</h3>";

try {
    // 1. Migrate assigned tasks
    $tasksQuery = $conn->query("
        SELECT ur.*, t.account_id, u.fname, u.lname, u.department 
        FROM user_requests ur 
        JOIN technicians t ON ur.tech_id = t.tech_id 
        LEFT JOIN users u ON ur.user_id = u.user_id 
        WHERE ur.tech_id IS NOT NULL
    ");
    $tasks = $tasksQuery->fetchAll(PDO::FETCH_ASSOC);

    $taskCount = 0;
    foreach ($tasks as $task) {
        $exists = $conn->prepare("SELECT id FROM notifications WHERE user_id = ? AND related_request_id = ? AND type = 'assignment'");
        $exists->execute([$task['account_id'], $task['id']]);
        
        if (!$exists->fetch()) {
            createNotification(
                $task['account_id'], 
                'Task Assigned', 
                "You have been assigned to fix {$task['unit_name']} for {$task['fname']} {$task['lname']} in {$task['department']}", 
                'assignment', 
                $task['id']
            );
            $taskCount++;
            echo "<p>Created task notification for technician {$task['account_id']} - Request #{$task['id']}</p>";
        }
    }

    // 2. Migrate ratings
    $ratingsQuery = $conn->query("
        SELECT tr.*, t.account_id, ur.unit_name, u.fname, u.lname 
        FROM technician_ratings tr 
        JOIN technicians t ON tr.tech_id = t.tech_id 
        JOIN user_requests ur ON tr.request_id = ur.id 
        LEFT JOIN users u ON tr.user_id = u.user_id
    ");
    $ratings = $ratingsQuery->fetchAll(PDO::FETCH_ASSOC);

    $ratingCount = 0;
    foreach ($ratings as $rating) {
        $exists = $conn->prepare("SELECT id FROM notifications WHERE user_id = ? AND related_request_id = ? AND type = 'rating'");
        $exists->execute([$rating['account_id'], $rating['request_id']]);
        
        if (!$exists->fetch()) {
            createNotification(
                $rating['account_id'], 
                'Rating Received', 
                "You received a {$rating['rating']}-star rating from {$rating['fname']} {$rating['lname']} for {$rating['unit_name']}", 
                'rating', 
                $rating['request_id']
            );
            $ratingCount++;
            echo "<p>Created rating notification for technician {$rating['account_id']} - Rating #{$rating['id']}</p>";
        }
    }

    echo "<p style='color: green; font-weight: bold;'>✅ Migration Complete!</p>";
    echo "<p>Tasks migrated: $taskCount</p>";
    echo "<p>Ratings migrated: $ratingCount</p>";
    echo "<p>Total: " . ($taskCount + $ratingCount) . " notifications created</p>";

} catch (PDOException $e) {
    echo "<p style='color: red;'>Database Error: " . $e->getMessage() . "</p>";
}
?>