<?php
// ==========================================
// FILE: config/notification_functions.php
// Complete Notification Functions with Error Handling
// ==========================================

/**
 * Get User Notifications with Error Handling
 */
function getUserNotifications($account_id, $filter = 'all') {
    global $conn;
    
    try {
        $sql = "SELECT n.*, ur.unit_name, ur.status as request_status 
                FROM notifications n 
                LEFT JOIN user_requests ur ON n.related_request_id = ur.id 
                WHERE n.user_id = :account_id";
        
        if ($filter === 'unread') {
            $sql .= " AND n.is_read = 0";
        }
        
        $sql .= " ORDER BY n.created_at DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':account_id', $account_id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("getUserNotifications Error: " . $e->getMessage());
        return [];
    }
}

/**
 * Get Technician Notifications with Error Handling
 */
function getTechnicianNotifications($account_id, $filter = 'all') {
    global $conn;
    
    try {
        $sql = "SELECT * FROM notifications WHERE user_id = :account_id";
        
        if ($filter === 'unread') {
            $sql .= " AND is_read = 0";
        }
        
        $sql .= " ORDER BY created_at DESC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':account_id', $account_id, PDO::PARAM_INT);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("getTechnicianNotifications Error: " . $e->getMessage());
        return [];
    }
}

/**
 * Mark Notification as Read
 */
function markNotificationAsRead($notification_id) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE id = :id");
        $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
        return $stmt->execute();
        
    } catch (Exception $e) {
        error_log("markNotificationAsRead Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Mark All Notifications as Read
 */
function markAllNotificationsAsRead($account_id) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = :account_id");
        $stmt->bindParam(':account_id', $account_id, PDO::PARAM_INT);
        return $stmt->execute();
        
    } catch (Exception $e) {
        error_log("markAllNotificationsAsRead Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get Unread Count
 */
function getUserUnreadCount($account_id) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = :account_id AND is_read = 0");
        $stmt->bindParam(':account_id', $account_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn();
        
    } catch (PDOException $e) {
        error_log("getUserUnreadCount Error: " . $e->getMessage());
        return 0;
    }
}

function getTechnicianUnreadCount($account_id) {
    return getUserUnreadCount($account_id);
}

/**
 * Time Ago Helper
 */
function timeAgo($datetime) {
    try {
        $timestamp = strtotime($datetime);
        if ($timestamp === false) return "Unknown time";
        
        $time = time() - $timestamp;
        
        if ($time < 60) return "Just now";
        if ($time < 3600) return floor($time / 60) . " minutes ago";
        if ($time < 86400) return floor($time / 3600) . " hours ago";
        if ($time < 604800) return floor($time / 86400) . " days ago";
        
        return date('M d, Y', $timestamp);
        
    } catch (Exception $e) {
        error_log("timeAgo Error: " . $e->getMessage());
        return "Unknown";
    }
}

/**
 * Create Notification (Base Function)
 */
function createNotification($user_id, $title, $message, $type = 'system', $related_request_id = null) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            INSERT INTO notifications (user_id, title, message, type, related_request_id) 
            VALUES (:user_id, :title, :message, :type, :related_request_id)
        ");
        
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':title', $title, PDO::PARAM_STR);
        $stmt->bindParam(':message', $message, PDO::PARAM_STR);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':related_request_id', $related_request_id, PDO::PARAM_INT);
        
        return $stmt->execute();
        
    } catch (Exception $e) {
        error_log("createNotification Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Create notification for status updates (for Users)
 * Call this when updating request status
 */
function notifyUserStatusChange($user_id, $request_id, $status) {
    $statusMessages = [
        'Pending' => 'Your maintenance request is now pending review',
        'Assigned' => 'A technician has been assigned to your request',
        'In Progress' => 'Technician is now working on your request',
        'Completed' => 'Your request has been completed. You can now rate the technician.',
        'Cancelled' => 'Your maintenance request has been cancelled',
        'Archived' => 'Your maintenance request has been archived'
    ];
    
    $message = $statusMessages[$status] ?? "Request status updated to: $status";
    
    return createNotification(
        $user_id,
        'Request Status Updated',
        $message,
        'status_update',
        $request_id
    );
}

/**
 * Create notification when technician is assigned (for Users)
 */
function notifyUserTechnicianAssigned($user_id, $request_id, $tech_name, $tech_specialization) {
    $message = "$tech_name ($tech_specialization) has been assigned to your maintenance request";
    
    return createNotification(
        $user_id,
        'Technician Assigned',
        $message,
        'assignment',
        $request_id
    );
}

/**
 * Create notification for material request approval/rejection (for Technicians)
 * Call this when admin approves/rejects material request
 */
function notifyTechMaterialRequest($tech_account_id, $status, $item_name, $quantity) {
    $title = $status === 'Approved' ? 'Material Request Approved ✓' : 'Material Request Rejected ✗';
    $message = "Your request for $quantity x $item_name has been " . strtolower($status);
    
    return createNotification(
        $tech_account_id,
        $title,
        $message,
        'system',
        null
    );
}

/**
 * Create notification for ratings (for Technicians)
 * Call this when user rates a technician
 */
function notifyTechRating($tech_account_id, $rating, $user_name, $request_id) {
    $stars = str_repeat('⭐', $rating);
    $message = "$user_name rated your service: $stars ($rating/5 stars)";
    
    return createNotification(
        $tech_account_id,
        'New Rating Received',
        $message,
        'system',
        $request_id
    );
}

/**
 * Create notification for new task assignment (for Technicians)
 * Call this when admin assigns a request to technician
 */
function notifyTechNewTask($tech_account_id, $request_id, $unit_name, $location) {
    $message = "You have been assigned to repair $unit_name at $location";
    
    return createNotification(
        $tech_account_id,
        'New Task Assigned',
        $message,
        'assignment',
        $request_id
    );
}

/**
 * Delete old notifications (cleanup function)
 * Call this periodically to remove old read notifications
 */
function deleteOldNotifications($days = 30) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("
            DELETE FROM notifications 
            WHERE is_read = 1 
            AND created_at < DATE_SUB(NOW(), INTERVAL :days DAY)
        ");
        $stmt->bindParam(':days', $days, PDO::PARAM_INT);
        return $stmt->execute();
        
    } catch (Exception $e) {
        error_log("deleteOldNotifications Error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get notification by ID
 */
function getNotificationById($notification_id) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("SELECT * FROM notifications WHERE id = :id");
        $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("getNotificationById Error: " . $e->getMessage());
        return null;
    }
}

/**
 * Check if user owns notification (security check)
 */
function userOwnsNotification($notification_id, $user_id) {
    global $conn;
    
    try {
        $stmt = $conn->prepare("SELECT COUNT(*) FROM notifications WHERE id = :id AND user_id = :user_id");
        $stmt->bindParam(':id', $notification_id, PDO::PARAM_INT);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
        
    } catch (PDOException $e) {
        error_log("userOwnsNotification Error: " . $e->getMessage());
        return false;
    }
}
?>