-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2025 at 02:24 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sad_fproj_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `account_id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Admin','Technician','User') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `notification_preferences` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`account_id`, `email`, `password`, `role`, `created_at`, `notification_preferences`) VALUES
(3, 'admin@mop.com', '$2y$10$V5d.TqusV4mAWBTEi63VJevV7mJPwUZe.XbqgOtefu3CAQD.Vxfwe', 'Admin', '2025-11-10 12:02:29', NULL),
(4, 'aldenrichard@mop.com', '$2y$10$73IL9OYvAerzMyfxiqvqheBKR6z0mK.nf8B4nhOs2SOEffBYETR4y', 'Technician', '2025-11-11 14:43:41', NULL),
(5, 'dan@mop.com', '$2y$10$mwWYoqkvZBVGP4Lq6A21Eu30TO5c6apvK7brD4A7.8qY1fyiJO4Xe', 'User', '2025-11-15 12:28:39', NULL),
(6, 'aldenuser@mop.com', '$2y$10$C2rZZr87UWK4k7INhdM5A.tAJWUJbmSHAuSfJ9HSW9fX.Z//t1epG', 'User', '2025-11-16 18:14:34', NULL),
(8, 'baloy@mop.com', '$2y$10$2d62Qksc9RhS9L7rT.BnLOpEdIkwVJ1AcbbIaXdhRLsNbuZz97Lye', 'Technician', '2025-11-16 19:52:31', NULL),
(9, 'tech@mop.com', '$2y$10$UKbza4F0.fiA/U6RvnjJ8e1SRma1L5G.qLkMcUA7EWxJ0/qemXY.C', 'Technician', '2025-11-16 23:16:54', NULL),
(18, 'dantech@mop.com', '$2y$10$ZBK3cBIttJK/2bVs/bqSIeiPcQUh8uas3y6BMi3AoLCDxSvxok4Eq', 'Technician', '2025-11-28 17:22:40', NULL),
(19, 'mano@mop.com', '$2y$10$NPEcm6w5Gq/ot/1Jva9Vt.59n.uklWMkPG3Nz6GnaGLg2HrVFjMQC', 'Technician', '2025-11-28 18:03:32', NULL),
(20, 'Jop1@mop.com', '$2y$10$FKfjpwMYvz.5DBXwE61f6ulGnlrkbU4H.fNrMMu6qPa6tstHNjJuS', 'Technician', '2025-11-29 01:52:49', NULL),
(21, 'danuser@mop.com', '$2y$10$KPxYbLcAk1e11gj01Dw9z.SSd94/hKxHc4xLWq8ASGsQ7hjhFn66.', 'User', '2025-11-29 03:34:08', NULL),
(22, 'user@mop.com', '$2y$10$RWseZtNNSPVgDsCnvzVRa./bPnrd/A67AHrwbG8Aw.aGrchc/gmXG', 'User', '2025-11-29 16:55:01', NULL),
(23, 'mus@mop.com', '$2y$10$SvibgHiupRTmUbTImGtfM.XQp9nGHCx2UmIbx177FqdwsUlD72fd6', 'User', '2025-11-29 17:44:48', NULL),
(28, 'kups@mop.com', '$2y$10$4EmLpPatGt/E9VOeH6MJVu4t5u.1HbASqiQFKHy.LvLKpRh1NxnqG', 'Technician', '2025-11-29 18:31:04', NULL),
(29, 'arayko@mop.com', '$2y$10$ciFMhJWA0pdkO0H7GEnR2.n/zVbxcHK4vTxzom2we8FgkRhoyBqBG', 'Technician', '2025-11-30 00:10:54', NULL),
(30, 'deoU@mop.com', '$2y$10$mak5AYUnn3Qsne/YIhXmQO3qXDwPPOFb7cj2qhBEcMmYn/2f/Pgz.', 'User', '2025-12-12 14:57:58', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `archived_requests`
--

CREATE TABLE `archived_requests` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `dept` varchar(100) DEFAULT NULL,
  `idnum` varchar(30) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `floor` varchar(20) DEFAULT NULL,
  `room` varchar(20) DEFAULT NULL,
  `unit_name` varchar(100) DEFAULT NULL,
  `unit_number` varchar(50) DEFAULT NULL,
  `request_details` text DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `status` enum('Pending','Assigned','In Progress','Completed','Cancelled') DEFAULT 'Completed',
  `tech_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `item_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `unit_number` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `supplier` varchar(255) DEFAULT NULL,
  `status` enum('Available','Low','Out of Stock') DEFAULT 'Available',
  `stock` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `isDeleted` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`item_id`, `name`, `unit_number`, `category`, `supplier`, `status`, `stock`, `created_at`, `isDeleted`) VALUES
(4, 'Corsair Mouse', 'M003', 'Mouse', 'Machenike QC', 'Available', 80, '2025-11-21 13:48:10', 1),
(8, 'Lenovo LOQ', 'L001', 'Laptop', 'Lenovo QC', 'Available', 14, '2025-11-29 23:51:19', 1);

-- --------------------------------------------------------

--
-- Table structure for table `inventory_reports`
--

CREATE TABLE `inventory_reports` (
  `report_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `tech_id` int(11) DEFAULT NULL,
  `action` enum('Added','Updated','Withdrawn','Returned') NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `note` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_reports`
--

INSERT INTO `inventory_reports` (`report_id`, `item_id`, `tech_id`, `action`, `quantity`, `created_at`, `note`) VALUES
(1, 4, NULL, 'Added', 2, '2025-11-21 13:48:10', ''),
(2, 4, NULL, 'Updated', 23, '2025-11-21 13:50:23', ''),
(3, 4, NULL, 'Updated', 1, '2025-11-21 13:50:27', ''),
(4, 4, NULL, 'Updated', 12, '2025-11-21 13:50:31', ''),
(10, 4, 3, 'Withdrawn', 3, '2025-11-26 23:38:09', 'Approved material request #2'),
(11, 4, 3, 'Withdrawn', 1, '2025-11-28 08:38:05', 'Approved material request #4 - Reason: need for the pc 2'),
(12, 4, NULL, 'Updated', 100, '2025-11-29 16:55:50', NULL),
(13, 4, 3, 'Withdrawn', 20, '2025-11-29 18:33:37', 'Approved material request #5'),
(18, 8, NULL, 'Added', 15, '2025-11-29 23:51:19', NULL),
(20, 8, NULL, '', NULL, '2025-11-30 00:08:22', NULL),
(21, 8, 3, 'Withdrawn', 1, '2025-11-30 00:13:16', 'Approved material request #6 - Reason: ada'),
(22, 8, NULL, '', NULL, '2025-12-13 01:22:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `material_requests`
--

CREATE TABLE `material_requests` (
  `request_id` int(11) NOT NULL,
  `tech_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `material_requests`
--

INSERT INTO `material_requests` (`request_id`, `tech_id`, `item_id`, `quantity`, `status`, `created_at`, `reason`) VALUES
(1, 3, 4, 1, 'Approved', '2025-11-26 14:41:52', NULL),
(2, 3, 4, 3, 'Approved', '2025-11-26 15:05:41', NULL),
(3, 3, 4, 1, 'Rejected', '2025-11-28 08:18:46', NULL),
(4, 3, 4, 1, 'Approved', '2025-11-28 08:22:03', 'need for the pc 2'),
(5, 3, 4, 20, 'Approved', '2025-11-29 18:33:18', ''),
(6, 3, 8, 1, 'Approved', '2025-11-30 00:12:07', 'ada');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_role` enum('Admin','User','Technician') NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `receiver_role` enum('Admin','User','Technician') NOT NULL,
  `group_id` varchar(100) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` enum('assignment','status_update','system','message') DEFAULT 'system',
  `is_read` tinyint(1) DEFAULT 0,
  `related_request_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `account_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `title`, `message`, `type`, `is_read`, `related_request_id`, `created_at`, `account_id`) VALUES
(1, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned', 'status_update', 1, 4, '2025-11-16 21:06:29', 0),
(2, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 4, '2025-11-16 21:07:28', 0),
(3, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 1, 4, '2025-11-16 21:08:11', 0),
(4, 'Technician Assigned', 'alden richard (Aircon Technician) has been assigned to your maintenance request', 'assignment', 1, 5, '2025-11-16 21:21:58', 0),
(5, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned', 'status_update', 1, 5, '2025-11-16 21:22:00', 0),
(6, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned', 'status_update', 1, 5, '2025-11-16 21:22:09', 0),
(7, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 1, 5, '2025-11-16 21:22:16', 0),
(8, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 5, '2025-11-16 21:22:22', 0),
(9, 'Technician Assigned', 'alden richard (Aircon Technician) has been assigned to your maintenance request', 'assignment', 1, 6, '2025-11-16 23:24:57', 0),
(10, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned', 'status_update', 1, 6, '2025-11-16 23:24:59', 0),
(11, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 6, '2025-11-16 23:26:19', 0),
(12, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 1, 6, '2025-11-16 23:28:43', 0),
(13, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 0, 5, '2025-11-17 00:18:04', 0),
(14, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 7, '2025-11-22 00:39:20', 0),
(15, 'Technician Assigned', 'Aaron Silastre (Network Technician) has been assigned to your maintenance request', 'assignment', 1, 11, '2025-11-22 18:41:34', 0),
(16, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 1, 11, '2025-11-22 18:41:37', 0),
(17, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned', 'status_update', 1, 9, '2025-11-22 18:41:48', 0),
(18, 'Technician Assigned', 'Aloy Baloy (Electrician) has been assigned to your maintenance request', 'assignment', 1, 9, '2025-11-22 18:41:50', 0),
(19, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 11, '2025-11-22 18:41:57', 0),
(20, 'Request Status Updated', 'Your maintenance request status has been updated to: Pending', 'status_update', 1, 11, '2025-11-22 18:42:01', 0),
(21, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 9, '2025-11-22 18:53:31', 0),
(22, 'Technician Assigned', 'Aaron Silastre (Network Technician) has been assigned to your maintenance request', 'assignment', 1, 9, '2025-11-22 18:53:32', 0),
(23, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 9, '2025-11-22 18:54:19', 0),
(24, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 1, 9, '2025-11-22 18:54:21', 0),
(25, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 10, '2025-11-22 18:54:39', 0),
(26, 'Technician Assigned', 'Aaron Silastre (Network Technician) has been assigned to your maintenance request', 'assignment', 1, 10, '2025-11-22 18:54:47', 0),
(27, 'Technician Assigned', 'alden richard (Aircon Technician) has been assigned to your maintenance request', 'assignment', 1, 8, '2025-11-22 18:59:09', 0),
(28, 'Technician Assigned', 'Aaron Silastre (Network Technician) has been assigned to your maintenance request', 'assignment', 0, 10, '2025-11-23 23:30:17', 0),
(29, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 10, '2025-11-23 23:30:21', 0),
(30, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 8, '2025-11-23 23:31:04', 0),
(31, 'Technician Assigned', 'alden richard (Aircon Technician) has been assigned to your maintenance request', 'assignment', 0, 14, '2025-11-24 00:30:54', 0),
(32, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 14, '2025-11-24 00:30:58', 0),
(33, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 0, 14, '2025-11-24 00:51:05', 0),
(34, 'Technician Assigned', 'Aaron Silastre (Network Technician) has been assigned to your maintenance request', 'assignment', 0, 13, '2025-11-24 01:11:38', 0),
(35, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 13, '2025-11-24 01:11:40', 0),
(36, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 13, '2025-11-24 01:12:20', 0),
(37, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 0, 13, '2025-11-26 13:58:15', 0),
(38, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 10, '2025-11-26 14:36:25', 0),
(39, 'Technician Assigned', 'Aloy Baloy (Electrician) has been assigned to your maintenance request', 'assignment', 0, 8, '2025-11-28 16:43:38', 0),
(40, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 8, '2025-11-28 16:43:42', 0),
(41, 'Technician Assigned', 'Aloy Baloy (Electrician) has been assigned to your maintenance request', 'assignment', 0, 8, '2025-11-28 17:02:43', 0),
(42, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 8, '2025-11-28 17:03:10', 0),
(43, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 8, '2025-11-28 17:03:50', 0),
(44, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 10, '2025-11-29 01:53:37', 0),
(45, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 10, '2025-11-29 01:57:37', 0),
(46, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 15, '2025-11-29 04:05:20', 0),
(47, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 15, '2025-11-29 04:20:27', 0),
(48, 'New Task Assigned', 'You have been assigned to fix the air conditioner in Room 301', 'assignment', 1, 15, '2025-11-29 11:39:19', 0),
(49, 'Task Completed Successfully', 'Your task \"Printer Repair\" has been marked as completed', 'status_update', 1, 15, '2025-11-29 11:39:19', 0),
(50, 'New Rating Received', 'You received a 5-star rating for your recent work', 'system', 1, NULL, '2025-11-29 11:39:19', 0),
(51, 'New Task Assigned', 'You have been assigned to fix the air conditioner in Room 301', 'assignment', 1, 15, '2025-11-29 11:39:37', 0),
(52, 'Task Completed Successfully', 'Your task \"Printer Repair\" has been marked as completed', 'status_update', 1, 15, '2025-11-29 11:39:37', 0),
(53, 'New Rating Received', 'You received a 5-star rating for your recent work', 'system', 1, NULL, '2025-11-29 11:39:37', 0),
(54, 'New Task Assigned', 'You have been assigned to fix the air conditioner in Room 301', 'assignment', 1, 15, '2025-11-29 11:40:42', 0),
(55, 'Task Completed Successfully', 'Your task \"Printer Repair\" has been marked as completed', 'status_update', 1, 15, '2025-11-29 11:40:42', 0),
(56, 'New Rating Received', 'You received a 5-star rating for your recent work', 'system', 1, NULL, '2025-11-29 11:40:42', 0),
(57, 'New Task Assigned', 'You have been assigned to fix the air conditioner in Room 301', 'assignment', 1, 15, '2025-11-29 11:40:47', 0),
(58, 'Task Completed Successfully', 'Your task \"Printer Repair\" has been marked as completed', 'status_update', 1, 15, '2025-11-29 11:40:47', 0),
(59, 'New Rating Received', 'You received a 5-star rating for your recent work', 'system', 1, NULL, '2025-11-29 11:40:47', 0),
(60, 'New Task Assigned', 'You have been assigned to fix the air conditioner in Room 301', 'assignment', 1, 15, '2025-11-29 11:41:06', 0),
(61, 'Task Completed Successfully', 'Your task \"Printer Repair\" has been marked as completed', 'status_update', 1, 15, '2025-11-29 11:41:06', 0),
(62, 'New Rating Received', 'You received a 5-star rating for your recent work', 'system', 1, NULL, '2025-11-29 11:41:06', 0),
(63, 'Task Assigned', 'You have been assigned to fix Printer for Dan Jun in Engineering Department', 'assignment', 1, 15, '2025-11-29 15:38:24', 0),
(64, 'Rating Received', 'You received a 5-star rating from Dan Jun for Printer', '', 1, 15, '2025-11-29 15:38:24', 0),
(65, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 16, '2025-11-29 15:40:42', 0),
(66, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 1, 22, '2025-11-29 17:32:33', 0),
(67, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 1, 22, '2025-11-29 17:32:35', 0),
(68, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 18, '2025-11-30 14:51:03', 0),
(69, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 22, '2025-11-30 14:53:06', 0),
(70, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 0, 22, '2025-11-30 15:06:54', 0),
(71, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 20, '2025-11-30 15:07:01', 0),
(72, 'Technician Assigned', 'Jop Jack (Computer Technician) has been assigned to your maintenance request', 'assignment', 0, 20, '2025-12-12 06:19:17', 0),
(73, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 20, '2025-12-12 06:19:21', 0),
(74, 'Request Status Updated', 'Your maintenance request status has been updated to: Archived', 'status_update', 0, 20, '2025-12-12 13:48:01', 0),
(75, 'Technician Assigned', 'Daniel Junio (Carpenter) has been assigned to your maintenance request', 'assignment', 0, 23, '2025-12-13 02:59:42', 0),
(76, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 23, '2025-12-13 02:59:51', 0),
(77, 'Technician Assigned', 'alden richard (Aircon Technician) has been assigned to your maintenance request', 'assignment', 0, 24, '2025-12-13 04:18:09', 0),
(78, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress', 'status_update', 0, 24, '2025-12-13 04:18:14', 0),
(79, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 24, '2025-12-13 04:18:42', 0),
(80, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 16, '2025-12-14 10:12:07', 8),
(81, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:18:08', 5),
(82, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:51', 5),
(83, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:54', 5),
(84, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:54', 5),
(85, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:54', 5),
(86, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:54', 5),
(87, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:54', 5),
(88, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(89, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(90, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(91, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(92, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(93, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:55', 5),
(94, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(95, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(96, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(97, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(98, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(99, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:20:56', 5),
(100, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:22', 5),
(101, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:22', 5),
(102, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:22', 5),
(103, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:23', 5),
(104, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:23', 5),
(105, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:23', 5),
(106, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:23', 5),
(107, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:24', 5),
(108, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:24', 5),
(109, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:24', 5),
(110, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:24', 5),
(111, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:21:24', 5),
(112, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:14', 5),
(113, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:14', 5),
(114, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(115, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(116, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(117, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(118, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(119, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:15', 5),
(120, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:16', 5),
(121, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:16', 5),
(122, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:16', 5),
(123, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:16', 5),
(124, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:22:16', 5),
(125, 'Test Notification for User', 'This is a test notification. If you see this in UNotification.php, the system is working!', 'system', 0, NULL, '2025-12-14 10:24:09', 5),
(126, 'Test Notification for Technician', 'This is a test notification. If you see this in TNotification.php, the system is working!', 'system', 1, NULL, '2025-12-14 10:24:09', 4),
(127, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 1, 24, '2025-12-14 10:29:58', 22),
(128, 'New Task Assigned', 'You have been assigned to repair Computer in Room 401 for Dan Jun (Engineering Department)', 'assignment', 0, 16, '2025-12-14 10:31:22', 9),
(129, 'Test Notification', 'This is a test notification from the manual testing tool', 'system', 0, NULL, '2025-12-14 10:31:53', 21),
(130, 'New Task Assigned', 'You have been assigned to repair Printer in Room 301 for Dan Jun (Engineering Department)', 'assignment', 1, 15, '2025-12-14 10:32:35', 20),
(131, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 16, '2025-12-14 10:33:16', 21),
(132, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 19, '2025-12-14 10:34:58', 9),
(133, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:39:15', 5),
(134, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:39:37', 5),
(135, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:39:39', 5),
(136, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:39:39', 5),
(137, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:08', 5),
(138, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:09', 5),
(139, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:09', 5),
(140, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:09', 5),
(141, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:10', 5),
(142, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:10', 5),
(143, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:10', 5),
(144, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:10', 5),
(145, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:49:10', 5),
(146, 'Test Notification for User', 'This is a test notification. If you see this in UNotification.php, the system is working!', 'system', 0, NULL, '2025-12-14 10:49:27', 5),
(147, 'Test Notification for Technician', 'This is a test notification. If you see this in TNotification.php, the system is working!', 'system', 1, NULL, '2025-12-14 10:49:27', 4),
(148, 'Test Notification', 'This is a test notification created by the diagnostic tool', 'system', 0, NULL, '2025-12-14 10:50:36', 5),
(149, '🧪 Test Notification', 'This is a test notification created at 2025-12-14 11:58:41', 'system', 1, NULL, '2025-12-14 10:58:41', 20),
(150, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 0, 21, '2025-12-14 11:15:31', 9),
(151, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed', 'status_update', 0, 19, '2025-12-14 11:20:16', 9),
(152, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 0, 21, '2025-12-14 11:38:56', 9),
(153, 'Request Status Updated', 'Your maintenance request status has been updated to: Completed - Your request has been completed. You can now rate the technician in your history.', 'status_update', 1, 18, '2025-12-14 12:01:32', 22),
(154, 'Request Status Updated', 'Your maintenance request status has been updated to: In Progress - Technician is now working on your request', 'status_update', 1, 21, '2025-12-14 12:03:50', 22),
(155, 'Request Status Updated', 'Your maintenance request status has been updated to: Assigned - A technician has been assigned to your request', 'status_update', 0, 16, '2025-12-14 12:11:41', 21),
(156, 'New Rating Received!', 'You received a 4-star rating (★★★★) from Daniel Junio for request: Air Conditioner', '', 1, 24, '2025-12-14 13:22:38', 4);

-- --------------------------------------------------------

--
-- Table structure for table `notifications_new`
--

CREATE TABLE `notifications_new` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `related_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification_settings`
--

CREATE TABLE `notification_settings` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `push_enabled` tinyint(1) DEFAULT 1,
  `email_enabled` tinyint(1) DEFAULT 1,
  `assignment_notifications` tinyint(1) DEFAULT 1,
  `status_notifications` tinyint(1) DEFAULT 1,
  `system_notifications` tinyint(1) DEFAULT 1,
  `message_notifications` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_settings`
--

INSERT INTO `notification_settings` (`id`, `account_id`, `push_enabled`, `email_enabled`, `assignment_notifications`, `status_notifications`, `system_notifications`, `message_notifications`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(2, 4, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(3, 6, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(4, 29, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(5, 8, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(6, 5, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(7, 18, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(8, 21, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(9, 20, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(10, 28, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(11, 19, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(12, 23, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(13, 9, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01'),
(14, 22, 1, 1, 1, 1, 1, 1, '2025-11-30 14:41:01', '2025-11-30 14:41:01');

-- --------------------------------------------------------

--
-- Table structure for table `notification_types`
--

CREATE TABLE `notification_types` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `role_access` enum('User','Technician','Admin','All') DEFAULT 'All'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_types`
--

INSERT INTO `notification_types` (`type_id`, `type_name`, `description`, `role_access`) VALUES
(1, 'request_assigned', 'Request assigned to technician', 'Technician'),
(2, 'request_status_update', 'Request status updated', 'User'),
(3, 'technician_rated', 'You received a rating', 'Technician'),
(4, 'inventory_low', 'Inventory item running low', 'Technician'),
(5, 'inventory_restocked', 'Inventory item restocked', 'Technician'),
(6, 'new_request', 'New maintenance request', 'Admin'),
(7, 'request_completed', 'Your request was completed', 'User'),
(8, 'request_cancelled', 'Your request was cancelled', 'User'),
(9, 'request_assigned', 'Request assigned to technician', 'Technician'),
(10, 'request_status_update', 'Request status updated', 'User'),
(11, 'technician_rated', 'You received a rating', 'Technician'),
(12, 'inventory_low', 'Inventory item running low', 'Technician'),
(13, 'inventory_restocked', 'Inventory item restocked', 'Technician'),
(14, 'new_request', 'New maintenance request', 'Admin'),
(15, 'request_completed', 'Your request was completed', 'User'),
(16, 'request_cancelled', 'Your request was cancelled', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `ticketnum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`ticketnum`) VALUES
(2);

-- --------------------------------------------------------

--
-- Table structure for table `technicians`
--

CREATE TABLE `technicians` (
  `tech_id` int(11) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact_no` varchar(30) DEFAULT NULL,
  `specialization` varchar(100) DEFAULT NULL,
  `rating` float DEFAULT 0,
  `tasks_completed` int(11) DEFAULT 0,
  `working_hours` int(11) DEFAULT 0,
  `status` enum('Available','Busy') DEFAULT 'Available',
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp(),
  `mname` varchar(50) DEFAULT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `isDeleted` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technicians`
--

INSERT INTO `technicians` (`tech_id`, `account_id`, `fname`, `lname`, `email`, `contact_no`, `specialization`, `rating`, `tasks_completed`, `working_hours`, `status`, `date_registered`, `mname`, `id_number`, `isDeleted`) VALUES
(1, 4, 'alden', 'richard', 'aldenrichard@mop.com', '09497875899', 'Aircon Technician', 4, 0, 0, 'Available', '2025-11-11 14:43:41', '', NULL, 1),
(2, 8, 'Aloy', 'Baloy', 'baloy@mop.com', '09999999999', 'Electrician', 5, 2, 4, 'Available', '2025-11-16 19:52:31', 'Nig', NULL, 1),
(3, 9, 'Aaron', 'Silastre', 'tech@mop.com', '091111111111', 'Network Technician', 4, 0, 0, 'Available', '2025-11-16 23:16:54', 'jak', NULL, 1),
(7, 18, 'Daniel', 'Junio', 'dantech@mop.com', '09497875899', 'Carpenter', 4, 1, 4, 'Available', '2025-11-28 17:22:40', 'De Vera', NULL, 1),
(8, 19, 'Adrian', 'Mano', 'mano@mop.com', '09878765678', 'Plumber', 0, 0, 0, 'Available', '2025-11-28 18:03:32', 'De Los', NULL, 1),
(9, 20, 'Jop', 'Jack', 'Jop1@mop.com', '09876542567', 'Computer Technician', 4.7, 6, 9, 'Available', '2025-11-29 01:52:49', 'Jill', '', 1),
(13, 28, 'kupal', 'bossing', 'kups@mop.com', '09497875899', 'Computer Technician', 0, 0, 0, 'Available', '2025-11-29 18:31:04', '2', NULL, 0),
(14, 29, 'kupal', 'bossing', 'arayko@mop.com', '09497875899', 'General Maintenance', 0, 0, 0, 'Available', '2025-11-30 00:10:54', 'kaba', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `technician_ratings`
--

CREATE TABLE `technician_ratings` (
  `id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `tech_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `comment` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technician_ratings`
--

INSERT INTO `technician_ratings` (`id`, `request_id`, `tech_id`, `user_id`, `rating`, `comment`, `created_at`) VALUES
(8, 15, 9, 8, 5, '', '2025-11-29 04:20:53'),
(9, 22, 9, 9, 5, '', '2025-11-30 14:53:51'),
(10, 20, 9, 9, 4, '', '2025-12-12 06:20:23'),
(11, 23, 7, 9, 4, '', '2025-12-13 03:00:24'),
(14, 24, 1, 9, 4, '', '2025-12-14 13:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `suffix` varchar(10) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `id_number` varchar(30) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `floor` varchar(20) DEFAULT NULL,
  `room` varchar(20) DEFAULT NULL,
  `street` varchar(150) DEFAULT NULL,
  `barangay` varchar(150) DEFAULT NULL,
  `city` varchar(150) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp(),
  `isDeleted` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `account_id`, `fname`, `mname`, `lname`, `suffix`, `email`, `password`, `contact`, `gender`, `birthday`, `id_number`, `department`, `floor`, `room`, `street`, `barangay`, `city`, `zip`, `date_registered`, `isDeleted`) VALUES
(8, 21, 'Dan', 'Del', 'Jun', NULL, 'danuser@mop.com', '', NULL, NULL, NULL, 'ID-8', 'Engineering Department', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-29 03:34:08', 1),
(9, 22, 'Daniel', 'De Vera', 'Junio', NULL, 'user@mop.com', '', '09497875899', 'MALE', NULL, 'ID-9', 'Security Department', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-29 16:55:01', 1),
(10, 23, 'allahu', 'aa', 'akbar', NULL, 'mus@mop.com', '', NULL, NULL, NULL, 'ID-10', 'Engineering Department', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-29 17:44:48', 0),
(11, 20, 'Jop', '', 'Jk', NULL, 'Jop@mop.com', '', '', '', NULL, 'ID-11', 'IT Department', NULL, NULL, NULL, NULL, NULL, NULL, '2025-11-30 14:00:13', 0),
(12, 30, 'Deo', 'Gracias', 'Vinluan', NULL, 'deoU@mop.com', '', NULL, NULL, NULL, 'ID-10', 'HR Department', NULL, NULL, NULL, NULL, NULL, NULL, '2025-12-12 14:57:58', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_devices`
--

CREATE TABLE `user_devices` (
  `id` int(11) NOT NULL,
  `account_id` int(11) NOT NULL,
  `device_token` text NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_requests`
--

CREATE TABLE `user_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tech_id` int(11) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `mname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `idnum` varchar(30) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `floor` varchar(20) DEFAULT NULL,
  `room` varchar(20) DEFAULT NULL,
  `unit_name` varchar(100) DEFAULT NULL,
  `unit_number` varchar(50) DEFAULT NULL,
  `technician_type` varchar(100) DEFAULT NULL,
  `request_details` text DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `image_path` text DEFAULT NULL,
  `status` enum('Pending','Assigned','In Progress','Completed','Cancelled','Archived') DEFAULT 'Pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_requests`
--

INSERT INTO `user_requests` (`id`, `user_id`, `tech_id`, `fname`, `mname`, `lname`, `idnum`, `department`, `floor`, `room`, `unit_name`, `unit_number`, `technician_type`, `request_details`, `request_date`, `image_path`, `status`, `created_at`) VALUES
(15, 8, 9, 'Dan', 'Del', 'Jun', NULL, 'Engineering Department', '3', '301', 'Printer', 'Unit 5', 'Computer Technician', 'fix the printer - paper jamming', '2025-12-01', 'sodanew1_1764389066_708adf9f8410.jpg', 'Completed', '2025-11-29 04:04:26'),
(16, 8, 9, 'Dan', 'Del', 'Jun', NULL, 'Engineering Department', '4', '401', 'Computer', 'Unit 9', 'Computer Technician', 'lagging - cant even use the computer', '2025-11-29', 'Screenshot_2025-10-31_055426_1764430812_d4b0bf759952.png', 'Assigned', '2025-11-29 15:40:12'),
(17, 9, NULL, 'mop', 'sample', 'user', NULL, 'Security Department', '1', '101', 'Air Conditioner', 'Unit 1', 'Computer Technician', 'aaaa - aaa', '2025-12-05', 'notification__1__1764435885_e0bd1ea6c949.png', 'Pending', '2025-11-29 17:04:45'),
(18, 9, 9, 'mop', 'sample', 'user', NULL, 'Security Department', '1', '101', 'Air Conditioner', 'Unit 1', 'Computer Technician', 'aadasadsaaa - aa', '2025-12-01', 'notification__1__1764436140_6e9d34b2bfd8.png', 'Completed', '2025-11-29 17:09:00'),
(19, 9, 2, 'mop', 'sample', 'user', NULL, 'Security Department', '2', '201', 'Computer', 'Unit 1', 'Electrician', 'was - ssss', '2025-11-29', 'notification__1__1764436156_d9a4079a1f71.png', 'Completed', '2025-11-29 17:09:16'),
(20, 9, 9, 'mop', 'sample', 'user', NULL, 'Security Department', '5', '501', 'Projector', 'Unit 4', 'Computer Technician', 'bbbbbbbbbbbbbbbbbbb - a', '2025-11-29', NULL, 'Archived', '2025-11-29 17:22:35'),
(21, 9, 7, 'mop', 'sample', 'user', NULL, 'Security Department', '2', '201', 'Air Conditioner', 'Unit 1', 'Carpenter', 'adasdas - aa', '2025-11-29', NULL, 'In Progress', '2025-11-29 17:26:06'),
(22, 9, 9, 'mop', 'sample', 'user', NULL, 'Security Department', '1', '101', 'Air Conditioner', 'Unit 2', 'Computer Technician', 'TESTING - AAAAA', '2025-12-02', NULL, 'Archived', '2025-11-29 17:30:27'),
(23, 9, 7, 'Daniel', 'De Vera', 'Junio', NULL, 'Security Department', '3', '301', 'Furniture', 'Unit 6', 'Carpenter', 'butas yung upuan - paayos plz', '2025-12-13', NULL, 'Completed', '2025-12-13 02:59:09'),
(24, 9, 1, 'Daniel', 'De Vera', 'Junio', NULL, 'Security Department', '2', '204', 'Air Conditioner', 'Unit 3', 'Aircon Technician', 'Use PDO - php data object', '2025-12-13', NULL, 'Completed', '2025-12-13 04:08:58'),
(25, 9, NULL, 'Daniel', 'De Vera', 'Junio', NULL, 'Security Department', '3', '301', 'Air Conditioner', 'Unit 5', 'Electrician', 'test - test', '2025-12-14', NULL, 'Pending', '2025-12-14 12:11:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `archived_requests`
--
ALTER TABLE `archived_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `inventory_reports`
--
ALTER TABLE `inventory_reports`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `tech_id` (`tech_id`);

--
-- Indexes for table `material_requests`
--
ALTER TABLE `material_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `tech_id` (`tech_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `related_request_id` (`related_request_id`),
  ADD KEY `idx_user_unread` (`is_read`),
  ADD KEY `idx_user_type` (`type`),
  ADD KEY `idx_created_at` (`created_at`),
  ADD KEY `idx_account_unread` (`account_id`,`is_read`),
  ADD KEY `idx_account_created` (`account_id`,`created_at`),
  ADD KEY `idx_related_request` (`related_request_id`);

--
-- Indexes for table `notifications_new`
--
ALTER TABLE `notifications_new`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `notification_settings`
--
ALTER TABLE `notification_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `account_id` (`account_id`);

--
-- Indexes for table `notification_types`
--
ALTER TABLE `notification_types`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `technicians`
--
ALTER TABLE `technicians`
  ADD PRIMARY KEY (`tech_id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `technician_ratings`
--
ALTER TABLE `technician_ratings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_request_rating` (`request_id`),
  ADD KEY `tech_id` (`tech_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `account_id` (`account_id`);

--
-- Indexes for table `user_requests`
--
ALTER TABLE `user_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tech_id` (`tech_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `archived_requests`
--
ALTER TABLE `archived_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `inventory_reports`
--
ALTER TABLE `inventory_reports`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `material_requests`
--
ALTER TABLE `material_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `notifications_new`
--
ALTER TABLE `notifications_new`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notification_settings`
--
ALTER TABLE `notification_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `notification_types`
--
ALTER TABLE `notification_types`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `technicians`
--
ALTER TABLE `technicians`
  MODIFY `tech_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `technician_ratings`
--
ALTER TABLE `technician_ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user_devices`
--
ALTER TABLE `user_devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_requests`
--
ALTER TABLE `user_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `inventory_reports`
--
ALTER TABLE `inventory_reports`
  ADD CONSTRAINT `inventory_reports_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `inventory` (`item_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `inventory_reports_ibfk_2` FOREIGN KEY (`tech_id`) REFERENCES `technicians` (`tech_id`) ON DELETE SET NULL;

--
-- Constraints for table `material_requests`
--
ALTER TABLE `material_requests`
  ADD CONSTRAINT `material_requests_ibfk_1` FOREIGN KEY (`tech_id`) REFERENCES `technicians` (`tech_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `material_requests_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `inventory` (`item_id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications_new`
--
ALTER TABLE `notifications_new`
  ADD CONSTRAINT `notifications_new_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`);

--
-- Constraints for table `notification_settings`
--
ALTER TABLE `notification_settings`
  ADD CONSTRAINT `notification_settings_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE;

--
-- Constraints for table `technicians`
--
ALTER TABLE `technicians`
  ADD CONSTRAINT `technicians_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE;

--
-- Constraints for table `technician_ratings`
--
ALTER TABLE `technician_ratings`
  ADD CONSTRAINT `technician_ratings_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `user_requests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `technician_ratings_ibfk_2` FOREIGN KEY (`tech_id`) REFERENCES `technicians` (`tech_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `technician_ratings_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_devices`
--
ALTER TABLE `user_devices`
  ADD CONSTRAINT `user_devices_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`account_id`) ON DELETE CASCADE;

--
-- Constraints for table `user_requests`
--
ALTER TABLE `user_requests`
  ADD CONSTRAINT `user_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_requests_ibfk_2` FOREIGN KEY (`tech_id`) REFERENCES `technicians` (`tech_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
